/****************************************************************************/
/* s19.h       Juan Gonzalez                                                */
/****************************************************************************/
/*   Fichero con definicion de tipos y estructuras necesarios para todos    */
/* los programas que trabajan con el modulo S19                             */
/*--------------------------------------------------------------------------*/
/* web: www.microbotica.es                                                  */
/* mail: info@microbotica.es                                                */
/****************************************************************************/

#ifndef S19_H
#define S19_H

#ifndef BYTE
  typedef unsigned char byte;
  #define BYTE
#endif

/*			 **************************
**************************   I N T E R F A Z      ***********************
			 **************************                      */

/* TIPO S19

    Este tipo representa a un fichero en formato S19. Las librerias de
    interfaz lo que hacen es crear y manipular variables del tipo S19.
    Este tipo se puede considerar como un tipo abstracto de datos. No
    importa como es la estructura interna. Solo hay que saber como se
    opera con este tipo.				       */
    

/* ------------------ CONSTRUCCION DEL TIPO S19 -------------------------- */
    
struct registros1 {  /* Estructura registros del tipo 1 */
	  byte tam;                    /* Tamano codigo/datos  */
	  unsigned int dir;            /* Direccion            */
	  byte codigo[37];             /* Codigo/datos         */
          byte crc;                    /* Campo crc            */
	  struct registros1 *sig;      /* Siguiente registro   */
};

struct sfichs19 {   /* Estructura ficheros S19 */

	 unsigned int nbytes;        /* N* bytes total de codigo fich. S19 */
	 unsigned int nreg;          /* N* registros del tipo 1            */
	 struct registros1 *cabeza;  /* Lista de registros del tipo 1      */

};

typedef struct sfichs19 S19;  /* TIPO S19 */

/*  --------------------- PROTOTIPOS ------------------------------------ */

int abrir_s19(char *fich,S19 *ss19,int modo);
void cerrar_s19(S19 ss19);
int leerdir_s19(S19 ss19,int nreg, unsigned int *dir);
int leercod_s19(S19 ss19,int nreg, byte *cod, byte *tam, byte *crc);
byte calcular_crc(byte *bloque, int tam);
unsigned int getnbytes19(S19 ss19);
unsigned int getnregs19(S19 ss19);
char *geterrors19();
void s19toramint(S19 f,byte *ramint, byte *ramintoc);
void s19toeeprom(S19 f,byte *eeprom, byte *eepromoc);
int situacion_progs19(S19 fs19, int *ov);
void raminttoc(byte *ramint, char *cadc);

/* --------------- DESCRIPCION DEL INTERFAZ ----------------------------- */
/*

int abrir_s19(char *fich,S19 *ss19,int modo);
****************************************************************************
*  Abrir un fichero .S19 y crear una variable de tipo S19. Para trabajar   *
*  con cualquier fichero .S19 habra que abrirlo primero.                   *
*                                                                          *
*   PARAMETROS ENTRADA:                                                    *
*                                                                          *
*      - Fich: Nombre del fichero .S19 a abrir. Si se especifica sin       *
*              extension por defecto se toma extension.S19. Se puede       *
*              especificar la ruta completa del fichero.                   *
*                                                                          *
*      - Modo: Indica el modo de apertura del fichero. Existen dos modos   *
*                                                                          *
*              - Modo 1: Se comprueba el Checksum de todos los registros   *
*              - Modo 0: No se comprueba el checksum.                      *
*                                                                          *
*   PARAMETROS DE SALIDA:                                                  *
*                                                                          *
*      - ss19: Se devuelve una variable del tipo S19 que sera necesaria    *
*              para trabajar con el fichero abierto.                       *
*                                                                          *
*   La funcion devuelve 0 si no ha podido abrir el fichero porque se ha    *
*   producido algon error.                                                 *
*                                                                          *
*                                                                          *
*   Si el fichero ha sido abierto correctamente se devuelve un 1           *
*                                                                          *
****************************************************************************

void cerrar_s19(S19 ss19);
************************************************************************
*  Dejar de trabajar con el archivo S19 especificado. Se libera toda la*
*  memoria que se habia tomado.                                        *
*************************************************************************

byte calcular_crc(byte *bloque, int tam);
***********************************************************************
* Calcular el CRC de un bloque de datos. Se utiliza un CRC de 8 bits  *
***********************************************************************

int leerdir_s19(S19 ss19,int nreg, unsigned int *dir);
************************************************************************
*  Leer el campo direccion del fichero S19 especificado.               *
*                                                                      *
*                                                                      *
*  ENTRADAS:                                                           *
*                                                                      *
*       - ss19: Fichero S19 abierto con el que trabajar                *
*       - nreg: Numero del registro al que se quiere acceder           *
*                                                                      *
*  SALIDAS:                                                            *
*                                                                      *
*       - dir : Campo direccion del registro especificado              *
*                                                                      *
*      Se devuelve 0 en caso de que no exista el registro pedido.      *
*      Se devuelve 1 en caso de exito.                                 *
************************************************************************

int leercod_s19(S19 ss19,int nreg, byte *cod, byte *tam, byte *crc);
************************************************************************
*  Leer el campo codigo/datos del registro especificado.               *
*                                                                      *
*  ENTRADAS:                                                           *
*                                                                      *
*     - ss19 : Fichero S19 abierto con el que trabajar                 *
*     - nreg : Numero del registro al que se quiere acceder            *
*                                                                      *
*  SALIDAS:                                                            *
*                                                                      *
*     - cod : Campo codigo/datos del registro especificado             *
*     - tam : tamano del campo codigo/datos                            *
*     - crc : Campo crc                                                *
*                                                                      *
*      Se devuelve 0 en caso de que no exista el registro pedido.      *
*      Se devuelve 1 en caso de exito.                                 *
************************************************************************

unsigned int getnbytes19(S19 ss19);
************************************************************************
*  Devolver el numero de bytes de todo el codigo del fichero S19       *
*  especificado.                                                       *
************************************************************************

unsigned int getnregs19(S19 ss19);
****************************************************************
*  Devolver el numero de registros del tipo 1 del fichero S19  *
*  especificado.                                               *
****************************************************************

char *geterrors19();
****************************************************************************
*  Devolver la cadena del error producido en la ultima apertura del        *
*  fichero .S19                                                            *
****************************************************************************

void s19toramint(S19 f,byte *ramint, byte *ramintoc);
   ************************************************************************
   * Quedarse con la parte del programa .S19 comprendido entre las        *
   * direccion 0-255. El resto se desprecia.                              *
   *                                                                      *
   * Estas posiciones se introducen en la matriz ramint que debe tener    *
   * una capacidad minima de 256 posiciones.                              *
   *                                                                      *
   * En la matriz de ocupacion se indica con 0 las posiciones dentro de   *
   * la matriz ramint que no tienen codigo. Con 1 las posiciones que si   *
   * lo tienen.                                                           *
   ************************************************************************

void s19toeeprom(S19 f,byte *eeprom, byte *eepromoc);
   ************************************************************************
   * Quedarse con la parte del programa .S19 comprendido entre las        *
   * direccion $B600-$B7FF. El resto del programa se desprecia.           *
   *                                                                      *
   * Estas posiciones se introducen en la matriz eeprom que debe tener    *
   * una capacidad minima de 512 posiciones.                              *
   *                                                                      *
   * En la matriz de ocupacion se indica con 0 las posiciones dentro de   *
   * la matriz eeprom que no tienen codigo. Con 1 las posiciones que si   *
   * lo tienen.                                                           *
   ************************************************************************

int situacion_progs19(S19 fs19, int *ov);
   ************************************************************************
   * Comprobar la situacion del programa: RAM interna, EEPROM o RAM       *
   * externa.                                                             *
   * En ov se devuelve si ha habido desbordamiento de la eeprom o ram     *
   * interna.                                                             *
   *                                                                      *
   *  La funcion devuelve 1 : Programa para RAM interna                   *
   *                      2 : Programa para EEPROM                        *
   *                      3 : Programa para RAM externa.                  *
   ************************************************************************

void raminttoc(byte *ramint, char *cadc);
   ************************************************************************
   * Tomar la matriz ramint que contiene un programa para la RAM interna  *
   * y devolver en el array cadc la cadena que representa la misma        *
   * matriz pero definida en C.                                           *
   *   La cadena cadc debe tener el tamano especificado por la constante  *
   * MAXCADC especificada en el fichero S19UTIL.H                         *
   ************************************************************************
   
*/
   


#endif /* del define S19_H */
