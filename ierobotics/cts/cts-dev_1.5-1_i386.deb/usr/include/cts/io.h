/****************************************************************************/
/* io.h  Juan Gonzalez Gomez                                                */
/*------------------------------------------------------------------------- */
/* Definiciones y prototipos para el IO                                     */
/*--------------------------------------------------------------------------*/
/****************************************************************************/

#ifndef _IO_H
#define _IO_H

/******************************/
/* Prototipos del interfaz    */
/******************************/


/**********************/
/* Abrir la consola.  */
/**********************/
void abrir_consola();

/**********************************************/
/* Cerrar la consola y recuperar la anterior  */
/**********************************************/
void cerrar_consola();

/************************************************************************/
/*  Indicar si hay un caracter pendiente de ser leido. La funcion       */
/*  devuelve:                                                           */
/*    0 --> No hay caracteres pendientes                                */
/*    1 --> Si hay caracteres pendientes                                */
/************************************************************************/
int kbhit();

/******************************************************************/
/*  Devolver el caracter leido por el teclado. Si no hay ningun   */
/*  caracter pendiente de ser leido se espera hasta que lo haya.  */
/******************************************************************/
char getch();

/****************************************************/
/* Imprimir un caracter directamente en la pantalla */
/****************************************************/
void printcar(char c);

/******************************************************/
/* Imprimir una cadena directamente en la pantalla    */
/******************************************************/
void print(char *cad);

      
#endif  /* Del define _IO_H */
