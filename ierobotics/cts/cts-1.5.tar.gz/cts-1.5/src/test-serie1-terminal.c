/******************************************************************/
/* test-serie1-terminal.c   Juan Gonzalez Gomez                   */
/*----------------------------------------------------------------*/
/* Ejemplo del modulo serie.c.                                    */
/* Peque�o terminal de comunicaciones.                            */
/*----------------------------------------------------------------*/
/* LICENCIA GPL                                                   */
/******************************************************************/

#include <stdlib.h>
#include <fcntl.h>
#include <termios.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <string.h>

#include "serie.h"
#include "io.h"

#define ESC 27

int main(void)
{
  char cad[50];
  char c,d;
  
  if (abrir_puerto_serie(COM1)==0) {
    printf ("Error al abrir puerto serie: %s\n",getserial_error());
    exit(1);
  }  
  dtr_off();
  
  printf ("\nTerminal de comunicaciones. Pulse ESC para terminar\n");
  printf ("Teclas:  1.- DTR ON\n");
  printf ("         2.- DTR OFF\n");
  printf ("         3.- Enviar una cadena\n");
  printf ("         4.- Velocidad 1200\n");
  printf ("         5.- Velocidad 7680\n");
  printf ("         6.- Velocidad 9600\n");
  printf ("\n\n");
  
  abrir_consola();
 
  do {
    if (kbhit()) {
      c=getch();
      switch(c) {
        case '1' : dtr_on();
                   printf ("DTR ON\n");
                   break; 
        case '2' : dtr_off(); 
                   printf ("DTR OFF\n");
                   break; 
        case '3' : strcpy(cad,"Hola..");           
                   enviar_bloque(cad,strlen(cad));
                   break;
        case '4' : baudios(1200); break;
        case '5' : baudios(7680); break;
        case '6' : baudios(9600); break;
        case '\n': c='\r';
        default  : enviar_car(c);
      }
    }
    if (car_waiting()) {
      d=leer_car();
      if (d!=0) printcar(d);
      else printcar('*');
    }
  } while (c!=ESC);
  
  printf ("\n\n");
  cerrar_consola();
  cerrar_puerto_serie();
  
  return 1;
}
