/****************************************************************************/
/* BOOTSTRP.C  (c) MICROBOTICA, S.L.  ENERO 2000.                           */
/****************************************************************************/
/*                                                                          */
/*   Rutinas para la carga de programas en la ram interna del 68HC11 cuando */
/* arranca en modo bootstrap.                                               */
/*                                                                          */
/*--------------------------------------------------------------------------*/
/* web: www.microbotica.es                                                  */
/* mail: info@microbotica.es                                                */
/*--------------------------------------------------------------------------*/
/****************************************************************************/

#include <unistd.h>

#include "serie.h"
#include "bootstrp.h"

/*			 **************************
**************************   I N T E R F A Z      ***********************
			 **************************                      */

/* Lista funciones de interfaz: 

void set_break_timeout(unsigned long timeout);
void set_eco_checking(byte eco);
void resetct6811();
int okreset();        
int jump_eeprom();
int jump_ram();
int cargar_ramint(byte *ramint, void (*car)());
int cargars19_ramint(S19 fs19, void (*car)());
char *getloaderror();

*/

/*		   ********************************
******************** I M P L E M E N T A C I O N  ***********************
		   ********************************                        */
                   
#define TIMEOUT_BREAK 2000000  /* Timeout por defecto del Break */
#define TIEMPO 500000    /* Timeout para recibir el eco */

unsigned long break_timeout=TIMEOUT_BREAK; 
byte ecocheck=ON;
static int nerror;
char errorload[8][80] = {
 "",                               /* 1 */ /* Error en .S19 */
 "La tarjeta CT6811 no responde",  /* 2 */
 "Fallo en la transmision",        /* 3 */
 "No se recibe senal de BREAK",    /* 4 */
 "El programa no es para la RAM interna",                 /* 5 */
 "El programa desborda los 256 bytes de la RAM interna",  /* 6 */
};

void set_break_timeout(unsigned long timeout)
/****************************************************************/
/* Cambiar el valor del timeout para recibir la senal de BREAK  */
/****************************************************************/
{
  if (timeout>0) break_timeout=timeout;
}

void set_eco_checking(byte eco)
/*********************************************************************/
/* Cambiar el estado de la comprobacion del eco al cargar programas  */
/* Si se realiza carga en la CTNET sera necesario DESACTIVAR EL ECO  */
/*  Por defecto se encuentra activo.                                 */
/*********************************************************************/
{
  if (eco==OFF) ecocheck=OFF;
  else ecocheck=ON;
}

void resetct6811()
/*
**************************************
*  Realizar un reset de la CT6811.   *
***************************************/
{
  dtr_on();
  usleep(100000);
  dtr_off();
}

int okreset()
/*
************************************************************************
*  Realizar un reset de la CT6811 y esperar la se*al de BREAK          *
*  correspondiente. Si no se recibe dentro del plazo establecido la    *
*  funcion devuelve 0. 1 en caso de recibirse el BREAK.                *
*************************************************************************/
{
  resetct6811();
  if (wait_break(break_timeout)==0) return 0;
  else return 1;
}

int jump_eeprom()
/*
************************************************
*  Saltar a la memoria EEPROM. La funci*n de-  *
*  vuelve 1 si se ha recibido el BREAK y se ha *
*  saltado correctamente. En caso de no reci-  *
*  bir el BREAK se devuelve 0.                 *
*************************************************/
{
  if (okreset()) {
    enviar_break();
/*    enviar_car(0x00); */
    return 1;
  }
  return 0;
}

int jump_ram()
/*
************************************************
*  Saltar a la direccion $0000 de la memoria.  *
*  La funcion devuelve 1 si se ha recibido el  *
*  BREAK y se ha saltado correctamente a la    *
*  RAM. En caso de no recibir el BREAK se      *
*  devuelve 0.                                 *
*************************************************/
{
  if (okreset()) {
    enviar_car(0x55);
    return 1;
  }
  return 0;
}

int cargar_ramint(byte *ramint, void (*car)())
/*
************************************************************************
*  Enviar el programa especificado por la matriz ramint a la tarjeta   *
*  CT6811. Cada vez que se ha enviado un byte de codigo se llama a la  *
*  funcion car.                                                        *
*                                                                      *
*    La funcion devuelve 1 si no se ha producido ningun error. Se      *
*  devuelve 0 en caso de error. Si se ha producido un error con la     *
*  funcion getloaderror se devuelve la cadena que indica el error.     *
*                                                                      *
*    ES NECESARIO QUE SE HAYA ABIERTO EL PUERTO SERIE ANTES DE ENVIAR  *
*  CUALQUIER PROGRAMA.                                                 *
*                                                                      *
*************************************************************************/
{
  int i;
  byte c;
  int timeout;

  nerror=0;

  baudios(7680);
  vaciar_buffer_rx();
  resetct6811();
  if (okreset()==0) {
    nerror=4;                /* No se recibe BREAK */
    return 0;
  }
  enviar_car(0xFF);          /* Especificar 7680 baudios */
  enviar_bloque(ramint,256);

  /* Leer los caracteres del eco */
  /* El ultimo eco no se tiene en cuenta, porque si el programa         */
  /* en la ram interna usa el SCI, puede venir modificado (El programa  */
  /* puede modificar los parametros del SCI, como la velocidad          */
  for (i=0; i<256; i++) {
    c=leer_car_plazo(TIEMPO,&timeout);

    if (timeout) {
      nerror=2;      /* Error de timeout */
      return 0;
    }
    /* El ultimo caracter del eco nunca se comprueba. */
    /* Puede llegar corrupto.                         */
    if (ecocheck==ON && i<255) {  /* Si hay que comprobar el eco... */
      if (c!=ramint[i]) { 
        nerror=3;      /* Se ha recibido un eco diferente */
        return 0;      /* El ultimo eco no se cuenta...   */
      }
    }  
    (*car)();          
  }
  return 1;
}

int cargars19_ramint(S19 fs19, void (*car)())
/*
************************************************************************
*  Enviar el fichero .S19 especificado a la tarjeta CT6811. El         *
*  fichero debe estar preparado para la ram interna. Cada vez que se   *
*  envia un caracter se llama a la funcion car.                        *
*                                                                      *
*    La funcion devuelve 1 si no se ha producido ningun error. Se      *
*  devuelve 0 en caso de error. Si se ha producido un error con la     *
*  funcion getloaderror se devuelve la cadena que indica el error.     *
*                                                                      *
*    ES NECESARIO QUE SE HAYA ABIERTO EL PUERTO SERIE ANTES DE ENVIAR  *
*  CUALQUIER PROGRAMA.                                                 *
*                                                                      *
*************************************************************************/
{
  byte ramint[256];
  byte ramintoc[256];
  int ov;

  
  if (situacion_progs19(fs19,&ov)!=1) {
    nerror=5;               /* Programa no es para ram interna */
    return 0;
  }
  if (ov==1) {
    nerror=6;    /* El programa desborda la RAM interna */
    return 0;
  }
  s19toramint(fs19,ramint,ramintoc);
  return cargar_ramint(ramint,car);
}

char *getloaderror()
/*
****************************************************************************
*  Devolver la cadena del error producido en la ultima carga de programas  *
*  en la RAM interna                                                       *
*****************************************************************************/
{
  if (nerror==0) return NULL;
  if (nerror==1) return (char *)geterrors19();   /* Error en .S19   */
  return (char *)&errorload[nerror-1];    /* Error al cargar */
}
