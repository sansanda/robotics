/**************************************************************************/
/*  IO.C   (C) Microbotica, S.L. NOVIEMBRE 1997.                          */
/* ---------------------------------------------------------------------- */
/*  Rutinas de E/S para la pantalla y el teclado. Las funciones de        */
/*  interfaz son:                                                         */
/*                                                                        */
/*    * abrir_consola()                                                   */
/*    * cerrar_consola()                                                  */
/*    * print()                                                           */
/*    * printcar()                                                        */
/*    * getch()                                                           */
/*    * kbhit()                                                           */
/*                                                                        */
/*------------------------------------------------------------------------*/
/* web: www.microbotica.es                                                */
/* mail: info@microbotica.es                                              */
/**************************************************************************/

#include <stdio.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/time.h>
#include <stdlib.h>
#include <unistd.h>

#include "io.h"

#define ESC 27

static struct termios oldconsola,consola;

void abrir_consola()
/**********************/
/* Abrir la consola.  */
/**********************/
{
  /* Leer los parametros asociados a la consola */
  if (ioctl(0,TCGETS,&consola)==-1){
    perror("ioctl\n");
    exit(4);
  }
  oldconsola = consola; /* Almacenar parametros para su posterior recup. */
  /* Cambiar parametros */
  consola.c_cc[VMIN]=0;
  consola.c_lflag&=~(ECHO|ISIG|ICANON); 
  ioctl(0,TCSETS,&consola);
}

void cerrar_consola()
/**********************************************/
/* Cerrar la consola y recuperar la anterior  */
/**********************************************/
{
  ioctl(0,TCSETSF,&oldconsola);
}

int kbhit()
/************************************************************************/
/*  Indicar si hay un caracter pendiente de ser leido. La funcion       */
/*  devuelve:                                                           */
/*    0 --> No hay caracteres pendientes                                */
/*    1 --> Si hay caracteres pendientes                                */
/************************************************************************/
{
  int n;
  if (ioctl(0,FIONREAD,&n)==0) {
    return n;
  }
  return 0;
}

char getch()
/******************************************************************/
/*  Devolver el caracter leido por el teclado. Si no hay ningun   */
/*  caracter pendiente de ser leido se espera hasta que lo haya.  */
/******************************************************************/
{
  char c;
    
  while (!kbhit()) {
  }
  read(0,&c,1);   /* Leer caracter     */
  return c;       /* Devolver caracter */
}

void printcar(char c)
/****************************************************/
/* Imprimir un caracter directamente en la pantalla */
/****************************************************/
{
  write(1,&c,1);
}

void print(char *cad)
/******************************************************/
/* Imprimir una cadena directamente en la pantalla    */
/******************************************************/
{
  int i=0;
  
  while (cad[i]!=0){
    write(1,&cad[i],1);
    i++;
  }
}
