/**************************************************************************/
/* R6811pc.H (C) MICROBOTICA, S.L. ENERO 2000                             */
/**************************************************************************/
/*  Fichero que contiene todos los registros internos del 68HC11.         */
/*  Version para el PC.                                                   */
/*------------------------------------------------------------------------*/
/* web: www.microbotica.es                                                */
/* mail: info@microbotica.es                                              */
/**************************************************************************/

#ifndef R6811PC_H
#define R6811PC_H

#define PORTA  0x1000
#define PIOC   0x1002
#define PORTC  0x1003
#define PORTB  0x1004
#define PORTCL 0x1005
#define DDRC   0x1007
#define PORTD  0x1008
#define DDRD   0x1009
#define PORTE  0x100A
#define CFORC  0x100B
#define OC1M   0x100C
#define OC1D   0x100D

#define TCNT   0x100E
#define TIC1   0x1010
#define TIC2   0x1012
#define TIC3   0x1014
#define TOC1   0x1016
#define TOC2   0x1018
#define TOC3   0x101A
#define TOC4   0x101C
#define TOC5   0x101E

#define TCTL1  0x1020
#define TCTL2  0x1021
#define TMSK1  0x1022
#define TFLG1  0x1023
#define TMSK2  0x1024
#define TFLG2  0x1025
#define PACTL  0x1026
#define PACNT  0x1027
#define SPCR   0x1028
#define SPSR   0x1029
#define SPDR   0x102A
#define BAUD   0x102B
#define SCCR1  0x102C
#define SCCR2  0x102D
#define SCSR   0x102E
#define SCDR   0x102F
#define ADCTL  0x1030
#define ADR1   0x1031
#define ADR2   0x1032
#define ADR3   0x1033
#define ADR4   0x1034
#define OPTION 0x1039
#define COPRST 0x103A
#define PPROG  0x103B
#define HPRIO  0x103C
#define INIT   0x103D
#define TEST1  0x103E
#define CONFIG 0x103F

#endif /* Del R6811PC_H */
