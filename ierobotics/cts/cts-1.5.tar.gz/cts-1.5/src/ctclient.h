/****************************************************************************/
/* CTCLIENT.H  (c) MICROBOTICA, S.L.       ENERO 2000                       */
/*--------------------------------------------------------------------------*/
/* web: www.microbotica.es                                                  */
/* mail: info@microbotica.es                                                */
/****************************************************************************/

#ifndef CTCLIENT_H
#define CTCLIENT_H


#ifndef BYTE
  #define BYTE
  typedef unsigned char byte;
#endif

#ifndef SI
  #define SI 1
  #define NO 0
#endif

typedef unsigned int uint;

/* -------------------------- PROTOTIPOS ------------------------------- */

  int load(byte *valor, uint dir);
  int load_block(byte *buff, uint tam, uint dir, void (*reccar)());
  void store(byte valor, uint dir);
  void store_block(byte *buff, uint tam, uint dir, void (*sendcar)());
  int store_block_eeprom(byte *buff, uint tam, uint dir, void (*eeprcar)());
  int check_conexion();
  void execute(uint dir);
  int hay_conexion();


/* -------------------------- DESCRIPCION ------------------------------- */
/*

int load(byte *valor, uint dir);
  ************************************************************************
  * Leer un byte de la direccion de memoria especificada. La funcion     *
  * devuelve 0 si el CTSERVER no responde. 1 en caso contrario.          *
  ************************************************************************

int load_block(byte *buff, uint tam, uint dir, void (*reccar)());
  ************************************************************************
  * Recibir un bloque de datos desde el 68HC11. El bloque tiene un       *
  * tamaoo tam y comienza a partir de la direccion dir. El bloque reci-  *
  * bido se situa en el buffer buff. Cada vez que se recibe un byte se   *
  * llama al procedimiento reccar pasado como parametro.                 *
  *                                                                      *
  *   La funcion devuelve un 0 si el CTSERVER no responde. Se envia un   *
  * 1 si la operacion se ha realizado con exito.                         *
  *                                                                      *
  ************************************************************************  

void store(byte valor, uint dir);
  *********************************************************
  * Enviar el byte especificado en la direccion indicada. *
  *********************************************************

void store_block(byte *buff, uint tam, uint dir, void (*sendcar)());
  ************************************************************************
  * Enviar un bloque de datos desde el PC al 68HC11. El bloque se encuen-*
  * tran en el buffer buff, que tiene un tamano tam. El bloque se debe   *
  * situar a patir de la direccion indicada.                             *
  *                                                                      *
  * Cada vez que se envia un byte se llama a procedimiento sendcar pasado*
  * como argumento.                                                      *
  *                                                                      *
  ************************************************************************

int store_block_eeprom(byte *buff, uint tam, uint dir, void (*eeprcar)());
  ************************************************************************
  * Grabar un bloque de datos en la memoria EEPROM.  El bloque se encuen-*
  * tran en el buffer buff, que tiene un tama*o tam. El bloque se debe   *
  * situar a patir de la direccion indicada.                             *
  *                                                                      *
  * Cada vez que se envia un byte se llama a procedimiento eepromcar     *
  * pasado como argumento.                                               *
  *                                                                      *
  *   La funcion devuelve 0 si ha ocurido alg*n error. Devuelve 1 en     *
  * caso de exito.                                                       *
  *                                                                      *
  ************************************************************************

int check_conexion();
   ************************************************************************
   * Comprobar si existe conexion con el servidor CTSERVER.               *
   *                                                                      *
   * Se devuelve:                                                         *
   *           0 --> Servidor no responde                                 *
   *           1 --> El servidor ha respondido                            *
   ************************************************************************

void execute(uint dir);
   ************************************************************************
   * Llamar al servicio de salto y ejecucion del servidor CTSERVER.       *
   ************************************************************************

int hay_conexion();
*************************************************************************
* Devolver estado conexion de la ultima comunicacion con CTSERVER       *
*************************************************************************

*/

#endif  /* del define CTCLIENT_H */
