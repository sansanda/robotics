/********************************************************************/
/*  test-ascbin1.c   Juan Gonzalez                                  */
/* ---------------------------------------------------------------- */
/*  Prueba de la libreria ASCBIN.C.                                 */
/*------------------------------------------------------------------*/
/* LICENCIA GPL                                                     */
/********************************************************************/

#include <stdio.h>

#include "ascbin.h"

int main(void)
{
  unsigned char x1,x2;
  unsigned int y1;
  char cad[5];

  char1tobyte('A',&x1);  /* Convertir 'A' en 10 */
  printf ("%u\n",x1);
  
  char2tobyte("FF",&x2); /* Convertir "FF" en 255 */
  printf ("%u\n",x2);
  
  char4toint("123C",&y1); /* Convertir "123C" en 4668  */
  printf ("%u\n",y1);
  
  bytetochar1(12,cad);   /* Convertir 12 en "C" */
  printf ("%c\n",cad[0]);
  
  bytetochar2(127,cad);  /* Convertir 127 en "7F" */
  printf ("%s\n",cad);
  
  inttochar4(14563,cad); /* Convertir 14563 en "38E3"*/
  printf ("%s\n",cad);
  
  return 1;
}
