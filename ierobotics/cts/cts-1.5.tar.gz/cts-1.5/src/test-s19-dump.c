/****************************************************************************/
/* DUMPS19.C   (c) Microbotica,S.L. Febrero 1998.                           */
/****************************************************************************/
/*                                                                          */
/* Ejemplo de utilizacion de la libreria S19.C.                             */
/*                                                                          */
/*   Este programa lee un archivo en formato .S19 y vuelca los campos de    */
/* codigo/datos y de direccion.                                             */
/*                                                                          */
/*--------------------------------------------------------------------------*/
/* web: www.microbotica.es                                                  */
/* mail: info@microbotica.es                                                */
/****************************************************************************/

#include <stdio.h>
#include "ascbin.h"
#include "s19.h"

int main(void)
{
  char *caderror;
  char cad2[5];
  char cad[80];
  byte codigo[37];
  byte crc;
  byte tam;
  int i,n;
  unsigned int dir;
  unsigned int nreg;
  S19 mis19;      /* Fichero S19 */

  /* ------------------------------- */
  /* ---- ABRIR EL FICHERO S19 ----- */
  /* --------------------------------*/
  printf ("\nNombre fichero: ");
  scanf("%s",cad);
  if (abrir_s19(cad,&mis19,1)==0) {
    caderror=(char *)geterrors19();
    printf ("Error: %s\n",caderror);
    return 0;
  }

  /* ---------------------------- */
  /* ---- VOLCAR EL FICHERO  ---- */
  /* ---------------------------- */
  nreg=getnregs19(mis19);
  printf ("\n");
  printf ("Reg. Dir. tam.                  Codigo/datos\n");

  for (i=1; i<=nreg; i++) {
    leerdir_s19(mis19,i,&dir);
    leercod_s19(mis19,i,codigo,&tam,&crc);
    printf ("%3u %4X  %4u ",i,dir,tam);
    for (n=0; n<tam; n++) {
      bytetochar2(codigo[n],cad2);
      printf ("%s",cad2);
    }
    printf ("\n");

  }

  /* ------------------------------- */
  /* ---- CERRAR EL FICHERO S19 ---- */
  /* ------------------------------- */

  cerrar_s19(mis19);
  return 0;
}
