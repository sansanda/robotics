/************************************************************************/
/* CTNET.C  (C) MICROBOTICA, S.L.    ENERO 2000.                        */
/* -------------------------------------------------------------------- */
/* Libreria para el dialogo con los servidores especificos para la      */
/* CTNET.                                                               */
/*----------------------------------------------------------------------*/
/* web: www.microbotica.es                                              */
/* mail: info@microbotica.es                                            */
/************************************************************************/

#include <unistd.h>

#include "serie.h"

typedef unsigned int uint;

#define TIMEOUT 500000

void netstore(byte dirctn, byte valor, unsigned int dir)
/*********************************************************************/
/*  Almacenar un valor en la direccion de memoria especificada del   */
/*  nodo especificado de la CTNET.                                   */
/*                                                                   */
/*  ENTRADAS:                                                        */
/*              dirctn --> Direccion CTNET del nodo                  */
/*              valor  --> Valor a almacenar                         */
/*              dir   ---> Direccion de memoria                      */
/*********************************************************************/
{
  byte trama[7];
  
  trama[0]=dirctn;
  trama[1]='B';
  trama[2]=(byte)(dir & 0xFF);
  trama[3]=(byte)(dir>>8)&0xFF;
  trama[4]=1;
  trama[5]=0;
  trama[6]=valor;
  enviar_bloque(trama,7);
  while(bufftx_waiting()!=0);
  usleep(800);
}

void netstore_block(byte dirctn, byte *buff,uint tam, uint dir, void (*reccar)())
/************************************************************************/
/*  Almacenar un bloque de datos a partir de la direccion especificada  */
/*  en el nodo de la CTNET indicado.                                    */
/*                                                                      */
/*  ENTRADAS:                                                           */
/*             dirctn --> Direccion del nodo CTNET.                     */
/*             buff ----> Buffer con los datos a almacenar.             */
/*             tam -----> Tamano de los datos a almacenar.              */
/*             dir -----> Direccion de memoria donde almacenar datos    */
/*             reccar --> Funcion llamada cada vez que se envia un dato */
/************************************************************************/
{
  byte trama[5];
  int i;
  
  trama[0]=dirctn;
  trama[1]='B';
  trama[2]=(byte)(dir & 0xFF);
  trama[3]=(byte)(dir>>8 &0xFF);
  trama[4]=(byte)(tam & 0xFF);
  trama[5]=(byte)(tam>>8 & 0xFF);
  enviar_bloque(trama,6);
  i=0;
  while (tam>0) {
    enviar_car(buff[i]);
    i++;
    tam--;
  }
  while(bufftx_waiting()!=0);
  usleep(800);
}

int netcheck_conexion(byte dir)
/**********************************************************************/
/* Comprobar la conexion del nodo indicado de la CTNET.               */
/* La funcion devuelve 0 si el nodo no ha respondido, 1 si esta vivo  */
/**********************************************************************/
{
  int timeout;
  byte c;
  
  enviar_car(dir);
  enviar_car('D');
  while(bufftx_waiting()!=0);
  c=leer_car_plazo(TIMEOUT,&timeout);
  if (timeout==1 || c!='J') return 0;
  return 1;
}

int netload(byte dirctn, byte *valor, unsigned int dir)
/************************************************************************/
/*  Leer un dato de la direccion indicada del nodo especificado de la   */
/*  CTNET.                                                              */
/*                                                                      */
/*  ENTRADAS:                                                           */
/*            dirctn --> Direccion del nodo CTNET.                      */
/*            dir   ---> Direccion de memoria                           */
/*  SALIDAS:                                                            */
/*            valor --> Valor leido                                     */
/*                                                                      */
/*  La funcion devuelve 0 si el nodo no ha respondido, 1 si no ha       */
/*  habido errores.                                                     */
/************************************************************************/
{
  byte trama[7];
  int timeout;
  
  trama[0]=dirctn;
  trama[1]='A';
  trama[2]=(byte)(dir & 0xFF);
  trama[3]=(byte)(dir>>8)&0xFF;
  trama[4]=1;
  trama[5]=0;
  enviar_bloque(trama,6);
  while(bufftx_waiting()!=0);
  
  *valor=leer_car_plazo(TIMEOUT,&timeout);
  if (timeout==1) return 0;
  return 1;
}

int netload_block(byte dirctn,byte *buff,uint tam,uint dir,void (*reccar)())
/************************************************************************/
/* Leer un bloque de datos del nodo especificado de la CTNET.           */
/*                                                                      */
/* ENTRADAS:                                                            */
/*            - dirctn --> Direccion CTNET del nodo                     */
/*            - tam -----> Tamano del bloque a leer                     */
/*            - dir   ---> Direccion de memoria                         */
/*            - reccar --> Funcion llamada cada vez que se recibe un    */
/*                         byte.                                        */
/* SALIDAS:                                                             */
/*            - buff --> Datos leidos.                                  */
/*                                                                      */
/*   La funcion devuelve 0 si el nodo no ha respondido, 1 en caso de    */
/*  todo se haya recibido correctamente.                                */
/************************************************************************/
{
  byte trama[7];
  int timeout;
  int i;
  
  trama[0]=dirctn;
  trama[1]='A';
  trama[2]=(byte)(dir & 0xFF);
  trama[3]=(byte)(dir>>8)&0xFF;
  trama[4]=(byte)(tam & 0xFF);
  trama[5]=(byte)(tam>>8)&0xFF;
  enviar_bloque(trama,6);
  while(bufftx_waiting()!=0);
  
  /* --- Recibir la informacion solicitada -- */
  i=0;                
  while (tam>0) {
    buff[i]=leer_car_plazo(TIMEOUT,&timeout);
    if (timeout==1) {
      return 0;         /* El servidor no responde */
    }
    (*reccar)();
    i++;
    tam--;
  }
  return 1;
}
