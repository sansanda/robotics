/****************************************************************************/
/* s19.c    Juan Gonzalez Gomez                                             */
/****************************************************************************/
/*   Rutinas para el procesamiento de ficheros en el formato .S19 de        */
/* Motorola.                                                                */
/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
/****************************************************************************/

#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <malloc.h>

#include "ascbin.h"
#include "s19.h"

/*  ---------------RESUMEN DEL INTERFAZ:-----------------------

int abrir_s19(char *fich,S19 *ss19,int modo);
void cerrar_s19(S19 ss19);
int leerdir_s19(S19 ss19,int nreg, unsigned int *dir);
int leercod_s19(S19 ss19,int nreg, byte *cod, byte *tam, byte *crc);
byte calcular_crc(byte *bloque, int tam);
unsigned int getnbytes19(S19 ss19);
unsigned int getnregs19(S19 ss19);
char *geterrors19();
void s19toramint(S19 f,byte *ramint, byte *ramintoc);
void s19toeeprom(S19 f,byte *eeprom, byte *eepromoc);
int situacion_progs19(S19 fs19, int *ov);
void raminttoc(byte *ramint, char *cadc);
*/

/**************************************************************************/
/*                I M P L E M E N T A C I O N                             */
/**************************************************************************/

/*****************************
  *  VARIABLES GLOBALES      *
  *****************************/

int nerror; /* Numero de error que se ha producido */

char error_s19[8][80]={
  {"Archivo no encontrado o error al abrir el archivo"},  /* 1 */
  {"-----------------------------"},                      /* 2 */
  {"No se puede leer el fichero"},                        /* 3 */
  {"Fichero no esta en formato .S19"},                    /* 4 */
  {"Checksum erroneo"},                                   /* 5 */
  {"No hay memoria suficiente"},                          /* 6 */
  {"Conflicto con las directivas ORG"},			  /* 7 */
};

void extensions19(char *fich)
/*
****************************************************************************
*  Comprobar la extension del fichero. Si no tiene ninguna extension se    *
*  le poner .S19                                                           *
*****************************************************************************/
{
  int i;

  i=0;
  while (fich[i]!='.' && fich[i]!=0)  /* Recorrer la cadena buscando un . */
    i++;

  if (fich[i]==0) {     /* no tiene extensi*n. Hay que a*adirla  */
    fich[i]='.';
    fich[i+1]='s';
    fich[i+2]='1';
    fich[i+3]='9';
    fich[i+4]=0;
  }
}

char *geterrors19()
/*
****************************************************************************
*  Devolver la cadena del error producido en la ultima apertura del        *
*  fichero .S19                                                            *
*****************************************************************************/
{
  if (nerror==0) return NULL;
  return (char *)&error_s19[nerror-1];
}

int getchar2(int f,char *cad)
/*
****************************************************************************
*  Se leen 2 caracteres del fichero especificado y se meten en la cadena   *
*  cad. Se devuelve 0 si se ha producido alg*n error.                      *
*****************************************************************************/
{
  if (read(f,cad,2)==-1) {
    nerror=3;            /* Error leyendo el fichero */
    return 0;
  }
  cad[2]='\0';
  return 1;
}

int getchar4(int f,char *cad)
/*
****************************************************************************
*  Se leen 4 caracteres del fichero especificado y se meten en la cadena   *
*  cad. Se devuelve 0 si se ha producido alg*n error.                      *
*****************************************************************************/
{
  if (read(f,cad,4)==-1) {
    nerror=3;            /* Error leyendo el fichero */
    return 0;
  }
  cad[4]='\0';
  return 1;
}

int getbyte(int f, byte *num)
/*
****************************************************************************
*  Leer un entero del fichero especificado. Se leen 2 digitos ASCII en     *
*  hexadecimal y se devuelve su valor entero.                              *
*                                                                          *
*   Se devuelve 0 si se ha producido un error.                             *
*   Se devuelve 1 en caso contrario.                                       *
*                                                                          *
*****************************************************************************/
{
  char cad[3];

  if (getchar2(f,cad)==0) {  /* Error leyendo el fichero */
    nerror=3;
    return 0;
  };
  if (char2tobyte(cad,num)==0) {  /* Error al convertir los digitos */
       nerror=4;
       return 0;
  }

  return 1;
}

int getint(int f, unsigned int *num)
/*
****************************************************************************
*  Leer un entero del fichero especificado. Se leen 4 digitos ASCII en     *
*  hexadecimal y se devuelve su valor entero.                              *
*                                                                          *
*   Se devuelve 0 si se ha producido un error.                             *
*   Se devuelve 1 en caso contrario.                                       *
*                                                                          *
*****************************************************************************/
{
  char cad[5];

  if (getchar4(f,cad)==0) {
    nerror=3;                 /* Error leyendo el fichero */
    return 0;
  }
  if (char4toint(cad,num)==0) {
       nerror=4;              /* Error al convertir los digitos */
       return 0;
  }

  return 1;
}

int leertipo_reg(int f, byte *tipo)
/*
************************************************************************
*  Leer tipo de registro. Se devuelve en tipo un 1 si se trata de un   *
*  registro del tipo 1 y 9 en caso de que se trate de registro del     *
*  tipo 9.                                                             *
*                                                                      *
*  Modificacion: 20-Feb-2000. En el formato .S19 generado por el GCC   *
*   para el 6811 aparecen un nuevo tipo de registros, S0, cuyo         *
*   significado se desconoce.                                          *
*                                                                      *
*      Se devuelve 0 si ha habido alg*n error                          *
*      Se devuelve 1 si no ha habido errores                           *
*                                                                      *
*************************************************************************/
{
  char cad[3];

  if (getchar2(f,cad)==0) return 0;
  if (cad[0]!='S') {
    nerror=4;                           /* Error en tipo de registro */
    return 0;
  }
  if (cad[1]!='1' && cad[1]!='9' && cad[1]!='0') {
    nerror=4;                           /* Error en tipo de registro */
    return 0;
  }

  if (cad[1]=='0') *tipo=0;
  if (cad[1]=='1') *tipo=1;
  if (cad[1]=='9') *tipo=9;
  
  return 1;
}

void liberar_s19(S19 *ss19)
/*
************************************************************************
*  Liberar toda la memoria utilizada por el fichero s19 especificado   *
*************************************************************************/
{
  struct registros1 *punt;   /* Punteros a registros S19 */
  struct registros1 *borra;

  punt=ss19->cabeza;  /* Apuntar al comienzo de la lista */
  while(punt!=NULL){
    borra=punt;
    punt=punt->sig;   /* Apuntar al siguiente registro  */
    free(borra);      /* Borrar el registro actual      */
  }
}

byte calcular_crc(byte *bloque, int tam)
/***********************************************************************/
/* Calcular el CRC de un bloque de datos. Se utiliza un CRC de 8 bits  */
/***********************************************************************/
{
  int i;
  byte crc=0;
   
  for (i=0; i<tam; i++) {
    crc=(crc+bloque[i]);
  }
  crc=~crc;
  return crc;
}

int abrir_s19(char *fich,S19 *ss19,int modo)
/*
****************************************************************************
*  Abrir un fichero .S19 y crear una variable de tipo S19. Para trabajar   *
*  con cualquier fichero .S19 habra que abrirlo primero.                   *
*                                                                          *
*   PARAMETROS ENTRADA:                                                    *
*                                                                          *
*      - Fich: Nombre del fichero .S19 a abrir. Si se especifica sin       *
*              extension por defecto se toma extension.S19. Se puede       *
*              especificar la ruta completa del fichero.                   *
*                                                                          *
*      - Modo: Indica el modo de apertura del fichero. Existen dos modos   *
*                                                                          *
*              - Modo 1: Se comprueba el Checksum de todos los registros   *
*              - Modo 0: No se comprueba el checksum.                      *
*                                                                          *
*   PARAMETROS DE SALIDA:                                                  *
*                                                                          *
*      - ss19: Se devuelve una variable del tipo S19 que sera necesaria    *
*              para trabajar con el fichero abierto.                       *
*                                                                          *
*   La funcion devuelve 0 si no ha podido abrir el fichero porque se ha    *
*   producido algun error.                                                 *
*                                                                          *
*                                                                          *
*   Si el fichero ha sido abierto correctamente se devuelve un 1           *
*                                                                          *
*****************************************************************************/
{
  char cad[3];
  unsigned int dir;       /* Campo direccion           */
  unsigned int maxdir;	  /* Maxima direccion alcanzada*/
  byte tiporeg;           /* Campo tipo de registro    */
  byte tam;               /* Tamano campo codigo/datos */
  byte checksum;          /* Campo de checksum         */
  byte crc;               /* Checksum calculado        */
  byte codigo[37];        /* Campo de codigo/datos     */

  struct registros1 *nuevoreg;      /* Puntero a registro S1     */
  struct registros1 *regant;        /* Registro anterior         */

  unsigned int i;
  int fi;                 /* Descriptor del fichero de entrada   */

  crc=0;
  maxdir=0;
  ss19->nbytes=0;          /* Inicializar variable del tipo S19 */
  ss19->nreg=0;
  ss19->cabeza=NULL;
  nerror=0;                /* Inicialmente no hay errores     */

  /*---------- ABRIR EL FICHERO S19 -----*/

  extensions19(fich);  /* Si no tiene extension poner .S19 */
  if ((fi=open(fich,O_RDONLY))==-1) {
    nerror=1;                            /* Fichero no encontrado */
    liberar_s19(ss19);
    return 0;
  }
  /*------- LEER TIPO DE REGISTRO -------*/
  if (leertipo_reg(fi,&tiporeg)==0) {
    liberar_s19(ss19);                      /* Ha habido algun error */
    return 0;
  }
  
  /*------- REGISTROS DEL TIPO S0 ------ */
  /* Este registro suele aparecer al principio. No se sabe lo que significa */
  /* por tanto se elimina por completo... de momento                        */
  if (tiporeg==0) {
    do {
      if (read(fi,&cad[0],1)==-1) {
        liberar_s19(ss19);
        return 0;
      }
    } while (cad[0]!='\n');
    /* Registro S0 eliminado */
    /* Leer siguiente registro */
    if (leertipo_reg(fi,&tiporeg)==0) {
      liberar_s19(ss19);                      /* Ha habido algun error */
      return 0;
    }
  }
  
  while(tiporeg==1) {
    crc=0;
    /*-------- LEER CAMPO TAMANO ---------*/
    if (getbyte(fi,&tam)==0) {
      liberar_s19(ss19);
      return 0;
    }
    
    crc=tam;
    tam-=3; /* Quitar byte de checksum y 2 bytes de direccion    */

    /*-------- LEER CAMPO DIRECCION -------*/
    if (getint(fi,&dir)==0) {
      liberar_s19(ss19);
      return 0;
    }
    if (maxdir>dir){        /* comprobar si la dir. del nuevo reg. */
      nerror=7;             /* no se solapa con las anteriores      */
      liberar_s19(ss19);    /* Si es asi mensaje de error           */
      return 0;
    }
    maxdir=dir+tam;
    crc=crc + (byte)(dir & 0xFF) +
	      (byte)((dir>>8)&0xFF);

    /*-------- LEER CAMPO CODIGO/DATOS ----*/
    for (i=0; i<tam; i++) {
      if (getbyte(fi,&codigo[i])==0) {
	liberar_s19(ss19);
	return 0;
      }
      ss19->nbytes++;
      crc=crc+codigo[i];
    }

    /*-------- LEER CAMPO CRC ----------*/
    if (getbyte(fi,&checksum)==0) {
      liberar_s19(ss19);
      return 0;
    }
    crc= ~crc;
    if (modo==1 && crc!=checksum) {   /* Comprobar el CRC */
      nerror=5;                       /* Error de CRC     */
      liberar_s19(ss19);
      return 0;
    }
    
    /*-------- LEER CR Y LF ------------*/
    /* Modificacion realizada: 20 Feb-2000 para leer ficheros .S19  */
    /* Generados por el gcc para el 6811                            */
    /* Puebe haber solo LF o CR-LF */
    
    if (read(fi,&cad[0],1)==-1) {
      liberar_s19(ss19);
      return 0;
    }
    /* Si el caracter es CR hay un LF */
    if (cad[0]=='\r')  {
      if (read(fi,&cad[0],1)==-1) {
        liberar_s19(ss19);
        return 0;
      }
    }

    /* ------- CREAR EL NUEVO REGISTRO S1 LEIDO -------*/
    if ( (nuevoreg=(struct registros1 *)malloc(sizeof(struct registros1)))==NULL) {
      nerror=6;    /* No hay suficiente memoria */
      liberar_s19(ss19);
      return 0;
    }
    ss19->nreg++;
    nuevoreg->tam=tam;                /* Campo tama*o       */
    nuevoreg->dir=dir;                /* Campo direccion    */
    nuevoreg->crc=crc;
    for (i=0; i<tam; i++)             /* Campo c*digo/datos */
      nuevoreg->codigo[i]=codigo[i];
    nuevoreg->sig=NULL;
    if (ss19->nreg==1) ss19->cabeza=nuevoreg;  /* Cabeza de la lista */
    else regant->sig=nuevoreg;           /* Enlazar con registro anterior */
    regant=nuevoreg;

    /*------- LEER TIPO DE REGISTRO -------*/
    if (leertipo_reg(fi,&tiporeg)==0) {
      liberar_s19(ss19);                    /* Ha habido alg*n error */
      return 0;
    }
  }
  close(fi);
  return 1;
}

void cerrar_s19(S19 ss19)
/*
************************************************************************
*  Dejar de trabajar con el archivo S19 especificado. Se libera toda la*
*  memoria que se habia tomado.                                        *
*************************************************************************/
{
  liberar_s19(&ss19);    /* Liberar memoria               */
}


int leerdir_s19(S19 ss19,int nreg, unsigned int *dir)
/*
************************************************************************
*  Leer el campo direccion del fichero S19 especificado.               *
*                                                                      *
*                                                                      *
*  ENTRADAS:                                                           *
*                                                                      *
*       - ss19: Fichero S19 abierto con el que trabajar                *
*       - nreg: Numero del registro al que se quiere acceder           *
*                                                                      *
*  SALIDAS:                                                            *
*                                                                      *
*       - dir : Campo direccion del registro especificado              *
*                                                                      *
*      Se devuelve 0 en caso de que no exista el registro pedido.      *
*      Se devuelve 1 en caso de exito.                                 *
*************************************************************************/
{
  struct registros1 *punt;
  int reg;

  reg=1;      /* Comenzar la busqueda por el registro 1 */

  punt=ss19.cabeza;
  while(punt!=NULL) {
    if (reg==nreg) {
      *dir=punt->dir;
      return 1;
    }
    punt=punt->sig;
    reg++;
  }

  return 0;  /* Registro pedido no se encuentra */
}

int leercod_s19(S19 ss19,int nreg, byte *cod, byte *tam, byte *crc)
/*
************************************************************************
*  Leer el campo codigo/datos del registro especificado.               *
*                                                                      *
*  ENTRADAS:                                                           *
*                                                                      *
*     - ss19 : Fichero S19 abierto con el que trabajar                 *
*     - nreg : Numero del registro al que se quiere acceder            *
*                                                                      *
*  SALIDAS:                                                            *
*                                                                      *
*     - cod : Campo c*digo/datos del registro especificado             *
*     - tam : tama*o del campo codigo/datos                            *
*                                                                      *
*      Se devuelve 0 en caso de que no exista el registro pedido.      *
*      Se devuelve 1 en caso de exito.                                 *
*************************************************************************/
{
  struct registros1 *punt;
  int reg;
  int i;

  reg=1;

  punt=ss19.cabeza;
  while(punt!=NULL) {
    if (reg==nreg) {
      *tam=punt->tam;             /* Devolver tama*o       */
      *crc=punt->crc;             /* Devolver campo crc    */
      for (i=0; i<punt->tam; i++)
	cod[i]=punt->codigo[i];   /* Devolver codigo/datos */
      return 1;
    }
    punt=punt->sig;
    reg++;
  }
  return 0;
}

unsigned int getnbytes19(S19 ss19)
/*
************************************************************************
*  Devolver el numero de bytes de todo el codigo del fichero S19       *
*  especificado.                                                       *
*************************************************************************/
{
  return ss19.nbytes;
}

unsigned int getnregs19(S19 ss19)
/*
****************************************************************
*  Devolver el numero de registros del tipo 1 del fichero S19  *
*  especificado.                                               *
*****************************************************************/
{
  return ss19.nreg;
}

void s19toramint(S19 f,byte *ramint, byte *ramintoc)
/* ************************************************************************
   * Quedarse con la parte del programa .S19 comprendido entre las        *
   * direccion 0-255. El resto se desprecia.                              *
   *                                                                      *
   * Estas posiciones se introducen en la matriz ramint que debe tener    *
   * una capacidad minima de 256 posiciones.                              *
   *                                                                      *
   * En la matriz de ocupaci*n se indica con 0 las posiciones dentro de   *
   * la matriz ramint que no tienen codigo. Con 1 las posiciones que si   *
   * lo tienen.                                                           *
   *************************************************************************/
{
  unsigned int i,n;
  unsigned int dir;
  unsigned int nreg;
  byte codigo[37];
  byte tam;
  byte crc;

  nreg=getnregs19(f);

  for (i=0; i<=255; i++) {
    ramint[i]=0;
    ramintoc[i]=0;	      /* Inicialmente todas las posiciones vacias */
  }

  for (i=1; i<=nreg; i++) {
    leerdir_s19(f,i,&dir);
    leercod_s19(f,i,codigo,&tam,&crc);
    for (n=0; n<tam; n++) {
      if ((dir+n)<=0xFF) {
	ramint[dir+n]=codigo[n];    /* Guardar valor          */
	ramintoc[dir+n]=1;          /* Indicar posici*n llena */
      }
    }
  }
}

void s19toeeprom(S19 f,byte *eeprom, byte *eepromoc)
/* ************************************************************************
   * Quedarse con la parte del programa .S19 comprendido entre las        *
   * direccion $B600-$B7FF. El resto del programa se desprecia.           *
   *                                                                      *
   * Estas posiciones se introducen en la matriz eeprom que debe tener    *
   * una capacidad minima de 512 posiciones.                              *
   *                                                                      *
   * En la matriz de ocupaci*n se indica con 0 las posiciones dentro de   *
   * la matriz eeprom que no tienen codigo. Con 1 las posiciones que si   *
   * lo tienen.                                                           *
   *************************************************************************/
{
  unsigned int i,n;
  unsigned int dir;
  unsigned int ind;
  unsigned int nreg;
  byte codigo[37];
  byte tam;
  byte crc;

  nreg=getnregs19(f);

  for (i=0; i<=511; i++)
    eepromoc[i]=0;         /* Inicialmente matriz eeprom desocupada */

  for (i=1; i<=nreg; i++) {
    leerdir_s19(f,i,&dir);
    leercod_s19(f,i,codigo,&tam,&crc);
    for (n=0; n<tam; n++) {
      if ((dir+n)<=0xB7FF) {
	ind=dir-0xB600;
	eeprom[ind+n]=codigo[n];    /* Guardar valor     */
	eepromoc[ind+n]=1;	    /* Indicar ocupaci*n */
      }
    }
  }
}

int check_eeprom(S19 fs19, int *ov)
/* ************************************************************************
   * Comprobar si el archivo S19 especificado tiene todas sus direcciones *
   * dentro de los 512 bytes de la EEPROM.                                *
   *                                                                      *
   *  Se devuelve 1 en caso de que sea programa para la EEPROM            *
   *  Se devuelve 0 en caso contrario.                                    *
   *                                                                      *
   *   Si es un programa para la EEPROM pero la desborda se indica con    *
   *   un 1 en ov. 0 en caso de no desbordamiento.                        *
   *************************************************************************/
{
  unsigned int i;
  unsigned int dir;
  unsigned int nreg;
  byte codigo[37];
  byte tam;
  byte crc;

  nreg=getnregs19(fs19);

  if (nreg==0) {   /* *Fichero S19 sin registros? */
    *ov=0;
    return 1;
  }

  leerdir_s19(fs19,1,&dir);
  if (dir<0xB600 || dir>0xB7FF) {  /* Programa NO es para la EEPROM */
    return 0;
  }

  for (i=2; i<=nreg; i++) {
    leerdir_s19(fs19,i,&dir);
    leercod_s19(fs19,i,codigo,&tam,&crc);
    if ( (dir+tam-1)>0xB7FF) {
      *ov=1;                /* Programa desborda la EEPROM */
      return 1;
    }
  }
  *ov=0;
  return 1;                 /* Programa es para la EEPROM */
}


int check_ramint(S19 fs19, int *ov)
/* ************************************************************************
   * Comprobar si el archivo S19 especificado tiene todas sus direcciones *
   * dentro de los 256 bytes de la RAM interna.                           *
   *                                                                      *
   *  Se devuelve 1 en caso de que sea programa para la RAM interna       *
   *  Se devuelve 0 en caso contrario.                                    *
   *                                                                      *
   *   Si es un programa para la RAM interna pero la desborda se indica   *
   *  con un 1 en ov. 0 en caso de no desbordamiento.                     *
   *************************************************************************/
{
  int i;
  unsigned int dir;
  unsigned int nreg;
  byte codigo[35];
  byte tam;
  byte crc;

  nreg=getnregs19(fs19);

  if (nreg==0) {   /* *Fichero S19 sin registros? */
    *ov=0;
    return 1;
  }

  leerdir_s19(fs19,1,&dir);
  if (dir>0xFF) {           /* Programa NO es para la RAM interna */
    return 0;
  }

  for (i=2; i<=nreg; i++) {
    leerdir_s19(fs19,i,&dir);
    leercod_s19(fs19,i,codigo,&tam,&crc);
    if ( (dir+tam)>0xFF) {
      *ov=1;                /* Programa desborda la ram interna */
      return 1;
    }
  }
  *ov=0;
  return 1;                 /* Programa es para la RAM interna */
}

int situacion_progs19(S19 fs19, int *ov)
/* ************************************************************************
   * Comprobar la situaci*n del programa: RAM interna, EEPROM o RAM       *
   * externa.                                                             *
   * En ov se devuelve si ha habido desbordamiento de la eeprom o ram     *
   * interna.                                                             *
   *                                                                      *
   *  La funci*n devuelve 1 : Programa para RAM interna                   *
   *                      2 : Programa para EEPROM                        *
   *                      3 : Programa para RAM externa.                  *
   *************************************************************************/
{
  if (check_ramint(fs19,ov)==1) return 1;  /* Programa para RAM interna */
  if (check_eeprom(fs19,ov)==1) return 2;  /* Programa para EEPROM      */

  return 3;   /* Programa para RAM externa */
}

void raminttoc(byte *ramint, char *cadc)
/* ************************************************************************
   * Tomar la matriz ramint que contiene un programa para la RAM interna  *
   * y devolver en el array cadc la cadena que representa la misma        *
   * matriz pero definida en C.                                           *
   *************************************************************************/
{
  char cad[3];
  int i;
  int n;

  strcpy(cadc,"byte programint[256]={\n");

  n=1;
  for (i=0; i<=255; i++) {
    strcat(cadc,"0x");
    bytetochar2(ramint[i],cad);
    cad[2]=0;
    strcat(cadc,cad);
    strcat(cadc,",");
    n++;
    if (n==16) {
      strcat(cadc,"\n");
      n=1;
    }
  }
  strcat(cadc,"};");
}
