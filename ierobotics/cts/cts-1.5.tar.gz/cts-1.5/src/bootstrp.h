/**************************************************************************/
/* BOOTSTRP.H  (c) MICROBOTICA, S.L. ENERO 2000                           */
/*------------------------------------------------------------------------*/
/* web: www.microbotica.es                                                */
/* mail: info@microbotica.es                                              */
/**************************************************************************/

#ifndef BOOTSTRP_H
#define BOOTSTRP_H

#include "s19.h"

#ifndef BYTE
  #define BYTE
  typedef unsigned char byte;
#endif

#ifndef ON
  #define ON  1
  #define OFF 0
#endif

/*			 **************************
**************************   I N T E R F A Z      ***********************
			 **************************                      */


/* ---------------------- PROTOTIPOS ---------------------------------- */

void set_break_timeout(unsigned long timeout);
void set_eco_checking(byte eco);
void resetct6811();
int okreset();        
int jump_eeprom();
int jump_ram();
int cargar_ramint(byte *ramint, void (*car)());
int cargars19_ramint(S19 fs19, void (*car)());
char *getloaderror();


/* ----------------------- DESCRIPCION -------------------------------- */

/*

void set_break_timeout(unsigned long timeout);
****************************************************************
* Cambiar el valor del timeout para recibir la senal de BREAK  *
****************************************************************

void set_eco_checking(byte eco);
*********************************************************************
* Cambiar el estado de la comprobacion del eco al cargar programas  *
* Si se realiza carga en la CTNET sera necesario DESACTIVAR EL ECO  *
*  Por defecto se encuentra activo.                                 *
*********************************************************************

void resetct6811();
**************************************
*  Realizar un reset de la CT6811.   *
***************************************

int okreset();
************************************************************************
*  Realizar un reset de la CT6811 y esperar la senal de BREAK          *
*  correspondiente. Si no se recibe dentro del plazo establecido la    *
*  funcion devuelve 0. 1 en caso de recibirse el BREAK.                *
************************************************************************

int jump_eeprom();
************************************************
*  Saltar a la memoria EEPROM. La funcion de-  *
*  vuelve 1 si se ha recibido el BREAK y se ha *
*  saltado correctamente. En caso de no reci-  *
*  bir el BREAK se devuelve 0.                 *
************************************************

int jump_ram();
************************************************
*  Saltar a la direcci*n $0000 de la memoria.  *
*  La funcion devuelve 1 si se ha recibido el  *
*  BREAK y se ha saltado correctamente a la    *
*  RAM. En caso de no recibir el BREAK se      *
*  devuelve 0.                                 *
************************************************

int cargar_ramint(byte *ramint, void (*car)());
************************************************************************
*  Enviar el programa especificado por la matriz ramint a la tarjeta   *
*  CT6811. Cada vez que se ha enviado un byte de codigo se llama a la  *
*  funcion car.                                                        *
*                                                                      *
*    La funcion devuelve 1 si no se ha producido ningun error. Se      *
*  devuelve 0 en caso de error. Si se ha producido un error con la     *
*  funcion getloaderror se devuelve la cadena que indica el error.     *
*                                                                      *
*    ES NECESARIO QUE SE HAYA ABIERTO EL PUERTO SERIE ANTES DE ENVIAR  *
*  CUALQUIER PROGRAMA.                                                 *
*                                                                      *
************************************************************************

int cargars19_ramint(S19 fs19, void (*car)());
************************************************************************
*  Enviar el fichero .S19 especificado a la tarjeta CT6811. El         *
*  fichero debe estar preparado para la ram interna. Cada vez que se   *
*  envia un caracter se llama a la funcion car.                        *
*                                                                      *
*    La funcion devuelve 1 si no se ha producido ningun error. Se      *
*  devuelve 0 en caso de error. Si se ha producido un error con la     *
*  funcion getloaderror se devuelve la cadena que indica el error.     *
*                                                                      *
*    ES NECESARIO QUE SE HAYA ABIERTO EL PUERTO SERIE ANTES DE ENVIAR  *
*  CUALQUIER PROGRAMA.                                                 *
*                                                                      *
************************************************************************

char *getloaderror();
****************************************************************************
*  Devolver la cadena del error producido en la ultima carga de programas  *
*  en la RAM interna                                                       *
****************************************************************************

*/

#endif  /* del define BOOTSTRP_H */
