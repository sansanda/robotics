/******************************************************************/
/* ASCBIN.H    (c) MICROBOTICA, S.L.  ENERO 2000                  */
/*----------------------------------------------------------------*/
/* web: www.microbotica.es                                        */
/* mail: info@microbotica.es                                      */
/******************************************************************/

#ifndef ASCBIN_H
#define ASCBIN_H

#ifndef BYTE
  #define BYTE
  typedef unsigned char byte;
#endif

/* ------------------------- PROTOTIPOS --------------------------- */
  
int char1tobyte(char car,byte *dec);
int char2tobyte(char *cad,byte *dec);
int char4toint(char *cad,unsigned int *dec);

int bytetochar1(byte num, char *car);
int bytetochar2(byte num, char *cad);
int inttochar4(long num, char *cad);


/* ------------------------ DESCRIPCION ------------------------- */
/*
   * int char1tobyte(char car,byte *dec);
     Se toma una caracter hexadecimal en ASCII y se convierte a un numero   
    entero.                                                                
                                                                         
    EJ: char1tobyte('A',&x);  Se convertiria el digito ASCII 'A' en el   
                              numero 10 que se devolveria en x.          
    Se devuelve 0 si el caracter no es un digito en hexadecimal          
    Se devuelve 1 en caso contrario.                                     
                                                                         
   * int char2tobyte(char *cad,byte *dec);
    Se toma una cadena con dos digitos hexadecimales ASCII y los convierte 
    en un n*mero entero de 8 bits                                          
                                                                         
    Ej: char2tobyte("FF",&x);  Se convierte la cadena "FF" en el numero    
                               255 que se devuelve en x.                   
    Se devuelve 0 si algun digito no esta en hexadecimal.                
    Se devuelve 1 en caso contrario.                                     
                                                                         
   * int char4toint(char *cad,unsigned int *dec);
     Se toma una cadena con 4 digitos hexadecimales ASCII y los convierte   
     en un numero entero de 16bits                                          
                                                                         
     Ej. char4toint("123C",&x); Se convierte la cadena "123C" en el numero  
                                4668 que se devuelve en x.                  
                                                                         
     Se devuelve 0 si algun digito no esta en hexadecimal.                
     Se devuelve 1 en caso contrario.                                     
                                                                         
   * int bytetochar1(byte num, char *car);
     Convertir un numero entre 0-15 a caracteres hexadecimales en ASCII     
                                                                         
     Ej. bytetochar1(12,cad);  Se convierte el numero 12 a la cadena "C"    
                               que se devuelve en cad                       
     Se devuelve un 1 si se ha realizado correctamente la conversion.       
     Se devuelve un 0 en caso contrario.                                    

   * int bytetochar2(byte num, char *cad);
     Convertir un numero entre 0-255 a 2 caracters ASCII hexadecimales.    
                                                                           
     Ej. bytetochar2(127,cad); Se convierte el numero 127 en la cadena "7F"
                               que se devuelve en cad                      
     Se devuelve un 1 si se ha realizado correctamente la conversion.      
     Se devuelve un 0 en caso contrario.                                   
                                                                         
   * int inttochar4(long num, char *cad);
     Convertir un n*mero entre 0-65535 a 4 caracters ASCII hexadecimales.  
                                                                         
     Ej. inttochar4(14563,cad); Se convierte el numero 14563 en la cadena  
                                "38E3" que se devuelve en cad              
                                                                         
     Se devuelve un 1 si se ha realizado correctamente la conversion.      
     Se devuelve un 0 en caso contrario.                                   
   
*/    

#endif  /* del define ASCBIN_H */                                               
                 
