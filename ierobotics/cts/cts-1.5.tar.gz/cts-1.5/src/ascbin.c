/****************************************************************************/
/* ASCBIN.C    (c) MICROBOTICA, S.L. ENERO 2000                             */
/****************************************************************************/
/*   Rutinas para la conversion de digitos ASCII a numeros binarios y       */
/* viceversa.                                                               */
/*--------------------------------------------------------------------------*/
/* web: www.microbotica.es                                                  */
/* mail: info@microbotica.es                                                */
/****************************************************************************/

#include "ascbin.h"

/*			 **************************
**************************   I N T E R F A Z      ***********************
			 **************************                       */

/*  Lista de todas las funciones de interfaz :

int char1tobyte(char car,byte *dec);
int char2tobyte(char *cad,byte *dec);
int char4toint(char *cad,unsigned int *dec);

int bytetochar1(byte num, char *car);
int bytetochar2(byte num, char *cad);
int inttochar4(long num, char *cad);

*/

/*		   ********************************
******************** I M P L E M E N T A C I O N  ***********************
		   ********************************                      */

int char1tobyte(char car,byte *dec)
/*
***************************************************************************
*  Se toma una caracter hexadecimal en ASCII y se convierte a un numero   *
*  entero.                                                                *
*                                                                         *
*    Se devuelve 0 si el caracter no es un digito en hexadecimal          *
*    Se devuelve 1 en caso contrario.                                     *
*                                                                         *
****************************************************************************/
{
  if (car>='0' && car<='9')
      *dec=car-'0';
  else if (car<='F' && car>='A')
      *dec=car-'A'+10;
       else return 0;     /*  El digito no esta en hexadecimal  */

  return 1;		  /*  No ha habido errores              */
}

int char2tobyte(char *cad,byte *dec)
/*
***************************************************************************
*  Se toma una cadena con dos digitos hexadecimales ASCII y los convierte *
*  en un n*mero entero de 8 bits                                          *
*                                                                         *
*    Se devuelve 0 si algun digito no esta en hexadecimal.                *
*    Se devuelve 1 en caso contrario.                                     *
*                                                                         *
****************************************************************************/
{
  unsigned char num1,num2;

  if (char1tobyte(cad[0],&num1))  /* Si se convierte bien el primer digito */
    if (char1tobyte(cad[1],&num2)){/* y se convierte bien el segundo...    */
      *dec=num1*16+num2;           /* Se calcula en numero en decimal      */
      return 1;
    }
  return 0;           /* Ha habido algun error en la conversi*n */
}


int char4toint(char *cad,unsigned int *dec)
/*
***************************************************************************
*  Se toma una cadena con 4 digitos hexadecimales ASCII y los convierte   *
*  en un n*mero entero de 16bits                                          *
*                                                                         *
*    Se devuelve 0 si algun digito no esta en hexadecimal.                *
*    Se devuelve 1 en caso contrario.                                     *
*                                                                         *
****************************************************************************/
{
  unsigned char num1,num2;

  if (char2tobyte(&cad[0],&num1))     /* Si se convierten bien 1er par de dig */
    if (char2tobyte(&cad[2],&num2)) { /* Y se convierten bien el 2o par..     */
      *dec=num1*256 + num2;         /* Calcular numero decimal resultante   */
      return 1;
    }

  return 0;        /* Error en la conversion */
}


int bytetochar1(byte num, char *car)
/*
***************************************************************************
*  Convertir un numero entre 0-15 a caracteres hexadecimales en ASCII     *
*                                                                         *
*  Se devuelve un 1 si se ha realizado correctamente la conversion.       *
*  Se devuelve un 0 en caso contrario.                                    *
*                                                                         *
****************************************************************************/
{
  if (num>15) return 0;
  if (num<10)
    *car='0'+num;
  else
    *car='A'-10+num;

  return 1;
}

int bytetochar2(byte num, char *cad)
/**************************************************************************
  * Convertir un numero entre 0-255 a 2 caracters ASCII hexadecimales.    *
  *                                                                       *
  * Se devuelve un 1 si se ha realizado correctamente la conversion.      *
  * Se devuelve un 0 en caso contrario.                                   *
  *                                                                       *
  **************************************************************************/
{
  if (bytetochar1(num>>4,&cad[0])==0)    return 0;  /* Digito mayor peso */
  if (bytetochar1(num & 0xF,&cad[1])==0) return 0;  /* Digito menor peso */
  cad[2]=0;
  return 1;
}

int inttochar4(long num, char *cad)
/**************************************************************************
  * Convertir un n*mero entre 0-65535 a 4 caracters ASCII hexadecimales.  *
  *                                                                       *
  * Se devuelve un 1 si se ha realizado correctamente la conversion.      *
  * Se devuelve un 0 en caso contrario.                                   *
  *                                                                       *
  **************************************************************************/
{
  if (bytetochar2(num>>8,cad)==0) return 0;
  if (bytetochar2(num&0xFF,&cad[2])==0) return 0;
  cad[4]=0;
  return 1;
}

