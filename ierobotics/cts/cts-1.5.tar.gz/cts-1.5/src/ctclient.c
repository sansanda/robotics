/****************************************************************************/
/* CTCLIENT.C  (c) MICROBOTICA S.L.       ENERO 2000                        */
/*--------------------------------------------------------------------------*/
/* web: www.microbotica.es                                                  */
/* mail: info@microbotica.es                                                */
/*--------------------------------------------------------------------------*/
/****************************************************************************/

#include "serie.h"
#include "ctclient.h"

/*			 **************************
**************************   I N T E R F A Z      ***********************
			 **************************                      */

/* RESUMEN DEL INTERFAZ:       

  int load(byte *valor, uint dir)
  int load_block(byte *buff, uint tam, uint dir, void (*reccar)());
  void store(byte valor, uint dir);
  void store_block(byte *buff, uint tam, uint dir, void (*sendcar)());
  int store_block_eeprom(byte *buff, uint tam, uint dir, void (*eeprcar)());
  int check_conexion();
  void execute(uint dir);
  int hay_conexion();

*/

/*		   ********************************
******************** I M P L E M E N T A C I O N  ***********************
		   ********************************                      */

#define TIMEOUT   500000
#define EETIMEOUT 500000

static int conexion = 0;

int load(byte *valor, uint dir)
/*************************************************************************
  * Leer un byte de la direccion de memoria especificada. La funcion     *
  * devuelve 0 si el CTSERVER no responde. 1 en caso contrario.          *
  *************************************************************************/
{
  byte trama[5];
  int timeout;

  if (!conexion) return 0;

  trama[0]='A';
  trama[1]=(byte) (dir & 0xFF);       /* Byte bajo direccion    */
  trama[2]=(byte) (dir>>8 & 0xFF);    /* Byte alto direccion    */
  trama[3]=1;                         /* Byte bajo tamano datos */
  trama[4]=0;                         /* Byte alto tamano datos */
  enviar_bloque(trama,5);    /* Enviar cabecera de la trama     */
  while (bufftx_waiting());  /* Esperar a que se envie la trama */

  /* --- Recibir la informacion solicitada -- */
  *valor=leer_car_plazo(TIMEOUT,&timeout);
  if (timeout==1) {
    conexion=NO;
    return 0;         /* El servidor no responde */
  }
  conexion=SI;
  return 1;
}

int load_block(byte *buff, uint tam, uint dir, void (*reccar)())
/*************************************************************************
  * Recibir un bloque de datos desde el 68HC11. El bloque tiene un       *
  * tama*o tam y comienza a partir de la direccion dir. El bloque reci-  *
  * bido se situa en el buffer buff. Cada vez que se recibe un byte se   *
  * llama al procedimiento reccar pasado como parametro.                 *
  *                                                                      *
  *   La funcion devuelve un 0 si el CTSERVER no responde. Se env*a un   *
  * 1 si la operacion se ha realizado con exito.                         *
  *                                                                      *
  *************************************************************************/
{
  byte trama[5];
  int i;
  int timeout;

  if (!conexion) return 0;

  trama[0]='A';
  trama[1]=(byte) (dir & 0xFF);
  trama[2]=(byte) (dir>>8 & 0xFF);
  trama[3]=(byte) (tam & 0xFF);
  trama[4]=(byte) (tam>>8 & 0xFF);

  enviar_bloque(trama,5);    /* Enviar cabecera de la trama     */
  while (bufftx_waiting());  /* Esperar a que se envie la trama */

  /* --- Recibir la informacion solicitada -- */
  i=0;                
  while (tam>0) {
    buff[i]=leer_car_plazo(TIMEOUT,&timeout);
    if (timeout==1) {
      conexion=NO;
      return 0;         /* El servidor no responde */
    }
    (*reccar)();
    i++;
    tam--;
  }
  conexion=SI;
  return 1;
}

void store(byte valor, uint dir)
/**********************************************************
  * Enviar el byte especificado en la direccion indicada. *
  **********************************************************/
{
  byte trama[6];

  if (!conexion) return;

  /* -- Generar la trama a enviar -- */
  trama[0]='B';                      /* Codigo servicio          */
  trama[1]=(byte) (dir & 0xFF);      /* Byte bajo direccion      */
  trama[2]=(byte) (dir>>8 & 0xFF);   /* byte alto direccion      */
  trama[3]=1;                        /* Byte bajo tamano bloque  */
  trama[4]=0;                        /* Byte alto tamano bloque  */
  trama[5]=valor;
  enviar_bloque(trama,6);            /* Enviar trama */
}


void store_block(byte *buff, uint tam, uint dir, void (*envcar)())
/*************************************************************************
  * Enviar un bloque de datos desde el PC al 68HC11. El bloque se encuen-*
  * tran en el buffer buff, que tiene un tamano tam. El bloque se debe   *
  * situar a patir de la direccion indicada.                             *
  *                                                                      *
  * Cada vez que se envia un byte se llama a procedimiento sendcar pasado*
  * como argumento.                                                      *
  *                                                                      *
  *************************************************************************/
{
  byte trama[5];
  int i;

  if (!conexion) return;

  trama[0]='B';
  trama[1]=(byte) (dir & 0xFF);
  trama[2]=(byte) (dir>>8 & 0xFF);
  trama[3]=(byte) (tam & 0xFF);
  trama[4]=(byte) (tam>>8 & 0xFF);
  enviar_bloque(trama,5);    /* Enviar cabecera de la trama     */
  /* --- Enviar datos -- */
  i=0;                
  while (tam>0) {
    enviar_car(buff[i]);
    (*envcar)();
    i++;
    tam--;
  }
  while (bufftx_waiting());  /* Esperar a que se envie la trama */
  return;
}


int store_block_eeprom(byte *buff, uint tam, uint dir, void (*eeprcar)())
/************************************************************************/
/* Grabar un bloque de datos en la memoria EEPROM.  El bloque se encuen-*/
/* tran en el buffer buff, que tiene un tama*o tam. El bloque se debe   */
/* situar a patir de la direccion indicada.                             */
/*                                                                      */
/* Cada vez que se envia un byte se llama a procedimiento eepromcar     */
/* pasado como argumento.                                               */
/*                                                                      */
/*   La funcion devuelve 0 si ha ocurido algun error. Devuelve 1 en     */
/* caso de exito.                                                       */
/*                                                                      */
/*************************************************************************/
{
  byte trama[5];
  int i;
  int timeout;
  byte c;

  if (!conexion) return 0;

  trama[0]='E';
  trama[1]=(byte) (dir & 0xFF);
  trama[2]=(byte) (dir>>8 & 0xFF);
  trama[3]=(byte) (tam & 0xFF);
  trama[4]=(byte) (tam>>8 & 0xFF);
  enviar_bloque(trama,5);

  i=0;                /* Enviar bloque solicitado */
  while (tam>0) {
    enviar_car(buff[i]);
    while (bufftx_waiting()); /* Esperar hasta que sea enviado */
    c=leer_car_plazo(EETIMEOUT,&timeout); /* Leer el eco */
    if (timeout==1) {
      conexion=NO;
      return 0;                /* Error: CTSERVER no responde */
    }  
    if (c!=buff[i]) {
      conexion=NO;
      return 0;               /* Error: Eco incorrecto       */
    }  
    (*eeprcar)();
    i++;
    tam--;
  }
  conexion=SI;
  return 1;
}

int check_conexion()
/*************************************************************************/
/* Comprobar si existe conexion con el servidor CTSERVER.                */
/*                                                                       */
/* Se devuelve:                                                          */
/*           0 --> Servidor no responde                                  */
/*           1 --> El servidor ha respondido                             */
/*************************************************************************/
{
  int timeout;
  char c;

  enviar_car('D');            /* Solicitar servicio de supervivencia */
  while (bufftx_waiting());   /* Esperar a que buffer de TX se vacie */
  c=leer_car_plazo(TIMEOUT,&timeout);   /* Esperar respuesta */
  if (timeout==1 || c!='J') {
    conexion=NO;              /* El servidor no responde o lo hace mal */
    return 0;
  }
  else {
    conexion=SI;    /* Servidor ha respondido correctamente */
    return 1;
  }
}

void execute(uint dir)
/************************************************************************/
/* Llamar al servicio de salto y ejecucion del servidor CTSERVER.       */
/************************************************************************/
{
  byte trama[3];

  trama[0]='C';
  trama[1]=(byte) (dir & 0xFF);
  trama[2]=(byte) (dir>>8 & 0xFF);
  enviar_bloque(trama,3);
}

int hay_conexion()
/*************************************************************************/
/* Devolver estado conexion de la ultima comunicacion con CTSERVER       */
/*************************************************************************/
{
  return conexion;
}
