/**************************************************************************/
/* VIEWS19C.C  (c) GRUPO J&J. Febrero 1998.                               */
/**************************************************************************/
/*                                                                        */
/* Programa para convertir archivos .S19 para la RAM INTERNA en su        */
/* representacion como una matriz de 256 bytes en C.                      */
/*                                                                        */
/*------------------------------------------------------------------------*/
/* web: www.microbotica.es                                                */
/* mail: info@microbotica.es                                              */
/**************************************************************************/

#include "stdio.h"
#include "s19.h"

int main(void)
{
  char cad[80];
  char *caderror;
  char cadc[1350];
  byte ramint[256];
  byte ramintoc[256];
  S19 mi_s19;
  
  printf ("\nNombre fichero: ");
  scanf("%s",cad);
  if (abrir_s19(cad,&mi_s19,1)==0) {   /* Si se ha producido un error */
    caderror=(char *)geterrors19();    /* Leer la cadena de error     */
    printf ("Error: %s\n",caderror);   /* Imprimir mensaje de error   */
    return 0;
  }
  printf ("\n");

  s19toramint(mi_s19,ramint,ramintoc);
  raminttoc(ramint,cadc);
  printf ("%s\n",cadc);

  cerrar_s19(mi_s19);
  return 0;
}
