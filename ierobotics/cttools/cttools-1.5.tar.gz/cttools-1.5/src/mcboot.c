/*******************************************************************/
/*  MCBOOT.C  (C) Juan Gonzalez  ENERO 2000                        */
/* --------------------------------------------------------------- */
/* Terminal de comunicaciones para la tarjeta CT6811               */
/*******************************************************************/

#include <stdlib.h>
#include <stdio.h>   
#include <unistd.h>  
#include <curses.h>
#include <string.h>

#include <cts/serie.h>
#include <cts/s19.h>
#include <cts/bootstrp.h>

#include "io.h"

#define ESC 27
#define NO 0
#define SI 1

#define ON  1
#define OFF 0


const char version[] = {"1.5.0"};
const char fecha[] = {"Julio 2004"};

WINDOW *s1;   /* Ventana para el terminal */
WINDOW *ri;   /* Ventana para la carga en la ram interna */

int puerto;   /* Puerto de comunicaciones */
int vbaud;    /* Velocidad de transmision */
int vdtr;     /* Valor del DTR            */
int fin;
int bs;       /* Bytes enviados */
int cont;     /* Contador */
int posx;


void presenta()
{
  erase();
  init_pair(1,COLOR_YELLOW,COLOR_BLACK);
  init_pair(2,COLOR_RED,COLOR_BLACK);
  init_pair(3,COLOR_CYAN,COLOR_BLACK);
  init_pair(4,COLOR_GREEN,COLOR_BLACK);
  init_pair(5,COLOR_BLUE,COLOR_BLACK);
  init_pair(6,COLOR_WHITE,COLOR_BLACK);
  init_pair(7,COLOR_WHITE,COLOR_BLUE);
  init_pair(8,COLOR_WHITE,COLOR_RED);
  init_pair(9,COLOR_GREEN,COLOR_BLUE);
  init_pair(10,COLOR_YELLOW,COLOR_BLUE);
  init_pair(11,COLOR_RED,COLOR_BLUE);
  
  /* Barra superior del MCBOOT */
  attrset(COLOR_PAIR(1)|A_BOLD);
  printw("MC-BOOT ");
  attrset(COLOR_PAIR(2)|A_BOLD);
  printw(version);
  attrset(COLOR_PAIR(3)|A_BOLD);
  printw(" IEAROBOTICS, ");
  printw(fecha);
  attrset(COLOR_PAIR(5)|A_BOLD);
  move(1,0); hline(0,80);
  move(22,0); hline(0,80);
  
  /* Menu del Mcboot */
  attrset(COLOR_PAIR(4) |A_BOLD); mvprintw(23,0,"ALT-X");
  attrset(COLOR_PAIR(3) |A_BOLD); printw("-Terminar  ");
  attrset(COLOR_PAIR(4) |A_BOLD); printw("F1");
  attrset(COLOR_PAIR(3) |A_BOLD); printw("-Bootstrap  ");
  attrset(COLOR_PAIR(6) ); printw("F2");
  attrset(COLOR_PAIR(6) ); printw("-Expandido  ");
  attrset(COLOR_PAIR(6) ); printw("F3");
  attrset(COLOR_PAIR(6) ); printw("-GAIA  ");
  attrset(COLOR_PAIR(4) |A_BOLD); printw("F4");
  attrset(COLOR_PAIR(3) |A_BOLD); printw("-Puerto ");
  attrset(COLOR_PAIR(4) |A_BOLD); printw("F5");
  attrset(COLOR_PAIR(3) |A_BOLD); printw("-Baudios ");
  move(24,0);
  attrset(COLOR_PAIR(6) ); printw("F6");
  attrset(COLOR_PAIR(6) ); printw("-Volcar       ");
  attrset(COLOR_PAIR(4) |A_BOLD); printw("F7");
  attrset(COLOR_PAIR(3) |A_BOLD); printw("-DTR ON/OFF ");
  refresh();
}

void inicializar_crt()
/*****************************************/
/*  Configurar las ncurses para trabajar */
/*****************************************/
{
  initscr();
  start_color();
  noecho(); raw();
}

void crear_terminal()
/*******************************************/
/* Crear la ventana de terminal del MCBOOT */
/*******************************************/
{
  s1=newwin(20,80,2,0);
  wattrset(s1,COLOR_PAIR(6)); 
  scrollok(s1,TRUE);
  wrefresh(s1);
}

void display_com(int puerto)
/**********************************/
/*  Imprimir el puerto actual     */
/**********************************/
{  
  attrset(COLOR_PAIR(6) | A_BOLD);
  mvprintw(0,49,"COM%u",puerto+1);
  refresh();
}

void display_baudios(int vel)
/*********************************/
/* Imprimir la velocidad actual  */
/*********************************/
{
  attrset(COLOR_PAIR(6) | A_BOLD);
  mvprintw(0,69,"%u",vbaud);
  refresh();
}

void display_dtr(int vdtr)
/********************************/
/* Imprimir el estado del DTR   */
/********************************/
{
  if (vdtr==ON) {
    attrset(COLOR_PAIR(2) | A_BOLD);
    mvprintw(0,57,"DTR ON ");
  }
  else {
    attrset(COLOR_PAIR(5) | A_BOLD);
    mvprintw(0,57,"DTR OFF");
  }
  refresh();
}

void cambiar_dtr()
/********************************************************/
/* Cambiar el estado del dtr y visualizarlo en pantalla */
/********************************************************/
{
  if (vdtr==ON) {
    vdtr=OFF;
    dtr_off();
  }  
  else {
    vdtr=ON;
    dtr_on();
  }  
  display_dtr(vdtr);
}

void cambiar_velocidad()
/*****************************************************************/
/*  Cambiar rotativamente la velocidad y visulizarla en pantalla */
/*****************************************************************/
{
  switch(vbaud) {
    case 9600: vbaud=1200; break;
    case 7680: vbaud=9600; break;
    case 1200: vbaud=7680; break;
    default: vbaud=9600;
  }
  baudios(vbaud);
  display_baudios(vbaud);
  vdtr=OFF; dtr_off();
  display_dtr(vdtr);
  
}

void cambiar_puerto()
/*****************************************************************/
/*  Cambiar rotativamente el puerto y visulizarlo en pantalla */
/*****************************************************************/
{
  cerrar_puerto_serie();
  switch(puerto) {
    case COM1: puerto=COM2; break;
    case COM2: puerto=COM1; break;
    default: puerto=COM2;
  }
  abrir_puerto_serie(puerto);
  display_com(puerto);
  vdtr=OFF; dtr_off();
  display_dtr(vdtr);
}

void error(int y,int x, char *cad)
{
  WINDOW *ve;
  int longi;
  int i;
  
  if (strlen(cad)>76) longi=76;
  else longi=strlen(cad)+4;
  
  ve=newwin(3,longi,y,x);
  wattrset(ve,COLOR_PAIR(8)); 
  box(ve,0,0);
  wmove(ve,1,1);
  for (i=0; i<longi-2; i++) {
    wprintw(ve," ");
  }
  mvwprintw(ve,1,2,"%s",cad);
  touchwin(ve);
  wrefresh(ve);
  io_getch();
  
  delwin(ve);
}

void accion_ri()
{
  if (cont==16 || bs==255) {
    cont=0;
    mvwprintw (ri,6,posx,"*");
    wrefresh(ri);
    posx++;
  }
  bs++;
  cont++;
}

void ram_interna()
/*********************************************************/
/*  Cargar programa en la RAM interna                    */
/*********************************************************/
{
  int i;
  char cad[30];
  int ok=0;
  S19 fs19;
  char *caderror;
  char caderror2[80];
  int ov;
  
  ri=newwin(11,40,2,5);
  wattrset(ri,COLOR_PAIR(7)); 
  wmove(ri,1,0);
  for (i=0; i<11; i++) {
    wprintw(ri,"                                        ");
  }
  
  box(ri,0,0);
  wmove(ri,1,1);
  
  wprintw(ri," Carga de programas en la RAM interna");
  do {
    wattrset(ri,COLOR_PAIR(9) | A_BOLD);
    mvwprintw(ri,3,2,"Fichero: ");
    wattrset(ri,COLOR_PAIR(7));
    wrefresh(ri);
    echo();  
    cad[0]=0;
    wscanw(ri,"%12s",cad);
    noecho();
    if (cad[0]==0) {  /* Abortado por el usuario */
      mvwprintw(ri,8,4,"Abortado");
      wrefresh(ri);
      usleep(500000);
      touchwin(s1);
      delwin(ri);
      return;
    }  
    if ((ok=abrir_s19(cad,&fs19, 1))==0) {
      caderror=(char *)geterrors19();
      sprintf (caderror2,"Error: %s",caderror);
      mvwprintw(ri,3,10,"                             ");    
      wmove(ri,3,2);
      error(12,2,caderror2);
      touchwin(s1);
      wrefresh(s1);
      touchwin(ri);
      wrefresh(ri);
    }
  } while (ok==0);  
  
  if (situacion_progs19(fs19,&ov)!=1) {
    error(12,2,"El programa NO es para la RAM interna");
    touchwin(s1);
    wrefresh(s1);
    delwin(ri);
    cerrar_s19(fs19);
    return;
  }
  
  if (ov==1) {
    error(12,2,"El programa desborda la RAM interna");
    touchwin(s1);
    wrefresh(s1);
    delwin(ri);
    cerrar_s19(fs19);
    return;
  }
  posx=2;
  cont=0;
  bs=0; 
  wattrset(ri,COLOR_PAIR(10)|A_BOLD);
  mvwprintw(ri,5,2,"0%%     50%%   100%%");
  mvwprintw(ri,6,2,"................");
  wattrset(ri,COLOR_PAIR(11) | A_BOLD);
  wrefresh(ri);
  baudios(7680);
  vbaud=7680;
  display_baudios(vbaud);
  if (cargars19_ramint(fs19,accion_ri)==0) {
    sprintf(caderror2,"Error: %s",getloaderror());
    error(12,2,caderror2);
    touchwin(s1);
    wrefresh(s1);
    delwin(ri);
    cerrar_s19(fs19);
    return;
  }
  else {
    wattrset(ri,COLOR_PAIR(7));
    wprintw (ri," OK!!");
    mvwprintw (ri,8,2,"Tamano del programa: %u bytes",getnbytes19(fs19));
    mvwprintw (ri,9,2,"Envio correcto");
  }
  cerrar_s19(fs19);
  wrefresh(ri);
  usleep(500000);
  touchwin(s1);
  delwin(ri);
}

void tecla_especial()
{
  char c;
  
  c=io_getch();
  switch(c) {
    case 91 : c=io_getch();
              if (c==91) {  /* Teclas F1-F5 */
                c=io_getch();
                switch(c) {
                  case 65 : ram_interna();  /* F1 */
                            break;
                  case 66 : wprintw(s1,"F2");  /* F2 */
                            break;          
		  case 68 : cambiar_puerto(); /* F4 */
                  case 69 : cambiar_velocidad(); /* F5 */
                            break;          
                  default : wprintw(s1,"Fx:%u ",c);
                }
              } 
              if (c==49) { /* Teclas F6-F8 */
                c=io_getch();
                switch(56) {
                  case 56: cambiar_dtr(); /* F7 */
                           break;
                  default: wprintw(s1,"C%u",c);
                }
                if (kbhit()) io_getch();
              }  
              break;
    case 'x': fin=SI;  /* ALT-X */
              break;
    case 'c': werase(s1); /* ALT-C */
              wrefresh(s1);          
  }
  wrefresh(s1);
}

void terminal()
{
  char c;
  char d;
  
  wmove(s1,0,0);
  fin=NO;
  
  do {
    if (kbhit()) {
      c=io_getch();
      if (kbhit() && c==27) tecla_especial();  /* Tecla especial */
      else {  /* Tecla normal */
        enviar_car(c);
      }
    } 
    if (car_waiting()) {
      d=leer_car();
      if (d!=0) wprintw(s1,"%c",d);
      else wprintw(s1,"*");
      wrefresh(s1);
    }
  } while (fin==NO);
  werase(stdscr);
  wrefresh(stdscr);
}

void help()
{
  printf ("MCBOOT %s, IEARobotics, %s\n\n",version,fecha);
  printf ("Forma de uso: ");
  printf ("mcboot [opciones]\n\n");
  printf ("   -com1   ");
  printf ("Utilizar el COM1\n");
  printf ("   -com2   ");
  printf ("Utilizar el COM2\n");
  printf ("   -h      ");
  printf ("Esta ayuda\n\n");
  printf ("Ejemplo:  ");
  printf ("mcboot -com2\n\n");
  printf ("Si no se especifica puerto se toma COM2 por defecto\n\n");
}

void analizar_parametros(int argc, char* argv[])
{
    int c;

    puerto=COM2;  /* Por defecto COM2 */

    while ((c = getopt(argc, argv, "c:h"))!=EOF) {
 	switch (c) {
  	  case 'c':
            if (strcmp("om2",optarg)==0) puerto=COM2;
            else 
              if (strcmp("om1",optarg)==0) puerto=COM1;
              else puerto=COM2;  /* Por defecto COM2 */
	    break;
	  case 'h':
	default: help();
	         exit (0);
	}
    }
}

/* MAIN */

int main(int argc, char *argv[])
{
  analizar_parametros(argc,argv);
  if (abrir_puerto_serie(puerto)==0) {
    printf ("Error al abrir puerto serie: %s\n\n",getserial_error());
    exit(1);
  }  
  inicializar_crt();
  presenta();
  crear_terminal();
  vbaud=7680;
  vdtr=OFF;
  baudios(7680);
  set_break_timeout(100000);
  dtr_off();
  display_com(puerto);
  display_baudios(vbaud);
  display_dtr(vdtr);
  terminal();    
  cerrar_puerto_serie();    
  endwin();
  return 0;
}
