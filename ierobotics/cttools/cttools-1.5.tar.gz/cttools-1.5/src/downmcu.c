/****************************************************************************/
/* Downmcu.c                                                                */
/****************************************************************************/
/*  Carga de programas en la RAM interna del 68HC11. El programa esta       */
/*  especificamente disenado para trabajar con la tarjeta CT6811            */
/*--------------------------------------------------------------------------*/
/****************************************************************************/


#include <string.h>
#include <stdlib.h>
#include <stdio.h>   
#include <unistd.h>  

#include <cts/serie.h>
#include <cts/s19.h>
#include <cts/bootstrp.h>
#include "termansi.h"
#include "io.h"

char version[]={"1.5.0"};
char fecha[]={"Julio 2004"};

int puerto;
char fich[80];

int i=0;
int n=0;

void carga()
{
  if (n==16 || i==255) {
    n=0;
    print ("*");
  }
  i++;
  n++;
}

void presenta()
{
  printf ("\n");
  setcolor(ROJO);
  high();
  print ("DOWNMCU ");
  setcolor(AMARILLO);
  print (version);
  setcolor(VERDE);
  print (" para LINUX. ");
  setcolor(CYAN);
  print ("IEAROBOTICS, ");
  print (fecha);
  printf ("\n");
  setcolor(BLANCO);
  print ("Carga de programas en la CT6811\n\n");
  low();
}

void help()
{
  presenta();
  low();
  high();
  print ("Forma de uso: ");
  low();
  print ("downmcu fichero.s19 [opciones]\n\n");
  high(); print ("   -com1   ");
  low();  print ("Utilizar el COM1\n");
  high(); print ("   -com2   ");
  low();  print ("Utilizar el COM2\n");
  high(); print ("   -noansi ");
  low();  print ("No utilizar terminal ansi\n");
  high(); print ("   -h      ");
  low();  print ("Esta ayuda\n\n");
  high(); print ("Ejemplo:  ");
  low();  print ("downmcu ledp.s19 -com2\n\n");
}

void analizar_parametros(int argc, char* argv[])
{
    int c;

    puerto=COM2;  /* Por defecto COM2 */

    if (argc<2) {
      printf ("\nERROR: No se ha especificado nombre de fichero .s19\n");
      printf ("Utilice downmcu -h para obtener ayuda\n\n");
      exit(1);
    }  
      
    strcpy(fich,argv[1]);
    while ((c = getopt(argc, argv, ":c:n:h"))!=EOF) {
 	switch (c) {
  	  case 'c':
            if (strcmp("om2",optarg)==0) puerto=COM2;
            else 
              if (strcmp("om1",optarg)==0) puerto=COM1;
              else puerto=COM2;  /* Por defecto COM2 */
	    break;
          case 'n':
            if (strcmp("oansi",optarg)==0) configansi(0);
            else printf ("Parametro incorrecto\n");  
            break;
	  case 'h':
	default: help();
	         exit (0);
	}
    }
}

int main(int argc, char* argv[])
{
  char *caderror;
  S19 fs19;
  int ov;
  char s[30];

  analizar_parametros(argc,argv);

  printf ("\n");
  presenta();

  if (abrir_s19(fich,&fs19, 1)==0) {
    caderror=(char *)geterrors19();
    high();
    setcolor(ROJO);
    printf (" --> ERROR: %s\n\n",caderror);
    low();
    return 0;
  }
  
  if (situacion_progs19(fs19,&ov)!=1) {
    setcolor(ROJO);
    high();
    print ("  ---> ERROR: El programa NO es para la RAM interna\n\n");
    low();
    cerrar_s19(fs19);
    exit(1);
  }
  if (ov==1) {
    setcolor(ROJO);
    high();
    print ("  ---> ERROR: El programa desborda la RAM interna\n\n");
    low();
    cerrar_s19(fs19);
    exit(2);
  }
  if (abrir_puerto_serie(puerto)==0) {
    printf ("Error al abrir puerto serie: %s\n\n",getserial_error());
    exit(1);
  }  
  set_break_timeout(100000);
  setcolor(CYAN);
  printf("0%%     50%%   100%%\n");
  high();
  setcolor(AZUL);
  print ("................\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
  if (cargars19_ramint(fs19,carga)==0) {
    printf ("\nError: %s\n\n",getloaderror());
    low();
  }
  else {
    printf (" OK!!\n\n");
    low(); high();
    print ("Tamano del programa: ");
    setcolor(VERDE);
    sprintf (s,"%u bytes\n",getnbytes19(fs19));
    print(s);
    low(); high();
    printf ("Envio correcto\n\n");
    low();
  }

  cerrar_s19(fs19);
  cerrar_puerto_serie();
  return 0;
}
