/**************************************************************************/
/**************************************************************************/

/**************************************************************************
 *         IMPLEMENTACION DE LOS DIFERENTES COMANDOS                      *
 **************************************************************************/
 
#include <cts/ctclient.h> 
 
void ejecuta_md(uint dir,uint nbloq);
void ejecutar_ms(byte dato,uint dir);
void ejecutar_mse(byte dato,uint dir);
void ejecuta_go(uint dir);
void ejecuta_dasm(uint dir);
void ejecutar_ckc();
void ejecutar_info();
void ejecutar_bulk(); 
void ejecutar_config(byte dato);
int abrir_fich_ee(char *fich);
void accion();
void grabar_eeprom();
void ejecutar_eeprom(char *fich);
void cargar_ram();
void ejecutar_load(char fich[]);
void presenta();
void establecer_conexion();
int comprobar_conexion();
void prompt();
void help();
void analiza_parametros(int argc, char *argv[]);
void textcolor(int color);
