/**************************************************************************/
/* CTDIALOG.                                                              */
/**************************************************************************/
/*  Procesamiento de los comandos del programa CTDIALOG.                  */
/*------------------------------------------------------------------------*/
/**************************************************************************/

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <cts/ascbin.h>
#include "termansi.h"
#include "io.h"
#include "ctdialog.h"



#define MAXINST 16    /* Numero de instrucciones */  /* ANDRES -> 11 */

/*            ********************
  ************* TIPOS DEFINIDOS  ************
  	      ********************              */

//typedef unsigned short int byte;
enum ttoken {tcomando,tidentif,tnumero,tfin};

struct token {           /* Estructura de las "tokens" */
  enum ttoken tipo;      /* Tipo de token              */
  byte dato1;            /* Campo con infor. adicional */
  byte dato2;
} t;

//typedef unsigned int uint;

/*            ***********************
  ************* VARIABLES GLOBALES  ************
	      ***********************              */

char cadcom[80];     /* Cadena que contiene los comandos introducidos  */
	  	     /* por el usuario                                 */
char identif[30];    /* Para almacenar identificadores                 */
char carsig=' ';     /*  Siguiente caracter al que se ha leido         */
byte ind=0;          /*  Indice a la cadena cadcom                     */

char error[20][255] = {
 {"Comando incorrrecto"},
 {"Direccion de memoria incorrecta"},
 {"Demasiados parametros"},
 {"Dato incorrecto"},
 {"S*lo se pueden almacenar valores de 1 byte"},
 {"Nombre de registro incorrecto"},
 {"Numero decimal demasiado grande"},
 {"Valor incorrecto"},
 {"Nombre de fichero incorrecto"},
 {"Comando desconocido. No hay HELP"},
};

char instruccion[MAXINST][10]={     /* Instrucciones disponibles */
  {"MD"},
  {"MS"},
  {"QUIT"},
  {"CLS"},
  {"LOAD"},
  {"CKC"},
  {"HELP"},
  {"G"},
  {"DASM"},
  {"EEPROM"},
  {"LOAD"},
  {"INFO"},      
  {"BULK"},      
  {"CONFIG"},
  {"MSE"},   
  {"PA"},    
};

int hextoint(char car,byte *dec)
/**********************************************************************/
/*  Esta funcion toma un caracter hexadecimal en ASCII y lo convierte */
/*  a un numero entero.                                               */
/*                                                                    */
/*     La funcion devuelve 0 si el caracter no es un digita en hexa-  */
/*  decimal. Devuelve un 1 en caso contrario.                         */
/**********************************************************************/
{
  if (car>='0' && car<='9')
      *dec=car-'0';
  else if (car<='F' && car>='A')
      *dec=car-'A'+10;
    else return 0;        /*  El digito no esta en hexadecimal  */

  return 1;		  /*  No ha habido errores              */
}

int cadtoint(char *cad,byte *dec)
/***********************************************************************/
/*  Toma una cadena de 2 digitos en hexadecimal y los convierte en un  */
/*  numero entero.                                                     */
/*                                                                     */
/*    La funcion devuelve 0 si existe algun digito en la caden que no  */
/*  es hexadecimal. Se devuelve 1 en caso contrario.                   */
/***********************************************************************/
{
  byte num1,num2;

  if (hextoint(cad[0],&num1))	 /* Si se convierte bien el primer digito.. */
    if (hextoint(cad[1],&num2)){ /* y se convierte bien el segundo...       */
      *dec=num1*16+num2;         /* Se calcula en numero en decimal         */
      return 1;
    }
  return 0;           /* Ha habido alg*n error en la conversi*n */
}

char upper(car)
char car;
/* ************************************************
   * Pasar el caracter especificado a mayusculas  *
   *************************************************/
{
  return (car>='a' && car<='z') ? car-'a'+'A' : car;
}

void tomar_dir(char *cad,byte *dir)
/* ************************************************************************
   * Tomar la direccion que se encuentra en cad. Se introduce en dir[0]   *
   * el byte de menor peso y en dir[1] el de mayor peso.                  *
   *************************************************************************/
{
  cadtoint(cad,&(dir[1]));
  cadtoint(&(cad[2]),&(dir[0]));
}

char digito_hex(uint num)
/* ************************************************************************
   * Tomar un numero entre 0-15 y convertirlo en un digito hexadecimal.   *
   *************************************************************************/
{
  if (num<10 && num>=0)   return (char)num+'0';
  if (num<=15 && num>=10) return (char)(num-10)+'A';

  return 'H';   /* Si se retorna esto es que ha habido un error */
}

void printdir(uint dir)
{
  char cad[5];
  
  inttochar4(dir,cad);
  printf ("%s",cad);
}

void printhex(byte num)
/* ************************************************
   * Imprimir un numero de 1 byte en hexadecimal  *
   *************************************************/
{
  char cad[3];
  char s[80];
 
  num=num&0xFF; 
  bytetochar2(num,cad);
  sprintf (s,"%s",cad);
  print (s);
}

void printchar(num)
unsigned short int num;
/* ************************************************************
   * Imprimir un caracter. Si no es imprimible se saca un .   *
   *************************************************************/
{
  if (num<32 || num>126) printf (".");
  else printf ("%c",(char)num);
}

void print_error(num)
int num;
/* ************************************************
   * Sacar el mensaje de error correspondiente    *
   *************************************************/
{
  char s[80];

  print ("\n");
  setcolor(AZUL); high();
  sprintf (s,"        ---> %s\n",error[num-1]);
  print (s);
  low();
}

char leer_caracter()
/* *******************************************************************
   * Leer el siguiente car*cter de la cadena que contiene el comando *
   ********************************************************************/
{
  char c;

  c=carsig;
/*  carsig=upper(cadcom[ind++]);*/
  carsig=cadcom[ind++];

  return c;
}

byte es_instruccion(cad)
char *cad;
/* ************************************************************************
   * Comprobar si la cadena introducida es un comando de CTDIALOG.        *
   *                                                                      *
   * SALIDAS:                                                             *
   *           0 --> La cadena no es un comando                           *
   *           En caso contrario se devuelve el offset + 1 del comando    *
   *           en la tabla de comandos.                                   *
   *************************************************************************/
{
  int i;
  char cad2[80];

  for (i=0; i<strlen(cad); i++) {
    cad2[i]=toupper(cad[i]);
  }
  cad2[i]=0;

  for (i=0; i<MAXINST; i++) {
     if (strcmp(cad2,instruccion[i])==0) {
       return i+1;
     }  
  }

  return 0;  /* cad no es una instruccion */
}

byte es_numero(car)
char car;
/* *****************************************************************
   * Se devuelve 1 si el car*cter introducido es un digito decimal *
   ******************************************************************/
{
  return (car<='9' && car>='0') ? 1 : 0;
}

byte es_numero_hex(char car)
/* *********************************************************************
   * Se devuelve 1 si el car*cter introducido es un d*gito hexadecimal *
   **********************************************************************/
{
  return (es_numero(car) || (toupper(car)>='A' && toupper(car)<='F')) ? 1 : 0;
}

void leer_identificador(cad)
char *cad;
/* ************************************************************************
   * Se lee un identificador de la cadena cadcom y se introduce en la     *
   * variable cad.                                                        *
   *************************************************************************/
{
  int i=0;

  while (carsig!=' ' && carsig!=0) {
    cad[i++]=leer_caracter();
  }
  cad[i]=0;
}

byte leer_binario()
/***********************************************************************/
/*  Leer un numero en binario. El numero no puede ser de mas de 8 bits */
/*  Se devuelve 0 si ha habido un error.                               */
/***********************************************************************/
{
  return 0;
}

byte leer_hexadecimal()
/* ************************************************************************
   * Leer un numero en hexadecimal. El numero no puede ser de mas de 4    *
   * digitos hexadecimales                                                *
   *************************************************************************/
{
  char numero[30];
  int i=0;
  byte num[30];
  byte iold;     /* Para almacenar la variable ind */
  char carsigold;

  iold=ind;             /* @ antes pon*a iold=ind-1 */
  carsigold=carsig;

  leer_identificador(numero);

  /* Comprobar que en la cadena todo son d*gitos en hexadecimal */
  while (numero[i]!=0)
  {
    numero[i]=(char)toupper((char)numero[i]);
    if (!hextoint(numero[i],&num[i])) {
      ind=iold;
      carsig=carsigold;
      strcpy(identif,numero);
      return 0;
      }
      i++;
  }
  if (i>4) {                /* N*mero hexadecimal demasiado grande!! */
    /* Mensaje de error */
    return 0;
  }
  t.tipo=tnumero;
  switch (i) {
    case 1: t.dato1=num[0];
	    t.dato2=0;
	    break;
            
    case 2: t.dato1=num[0]*16 + num[1];
	    t.dato2=0;
	    break;
    case 3: t.dato1=num[1]*16 + num[2];
	    t.dato2=num[0];
	    break;
    case 4: t.dato1=num[2]*16  + num[3];
	    t.dato2=num[0]*16 + num[1];
	    break;
  }
  return 1;
}

byte leer_numero()
/* ************************************************************************
   * Leer un numero de la cadena cadcom e introducirlo en la variable de  *
   * tipo token. Si se produce algun error se devuelve 0.                 *
   * Si no hay errores se devuelve 1.                                     *
   *************************************************************************/
{

  if (carsig=='%') {
    leer_caracter();
    return leer_binario();
  }

  if (carsig=='$') {
    leer_caracter();
    return leer_hexadecimal();
  }

  /* Por defecto se leen n*mero en hexadecimal */

  return leer_hexadecimal();
}

byte leer_token()
/* ************************************************************************
   * Leer el siguiente token de la cadena cadcom. Se actualiza la variable*
   * t, que es de tipo token.                                             *
   *                                                                      *
   * Se devuelve 0 si ha habido un error en el token leido, 1 en caso     *
   * contrario.                                                           *
   *************************************************************************/
{
  byte codigo;

  t.dato1=0;
  t.dato2=0;

  while ( carsig==' ')
     leer_caracter();         /* Eliminar espacios */
 
  if (carsig==0) {    /* Si final de la cadena ... */
    t.tipo=tfin;
    ind=0;
    carsig=' ';
    return 1;
  }
  if (carsig=='$' || carsig=='%' || es_numero(carsig) || es_numero_hex(carsig)) {
    if (leer_numero()) return 1;
    else leer_identificador(identif);
  }
  else leer_identificador(identif);
  
  codigo=es_instruccion(identif);
  if ( codigo!=0 ) {  /* Si es una instruccion.. */
    t.tipo=tcomando;
    t.dato1=codigo;
    return 1;
  }

  /* Es un identificador */

  t.tipo=tidentif;
  return 1;
}

byte fin_comando()
/* ************************************************************************
   * Comprobar que el siguiente token es el de fin de comando.            *
   *************************************************************************/
{

  leer_token();
  if (t.tipo!=tfin) {
    print_error(3);
    return 0;
  }
  else return 1;
}

void comando_md()
/* ****************
   * COMANDO MD   *
   *****************/
{
  byte dirc[2];
  uint nbloq;
  uint dir;

  leer_token();

  if (t.tipo!=tnumero) {
    print_error(2);
    return;              /* Direccion de memoria incorrecta */
  }

  dirc[0]=t.dato1;
  dirc[1]=t.dato2;

  dir=dirc[1]*0x100 + dirc[0];

  leer_token();
  if (t.tipo==tfin) {
    nbloq=16;
    ejecuta_md(dir,nbloq);
    return;
  }

  if (t.tipo!=tnumero) {
    print_error(4);      /* Se esperaba un n*mero */
    return;
  }

  nbloq=t.dato2*256+t.dato1;

  if (fin_comando()) {
    ejecuta_md(dir,nbloq);
    return;
  }
}

void comando_ms()
/* ****************
   * COMANDO MS   *
   *****************/
{
  byte dirc[2];
  byte dato;
  uint dir;

  leer_token();

  if (t.tipo!=tnumero) {
    print_error(2);
    return;
  }
  dirc[0]=t.dato1;
  dirc[1]=t.dato2;
  dir=dirc[1]*0x100 + dirc[0];

  leer_token();

  if (t.tipo!=tnumero) {
    print_error(4);
    return;
  }

  dato=t.dato1;
  if (t.dato2>0) {
    print_error(5);
    return;
  }
  if (fin_comando())
    ejecutar_ms(dato,dir);
}

void comando_mse()
/* ****************
   * COMANDO MSE  *
   *****************/
{
  byte dirc[2];
  byte dato;
  uint dir;

  leer_token();

  if (t.tipo!=tnumero) {
    print_error(2);
    return;
  }
  dirc[0]=t.dato1;
  dirc[1]=t.dato2;
  dir=dirc[1]*0x100 + dirc[0];

  leer_token();

  if (t.tipo!=tnumero) {
    print_error(4);
    return;
  }

  dato=t.dato1;
  if (t.dato2>0) {
    print_error(5);
    return;
  }

  if (fin_comando())
	ejecutar_mse(dato,dir);
}


void comando_A()
/* ****************
   * COMANDO A    *
   *****************/
{
  uint dir;
  byte dato;

  dir=0x1000;

  leer_token();

  if (t.tipo!=tnumero) {
    print_error(4);
    return;
  }

  dato=t.dato1;
  if (t.dato2>0) {
    print_error(5);
    return;
  }

  if (fin_comando())
  	ejecutar_ms(dato,dir);
}



void comando_cls()
/* ****************
   * COMANDO CLS  *
   *****************/
{
  if (fin_comando()) {
    low();
    clrscr();
  }
}

void comando_ckc()
/* ****************
   * COMANDO CKC  *
   *****************/
{
  if (!fin_comando()) return;
  ejecutar_ckc();
}

void comando_go()
/* ****************
   * COMANDO GO   *
   *****************/
{
  byte dirc[2];
  uint dir;

  leer_token();

  if (t.tipo!=tnumero) {
    print_error(2);
    return;              /* Direccion de memoria incorrecta */
  }

  dirc[0]=t.dato1;
  dirc[1]=t.dato2;
  dir=dirc[1]*0x100 + dirc[0];

  if (fin_comando()) {
    ejecuta_go(dir);
    return;
  }
}

void comando_dasm()
/* ****************
   * COMANDO DASM *
   *****************/
{
  byte dirc[2];
  uint dir;

  leer_token();

  if (t.tipo!=tnumero) {
    print_error(2);
    return;              /* Direccion de memoria incorrecta */
  }

  dirc[0]=t.dato1;
  dirc[1]=t.dato2;

  dir=dirc[1]*0x100 + dirc[0];

  if (fin_comando()) {
    ejecuta_dasm(dir);
    return;
  }
}


void comando_info()        
/* ******************
   * COMANDO INFO   *
   *******************/
{
  if (!fin_comando()) return;
  ejecutar_info();
}


void comando_bulk()        
/* ******************
   * COMANDO BULK   *
   *******************/
{
  if (!fin_comando()) return;
  ejecutar_bulk();
}


void comando_config()	  
/* ******************
   * COMANDO CONFIG *
   *******************/
{
  byte dato;

  leer_token();

  if (t.tipo!=tnumero) {
    print_error(4);
    return;
  }

  dato=t.dato1;
  if (t.dato2>0) {
    print_error(5);
    return;
  }
  if (fin_comando()) {
	ejecutar_config(dato);
  }
}

void comando_eeprom()
/* ******************
   * COMANDO EEPROM *
   *******************/
{
  leer_token();

  if (t.tipo!=tidentif && t.tipo!=tcomando) {
    print_error(9);
    return;
  }

  if (fin_comando()) {
    ejecutar_eeprom(identif);
  }
}

void comando_load()
/* ******************
   * COMANDO LOAD   *
   *******************/
{
  leer_token();

  if (t.tipo!=tidentif && t.tipo!=tcomando) {
    print_error(9);
    return;
  }

  if (fin_comando()) {
    ejecutar_load(identif);
  }
}

void ayuda_md()
/* ********************************************
   * Imprimir la ayuda general del comando md *
   *********************************************/
{
  presenta();
  low();
  print ("---------------------------------------------------------------------------\n");
  print ("    ");
  high();
  setcolor(AMARILLO); print ("COMANDO MD");
  low(); print ("         Volcar bloques de memoria                           \n");
  print ("---------------------------------------------------------------------------\n\n");
  high(); print ("SINTAXIS:    ");
  low();  print ("MD direccion [numero de bloques]\n");
  high(); print ("DESCRIPCION: ");
  low();  print ("Volcar el numero de bloques especificados a partir de la direccion\n");
                 print ("             indicada. Si no se especifica el numero de bloques a volcar, por\n");
		 print ("             defecto se vuelcan 16 bloques. Cada bloque esta constituido\n");
		 print ("             por 16 bytes de memoria\n");
  high(); print ("EJEMPLOS:\n");
  setcolor(AZUL); print ("  MD b600");
  low();          print ("    Visualizar 16 bloques de memoria a partir de la direccion b600\n");
  high();
  setcolor(AZUL); print ("  MD 1000 1");
  low();          print ("  Visualizar 1 bloque de memoria a partir de la direccion $1000\n");
  high();
  setcolor(AZUL); print ("  MD 8000 ff");
  low();          print (" Visualizar 256 bloques ($ff) a partir de la direccion $8000\n");
  print ("\n");
}

void ayuda_ms()
/* ***************************************
   * Imprimir la ayuda del comando ms    *
   ****************************************/
{
  presenta();
  low();
  print ("---------------------------------------------------------------------------\n");
  print ("    "); high();
  setcolor(AMARILLO); print ("COMANDO MS");
  low(); print ("         Almacenar un byte en una direccion de memoria       \n");
  print ("---------------------------------------------------------------------------\n\n");
  high(); print ("SINTAXIS:    ");
  low();  print ("MS direccion valor\n");
  high(); print ("DESCRIPCION: ");
  low();  print ("Almacenar en la direccion de memoria especificada el valor de     \n");
		 print ("             8 bits indicado.\n");
  high(); print ("EJEMPLOS:\n");
  setcolor(AZUL); print ("  MS 1000 40");
  low();          print ("  Almacenar el valor $40 en la direccion 1000. Como esta\n");
		  print ("              direccion corresponde al puerto A del 6811, se activa el\n");
		  print ("              bit 6 del puerto A y se enciende el LED de la tarjeta CT6811\n");
  high();         
  setcolor(AZUL); print ("  MS 8000 ff");
  low();          print ("  Almacenar el valor $ff en la direccion 8000 (Esta direccion\n");
		  print ("              debe ser memoria RAM)\n");

  print ("\n");
}


void ayuda_mse()
/* ***************************************
   * Imprimir la ayuda del comando mse   *
   ****************************************/
{
  presenta();
  low();
  print ("---------------------------------------------------------------------------\n");
  print ("    "); high();
  setcolor(AMARILLO); print ("COMANDO MSE");
  low(); print ("         Almacenar un byte en una direccion de la EEPROM\n");
  print ("---------------------------------------------------------------------------\n\n");
  high(); print ("SINTAXIS:    ");
  low();  print ("MSE direccion valor\n");
  high(); print ("DESCRIPCION: ");
  low();  print ("Almacenar en la direccion de memoria EEPROM especificada   \n");
		 print ("             el valor de 8 bits indicado.\n");
  high(); print ("EJEMPLOS:\n");
  setcolor(AZUL);print ("  MSE B600 40");
  low();  print ("  Almacenar el valor $40 en la direccion B600. Suponiendo\r\n");
		 print ("              que dicha posicion sea de EEPROM. ( Por ejemplo en el \n");
		 print ("              modelo 68HC11A1 esta en la $B600-$B7FF.)\n");
		 print ("               Tambien hay que tener cuidado con no intentar programar\n");
		 print ("              zonas de EEPROM protegidas,pues la escritura sobre ellas\n");
		 print ("              no tendra efecto.\n");
  print ("\n");
}

void ayuda_dasm()
/* ***************************************
   * Imprimir la ayuda del comando DASM  *
   ****************************************/
{
  presenta();
  low();
  print ("---------------------------------------------------------------------------\n");
  print ("    "); high();
  setcolor(AMARILLO); print ("COMANDO DASM");
  low(); print ("         Desensamblar bytes de memoria                    \n");
  print ("---------------------------------------------------------------------------\n\n");
  high(); print ("SINTAXIS:    ");
  low();  print ("DASM direccion\n");
  high(); print ("DESCRIPCION: ");
  low();  print ("Desensamblar a partir de la direccion indicada.\n");
  high(); print ("EJEMPLOS:\n");
  setcolor(AZUL); print ("  DASM 0");
  low(); print ("     Desensamblar el contenido de la RAM interna del 6811\n");
  high();
  setcolor(AZUL); print ("  DASM B600");
  low(); print ("  Desensamblar el contenido de la memoria EEPROM del 6811\n");
  print ("\n");
}

void ayuda_eeprom()
/* ****************************************
   * Imprimir la ayuda del comando EEPROM *
   *****************************************/
{
  presenta();
  low();
  print ("---------------------------------------------------------------------------\n");
  print ("    "); high();
  setcolor(AMARILLO); print ("COMANDO EEPROM");
  low();  print ("  Grabar un programa .s19 en la memoria eeprom del 6811  \n");
  print ("---------------------------------------------------------------------------\n\n");
  high(); print ("SINTAXIS:    ");
  low();  print ("EEPROM archivo\n");
  high(); print ("DESCRIPCION: ");
  low();  print ("Grabar en la memoria EEPROM del 6811 el archivo .S19 indicado.\n");
		 print ("             Para que el programa se grabe correctamente debe haberse definido\n");
		 print ("             para estar comprendido en los limites de la memoria EEPROM,\n");
		 print ("             mediante directivas ORG en el programa fuente.\n");
  high();        print ("EJEMPLOS:\n");
  setcolor(AZUL);  print ("  EEPROM prueba");
  low();         print ("  Grabar el programa prueba.s19 en la EEPROM. El programa\n");
		 print ("                 prueba.asm debe tener al comienzo una directiva ORG con un\n");
		 print ("                 valor de direccion comprendido entre los valores $B600 y\n");
		 print ("                 $B7FF que son los limites de la memoria EEPROM.\n");
  high();
  setcolor(AZUL); print ("  EEPROM led.s19");
  low();  print ("  Grabar el programa led.s19 en la memoria EEPROM\n");
  print ("\n");
}

void ayuda_g()
/* ****************************************
   * Imprimir la ayuda del comando G      *
   *****************************************/
{
  presenta();
  low();
  print ("---------------------------------------------------------------------------\n");
  print ("    "); high();
  setcolor(AMARILLO); print ("COMANDO G     ");
  low();  print ("  Saltar a un programa y ejecutarlo.                     \n");
  print ("---------------------------------------------------------------------------\n\n");
  high(); print ("SINTAXIS:    ");
  low();  print ("G direccion\r\n");
  high(); print ("DESCRIPCION: ");
  low();  print ("Saltar a la direccion especificada y empezar a ejecutar el\r\n");
		 print ("             programa que alli se encuentre. Una vez ejecutado este comando\r\n");
		 print ("             la conexion con la tarjeta se pierde, puesto que el 6811\r\n");
		 print ("             ya no estara ejecutando el programa que mantiene la conexion.\r\n");
  high(); print ("EJEMPLOS:\r\n");
  setcolor(AZUL); print ("  G b600");
  low();  print ("  Ejecutar el programa que se encuentra en la memoria EEPROM\r\n");
  high();
  setcolor(AZUL); print ("  G 8000");
  low(); print ("  Ejecutar un programa que se encuentra direccion $8000 de la RAM\r\n");
  print ("\r\n");
}

void ayuda_ckc()
/* ****************************************
   * Imprimir la ayuda del comando CKC    *
   *****************************************/
{
  presenta();
  low();;
  print ("---------------------------------------------------------------------------\n");
  print ("    "); high();
  setcolor(AMARILLO); print ("COMANDO CKC   ");
  low(); print ("  Comprobar el estado de la conexi*n con la tarjeta      \n");
  print ("---------------------------------------------------------------------------\n\n");
  high(); print ("SINTAXIS:    ");
  low();  print ("CKC\r\n");
  high(); print ("DESCRIPCION: ");
  low();  print ("Se muestra el puerto actual de comunicaciones y el estado\r\n");
		 print ("             de la conexion con la tarjeta. La conexion con la tarjeta\r\n");
		 print ("             deja de existir por alguno de los siguientes motivos:\r\n");
		 print ("             Se ha realizado un reset de la tarjeta, se ha desconectado\r\n");
		 print ("             el cable que va al PC, la tarjeta no esta alimentada o \r\n");
		 print ("             el 6811 esta ejecutando un programa que no es el CTSERVER\r\n");

  print ("\n");
}

void ayuda_cls()
/* ****************************************
   * Imprimir la ayuda del comando CLS    *
   *****************************************/
{
  presenta();
  low();
  print ("---------------------------------------------------------------------------\n");
  print ("    "); high();
  setcolor(AMARILLO); print ("COMANDO CLS   ");
  low();  print ("  Borrar la pantalla.                                    \n");
  print ("---------------------------------------------------------------------------\n\n");
  high(); print ("SINTAXIS:    ");
  low();  print ("CLS\n");
  high(); print ("DESCRIPCION: ");
  low();  print ("Borrar la pantalla y situar el prompt en la parte superior\n");
	 print ("             izquierda de la pantalla.\n");
  print ("\n");
}

void ayuda_info()             /* ANDRES ********* */
/* ****************************************
   * Imprimir la ayuda del comando INFO   *
   *****************************************/
{
  presenta();
  low();
  print ("---------------------------------------------------------------------------\n");
  print ("   "); high();
  setcolor(AMARILLO); print ("COMANDO INFO  ");
  low();  print ("  Muestra informacion sobre el microcontrolador.         \n");
  print ("---------------------------------------------------------------------------\n\n");
  high(); print ("SINTAXIS:    ");
  low();  print ("INFO\r\n");
  high(); print ("DESCRIPCION: ");
  low();  print ("Informa sobre la configuracion del microcontrolador.\n");
		 print ("             Da la situacion de la EEPROM y muestra el CONFIG.\n");

  print ("\r\n");
}

void ayuda_bulk()             /* ANDRES ********* */
/* ****************************************
   * Imprimir la ayuda del comando BULK   *
   *****************************************/
{
  presenta();
  low();
  print ("---------------------------------------------------------------------------\n");
  print ("    "); high();
  setcolor(AMARILLO); print ("COMANDO BULK  ");
  low();  print ("  Borra toda la EEPROM interna del microcontrolador.     \n");
  print ("---------------------------------------------------------------------------\n\n");
  high(); print ("SINTAXIS:    ");
  low();  print ("BULK\n");
  high(); print ("DESCRIPCION: ");
  low();  print ("Borra la EEPROM interna del microcontrolador. El registro CONFIG\n");
		 print ("             no se ve afectado.\n");
  print ("\n");
}

void ayuda_config()
/* ****************************************
   * Imprimir la ayuda del comando CONFIG *
   *****************************************/
{
  presenta();
  low();
  print ("---------------------------------------------------------------------------\n");
  print ("    "); high();
  setcolor(AMARILLO); print ("COMANDO GONFIG");
  low();  print ("  Programa el registro CONFIG.                           \n");
  print ("---------------------------------------------------------------------------\n\n");
  high(); print ("SINTAXIS:    ");
  low();  print ("CONFIG byte \n");
  high(); print ("DESCRIPCION: ");
  low();  print ("Escribe el valor indicado en el registro CONFIG, para hacer\n");
		 print ("             efectivo el cambio tendremos que hacer un RESET.\n");
  print ("\n");
}


void ayuda_quit()
/* ****************************************
   * Imprimir la ayuda del comando QUIT   *
   *****************************************/
{
  presenta();
  low();
  print ("---------------------------------------------------------------------------\n");
  print ("    "); high();
  setcolor(AMARILLO); print ("COMANDO QUIT  ");
  low(); print ("  Salir de CTDIALOG.                                     \n");
  print ("---------------------------------------------------------------------------\n\n");
  high(); print ("SINTAXIS:    ");
  low();  print ("QUIT\r\n");
  high(); print ("DESCRIPCION: ");
  low();  print ("Salir del programa CTDIALOG y devolver el control al DOS/LINUX.\n");
  print ("\n");
}


void ayuda_load()
/* ****************************************
   * Imprimir la ayuda del comando LOAD   *
   *****************************************/
{
  presenta();
  textcolor(7);
  printf ("***************************************************************************\r\n");
  printf ("*  ");
  textcolor(14); printf ("COMANDO LOAD  ");
  textcolor(7);  printf ("  Cargar un programa en la memoria RAM.                  *\r\n");
  printf ("***************************************************************************\r\n\n");
  textcolor(15); printf ("SINTAXIS:    ");
  textcolor(7);  printf ("LOAD archivo\r\n");
  textcolor(15); printf ("DESCRIPCION: ");
  textcolor(7);  printf ("Cargar en la memoria RAM el archivo .s19 indicado. Este comando\r\n");
		 printf ("             no comprueba si el sistema tiene RAM o no.El programa especificado\r\n");
		 printf ("             simplemente se transfiere. Que exista o no memoria RAM es problema\r\n");
		 printf ("             del usuario. No se permite cargar programas en la RAM interna del\r\n");
		 printf ("             6811 para no machacar el programa CTSERVER y perder la conexi*n\r\n");
  textcolor(15); printf ("EJEMPLOS:\r\n");
  textcolor(9);  printf ("  LOAD prueba");
  textcolor(7);  printf ("   Cargar el programa prueba.s19 en la RAM. El programa\r\n");
		 printf ("                se carga en la direcci*n indicada por la directiva ORG\r\n");
		 printf ("                del programa fuente (.ASM).\r\n");
  textcolor(9);  printf ("  LOAD led.s19");
  textcolor(7);  printf ("  Cargar el programa led.s19 en la memoria RAM\r\n");
  printf ("\r\n");
}

void ayuda_comando(comando)
char *comando;
/* ********************************************
   * Imprimir la ayuda del comando indicado   *
   *********************************************/
{
  int i;
  
  for (i=0; i<strlen(comando); i++) {
    comando[i]=toupper(comando[i]);
  }

  if (strcmp(comando,"MD")==0) ayuda_md();
  else if (strcmp(comando,"MS")==0) ayuda_ms();
    else if (strcmp(comando,"DASM")==0) ayuda_dasm();
      if (strcmp(comando,"EEPROM")==0) ayuda_eeprom();
      else if (strcmp(comando,"G")==0) ayuda_g();
	if (strcmp(comando,"CKC")==0) ayuda_ckc();
	else if (strcmp(comando,"CLS")==0) ayuda_cls();
	  if (strcmp(comando,"QUIT")==0) ayuda_quit();
		else if (strcmp(comando,"LOAD")==0) ayuda_load();
		  if (strcmp(comando,"INFO")==0) ayuda_info();   	/* ANDRES **** */
		  else if (strcmp(comando,"BULK")==0) ayuda_bulk();   	/* ANDRES **** */
			if (strcmp(comando,"CONFIG")==0) ayuda_config();   	/* ANDRES **** */
			else if (strcmp(comando,"MSE")==0) ayuda_mse();   	/* ANDRES **** */
}

void comando_help()
/* ******************************
   * Imprimir la ayuda general  *
   *******************************/
{
  leer_token();

  if (t.tipo==tfin) {
    presenta();
    low();
    print ("Todos los valores se deben introducir en hexadecimal\n\n");
		   print ("---------------------------------------------------------------------------\n");
		   print ("    ");
    high(); setcolor(AMARILLO);               
                   print ("COMANDOS                         DESCRIPCION                          ");
    low();         print (" \n");
		   print ("---------------------------------------------------------------------------\n");
    high();               
    setcolor(CYAN); print ("  MD     dir bloques  ");
    setcolor(AZUL); print ("-Mostrar un numero de bloques de memoria\n");
    setcolor(CYAN); print ("  MS     dir byte     ");
    setcolor(AZUL); print ("-Introducir un byte en una direccion de memoria\n");
    setcolor(CYAN); print ("  MSE    dir byte     ");
    setcolor(AZUL); print ("-Introducir un byte en una direccion de la eeprom\n");  /* ANDRES */
    setcolor(CYAN); print ("  CONFIG byte         ");
    setcolor(AZUL); print ("-Programar el registro CONFIG.\n");                  /* ANDRES !!!!!! */
    setcolor(CYAN); print ("  DASM   dir          ");
    setcolor(AZUL); print ("-Desensamblar a partir de la direccion especificada\n");
    setcolor(CYAN); print ("  EEPROM fichero      ");
    setcolor(AZUL); print ("-Grabar un programa en la memoria EEPROM\n");
/*	textcolor(11); printf ("  LOAD   fichero      ");
	textcolor(9);  printf ("-Cargar un programa en memoria RAM EXTERNA\n"); */
    setcolor(CYAN); print ("  G      dir          ");
    setcolor(AZUL); print ("-Saltar a la direccion especificada\n");
    setcolor(CYAN); print ("  CKC                 ");
    setcolor(AZUL); print ("-Comprobar estado de la conexion\n");
    setcolor(CYAN); print ("  CLS                 ");
    setcolor(AZUL); print ("-Borrar la pantalla\n");
    setcolor(CYAN); print ("  INFO                ");
    setcolor(AZUL); print ("-Informacion sobre el microcontrolador\n");          /* ANDRES !!!!!! */
    setcolor(CYAN); print ("  BULK                ");
    setcolor(AZUL); print ("-Borrar la EEPROM interna del microcontrolador\n");  /* ANDRES !!!!!! */
    setcolor(CYAN); print ("  QUIT                ");
    setcolor(AZUL); print ("-Salir de CTDIALOG\n");
    low();         print ("---------------------------------------------------------------------------\n");
		   print ("    ");
    high();               
    setcolor(ROJO);print ("  HELP COMANDO ----> Obtener mas informacion sobre un comando         ");
    low();         print (" \n");
		   print ("---------------------------------------------------------------------------\n");
    return;
  }

  if (t.tipo!=tcomando) {
    print_error(10);
    return;
  }

  if (fin_comando()) {
    ayuda_comando(identif);
    return;
  }
}

int procesar_comando()
/* ************************************************************************
   * Esperar un comando y procesarlo. Si el comando es QUIT se retorna 0  *
   *************************************************************************/
{
  cerrar_consola();
  fgets(cadcom, 80, stdin);
  //-- Eliminar el CR final
  cadcom[strlen(cadcom)-1]=0;
  abrir_consola();
  ind=0;
  carsig=' ';
  leer_token();
  if (t.tipo==tfin) return 1;  /* Instrucci*n NULA */
  if (t.tipo!=tcomando) {
    print_error(1);
  }
  switch (t.dato1) {      /* Segun el comando introducido */
    case 1: comando_md();
	    break;
    case 2: comando_ms();
	    break;
    case 3: return 0;
            break;
    case 4: comando_cls();
	    break;
    case 5: comando_load();
	    break;
    case 6: comando_ckc();
	    break;
    case 7: comando_help();
	    break;
    case 8: comando_go();
	    break;
    case 9: comando_dasm();
	    break;
    case 10: comando_eeprom();
	     break;
    case 11: comando_load();
    	     break;
    case 12: comando_info();  
	     break;
    case 13: comando_bulk();  
  	     break;
    case 14: comando_config();
	     break;
    case 15: comando_mse();  
	     break;
    case 16: comando_A();    
	     break;

  }
  return 1;
}
