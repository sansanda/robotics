/****************************************************************************/
/* cts19toc.c                                                               */
/****************************************************************************/
/*                                                                          */
/* Programa para convertir archivos .S19 para la RAM INTERNA en su          */
/* representacion como una matriz de 256 bytes en C.                        */
/*                                                                          */
/*--------------------------------------------------------------------------*/
/****************************************************************************/

#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>

#include "termansi.h"
#include <cts/s19.h>
#include "io.h"

#define MODE644 (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)

char version[]={"1.5.0"};
char fecha[]={"Julio 2004"};

char fich[80];

void presenta()
{
  printf ("\n");
  setcolor(ROJO);
  high();
  print ("CTS19TOC ");
  setcolor(AMARILLO);
  print (version);
  setcolor(VERDE);
  print (" para LINUX. ");
  setcolor(CYAN);
  print ("IEAROBOTICS, ");
  print (fecha);
  printf ("\n");
  setcolor(BLANCO);
  print ("Pasar el codigo de ram interna de un archivo .S19 a una matriz en C\n\n");
  low();
}

void help()
{
  presenta();
  low();
  high();
  print ("Forma de uso: ");
  low();
  print ("cts19toc fichero.s19 [opciones]\n\n");
  high(); print ("   -h      ");
  low();  print ("Esta ayuda\n\n");
  high(); print ("Ejemplo:  ");
  low();  print ("cts19toc ledp.s19\n\n");
}

void analizar_parametros(int argc, char* argv[])
{
    int c;

    if (argc<2) {
      printf ("\nERROR: No se ha especificado nombre de fichero .s19\n");
      printf ("Utilice cts19toc -h para obtener ayuda\n\n");
      exit(1);
    }  
      
    strcpy(fich,argv[1]);
    while ((c = getopt(argc, argv, ":h"))!=EOF) {
 	switch (c) {
	  case 'h':
	default: help();
	         exit (0);
	}
    }
}

int main(int argc, char* argv[])
{
  char *caderror;
  S19 fs19;
  byte ramint[256];
  byte ramintoc[256];
  char cadc[1350];
  int fd;
  char fichout[80];

  analizar_parametros(argc,argv);

  printf ("\n");
  presenta();

  if (abrir_s19(fich,&fs19, 1)==0) {
    caderror=(char *)geterrors19();
    high();
    setcolor(ROJO);
    printf (" --> ERROR: %s\n\n",caderror);
    low();
    return 0;
  }
  
  s19toramint(fs19,ramint,ramintoc);
  raminttoc(ramint,cadc);
  cerrar_s19(fs19);
  
  /* Escribir en fichero de salida */
  strcpy(fichout,fich);
  strcat(fichout,".c");
  
  printf ("Generando fichero %s\n",fichout);
  
  fd=open(fichout,O_WRONLY | O_CREAT | O_TRUNC, MODE644);
  if (fd==-1) {
    perror("Error!");
    exit(1);
  }
  
  if (write(fd,cadc,strlen(cadc))==-1) {
    perror ("Error!");
    exit(1);
  }
  
  printf ("OK\n");
  
  close(fd);
  return 0;
}
