/***********************************************************************/
/* CTDETECT.C                                                          */
/* ------------------------------------------------------------------  */
/*  Autodetecion de la tarjeta CT6811 cuando se encuentra en modo      */
/*  Bootstrp.                                                          */
/* --------------------------------------------------------------------*/
/***********************************************************************/

#include <stdio.h>

#include <cts/serie.h>
#include <cts/bootstrp.h>
#include "termansi.h"
#include "io.h"

char version[]={"V1.5.0"};
char fecha[]={"Julio 2004"};

void presenta()
{
  printf ("\n");
  setcolor(ROJO);
  high();
  print ("CTDETECT ");
  setcolor(AMARILLO);
  print (version);
  setcolor(VERDE);
  print (" para LINUX. ");
  setcolor(CYAN);
  print ("(c) IEAROBOTICS. ");
  print (fecha);
  printf ("\n");
  setcolor(BLANCO);
  print ("Autodeteccion de la tarjeta CT6811\n\n");
  low();
}

int explorar(int port)
/***********************************************************************/
/* Explorar el puerto serie especificado. La funcion devuelve 0 si no  */
/* se ha encontrado la CT6811, 1 si se ha detectado.                   */
/***********************************************************************/
{
  int ok=0,nok=0;
  int intento;
  char cad[80];

  baudios(7680);
  for (intento=1; intento<=3; intento++) {
    setcolor(AMARILLO); high();
    sprintf (cad,"Intento %u.....",intento);
    print (cad);
    resetct6811();
    if (okreset()==0) {
      setcolor(ROJO); high();
      printf ("TIMEOUT\n");
      nok++;
    }
    else {
      setcolor(VERDE);
      printf ("OK\n");
      ok++;
    }
  }
  if (ok==3) return 1;
  return 0;
}

int main(void)
{
  int puerto;
  
  set_break_timeout(100000);  /* Poner el Timeout a 100mseg */
  presenta();
  
  for (puerto=0; puerto<=1; puerto++) {
    setcolor(BLANCO); high();
    printf ("\nExplorando puerto COM%u\n",puerto+1);
    if (abrir_puerto_serie(puerto)==0) {
      setcolor(ROJO); high();
      printf ("Error al abrir puerto serie: %s\n",getserial_error());
    }
    else {
      if (explorar(puerto)==1) {
        setcolor(CYAN);
        printf ("\nTarjeta CT6811 detectada en COM%u\n\n",puerto+1);
      }  
      cerrar_puerto_serie();  
    }  
  }
  high();
  low();
  printf ("\n");
  return 0;
}
