/********************************************************************/
/*  CTRESET.C                                                       */
/* ---------------------------------------------------------------- */
/*  Programa para hacer reset de la CT6811, saltar a la RAM o a la  */
/*  EEPROM                                                          */
/*------------------------------------------------------------------*/
/********************************************************************/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>   
#include <unistd.h>  

#include <cts/serie.h>
#include <cts/s19.h>
#include <cts/bootstrp.h>
#include "termansi.h"
#include "io.h"

char version[]={"V1.5.0"};
char fecha[]={"Julio 2004"};

int puerto;
int ge=0;     /* Go EEPROM */
int gr=0;     /* Go RAM    */

void presenta()
{
  printf ("\n");
  setcolor(ROJO);
  high();
  print ("CTRESET ");
  setcolor(AMARILLO);
  print (version);
  setcolor(VERDE);
  print (" para LINUX. ");
  setcolor(CYAN);
  print ("IEAROBOTICS,  ");
  print (fecha);
  printf ("\n");
  setcolor(BLANCO);
  print ("Reset, Salto a la RAM o a la EEPROM para la CT6811\n");
  setcolor(AZUL);
  print ("Utilice el parametro -h para obtener ayuda\n\n");
  low();
}

void help()
{
  presenta();
  low();
  high();
  print ("Forma de uso: ");
  low();
  print ("ctreset [opciones]\n\n");
  high(); print ("   -e      ");
  low();  print ("Saltar a la EEPROM\n");
  high(); print ("   -r      ");
  low();  print ("Saltar a la RAM\n");
  high(); print ("   -com1   ");
  low();  print ("Utilizar el COM1\n");
  high(); print ("   -com2   ");
  low();  print ("Utilizar el COM2\n");
  high(); print ("   -noansi ");
  low();  print ("No utilizar terminal ansi\n");
  high(); print ("   -h      ");
  low();  print ("Esta ayuda\n\n");
  high(); print ("Ejemplo:  ");
  low();  print ("ctreset -e -com2\n\n");
}

void analizar_parametros(int argc, char* argv[])
{
    int c;

    puerto=COM2;  /* Por defecto COM2 */

    while ((c = getopt(argc, argv, "rec:n:h"))!=EOF) {
 	switch (c) {
  	  case 'c':
            if (strcmp("om2",optarg)==0) puerto=COM2;
            else 
              if (strcmp("om1",optarg)==0) puerto=COM1;
              else puerto=COM2;  /* Por defecto COM2 */
	    break;
          case 'n':
            if (strcmp("oansi",optarg)==0) configansi(0);
            else printf ("Parametro incorrecto\n");  
            break;
          case 'e': ge=1; break;  /* Ir a la EEPROM */
          case 'r': gr=1; break;  /* Ir a la RAM */
	  case 'h':
	default: help();
	         exit (0);
	}
    }
}

int main(int argc, char* argv[])
{
  int r;

  analizar_parametros(argc,argv);
  printf ("\n");
  presenta();
  high();
  if (abrir_puerto_serie(puerto)==0) {
    setcolor(ROJO);
    printf ("Error al abrir puerto serie: %s\n\n",getserial_error());
    low();
    exit(1);
  }
  printf ("Puerto: COM%u\n",puerto+1);
  baudios(7680);
  set_break_timeout(100000);
  
  r=okreset();  /* Realizar un reset confirmado */
  if (r==0) {
    setcolor(ROJO);
    printf ("No se recibe senal de BREAK\n");
    low();
    printf ("Imposible realizar reset\n");
    cerrar_puerto_serie();
    exit(1);
  }
  if (ge==1) {   /* Salto a la EEPROM */
    if (jump_eeprom()) {
      low();
      printf ("Saltando a la EEPROM....OK!\n\n");
    }
    else {
      setcolor(ROJO); high();
      printf ("No se recibe senal de BREAK: Salto no realizado\n\n");
    }
    low();
    cerrar_puerto_serie();
    exit(0);
  }
  if (gr==1) {  /* Salto a la RAM */
    if (jump_ram()) {
     low();
     printf ("Saltando a la RAM....OK!\n\n");
    }
    else {
      setcolor(ROJO); high();
      printf ("No se recibe senal de BREAK: Salto no realizado\n\n");
    }
    low();
    cerrar_puerto_serie();
    exit(0);
  }
  low();
  printf ("Reset de la CT6811....OK\n\n");
  cerrar_puerto_serie();
  return 0;
}
