/************************************************************************/
/*  CTMAP.C                                                             */
/* -------------------------------------------------------------------- */
/*  Programa para examinar los ficheros .S19                            */
/*----------------------------------------------------------------------*/
/************************************************************************/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>   
#include <unistd.h>  

#include "termansi.h"
#include "io.h"
#include <cts/ascbin.h>
#include <cts/s19.h>

#define EEPROM 0xB600

char version[] = {"1.5.0"};
char fecha[] = {"Julio 2004"};

char fich[80];
byte ramint[256];
byte ramintoc[256];
byte eeprom[512];
byte eepromoc[512];

void presenta()
{
  printf ("\n");
  setcolor(ROJO);
  high();
  print ("CTMAP ");
  setcolor(AMARILLO);
  print (version);
  print (" ");
  setcolor(VERDE);
  print ("para LINUX. ");
  setcolor(CYAN);
  print ("IEAROBOTICS, ");
  print (fecha);
  printf ("\n");
  setcolor(BLANCO);
  print ("Visualizacion de ficheros .S19\n\n");
  low();
}

void help()
{
  presenta();
  low();
  high();
  print ("Forma de uso: ");
  low();
  print ("ctmap fichero.s19 [opciones]\n\n");
  high(); print ("   -noansi ");
  low();  print ("No utilizar terminal ansi\n");
  high(); print ("   -h      ");
  low();  print ("Esta ayuda\n\n");
  high(); print ("Ejemplo:  ");
  low();  print ("ctmap ledp.s19\n\n");
}

void analizar_parametros(int argc, char* argv[])
{
    int c;

    if (argc<2) {
      printf ("\nERROR: No se ha especificado nombre de fichero .s19\n");
      printf ("Utilice ctmap -h para obtener ayuda\n\n");
      exit(1);
    }  
      
    strcpy(fich,argv[1]);
    while ((c = getopt(argc, argv, ":n:h"))!=EOF) {
 	switch (c) {
          case 'n':
            if (strcmp("oansi",optarg)==0) configansi(0);
            else printf ("Parametro incorrecto\n");  
            break;
	  case 'h':
	default: help();
	         exit (0);
	}
    }
}

void ram_interna()
{
  int i;
  int y=5;
  byte t=0;
  char s[5];
  
  /* --- Sacar mapa de ocupacion de la RAM ---- */
  setcolor(BLANCO);
  high();
  print ("     0123456789ABCDEF");
  for (i=0; i<=0xFF; i++) {
    if (t==0) {
      setcolor(BLANCO);
      high();
      y++;
      locate(1,y);
      inttochar4(i,s);
      print(s); print (" ");
    }
    t++;
    t=(t % 0x10);
    low();
    if (i<0xC4) setcolor(CYAN);
    else setcolor(VERDE);
    if (ramintoc[i]) {
      high();
      print ("*");
    }  
    else {
      print (".");
    }  
  }  
  
  /* --- Sacar mapa ASCII ---- */
  y=5;
  locate(26,y);
  setcolor(BLANCO);
  high();
  print ("     0123456789ABCDEF");
  for (i=0; i<=0xFF; i++) {
    if (t==0) {
      setcolor(BLANCO);
      high();
      y++;
      locate(26,y);
      inttochar4(i,s);
      print(s); print (" ");
    }
    t++;
    t=t%0x10;
    low();
    if (ramint[i]>=32 && ramint[i]<='z') {
      sprintf (s,"%c",ramint[i]);
      print (s);
    }  
    else {
      print (".");
    }  
  }  
  printf ("\n");
}

void mem_eeprom()
{
  int i;
  int y=5;
  byte t=0;
  char s[5];
  
  /* --- Sacar mapa de ocupacion de la EEPROM ---- */
  setcolor(BLANCO);
  high();
  print ("     0123456789ABCDEF0123456789ABCDEF");
  for (i=0; i<=0x1FF; i++) {
    if (t==0) {
      setcolor(BLANCO);
      high();
      y++;
      locate(1,y);
      inttochar4(i+EEPROM,s);
      print(s); print (" ");
    }
    t++;
    t=t%0x20;
    low();
    setcolor(CYAN);
    if (eepromoc[i]) {
      high();
      print ("*");
    }  
    else {
      print (".");
    }  
  }  
  
  /* --- Sacar mapa ASCII ---- */
  y=5;
  locate(40,y);
  setcolor(BLANCO);
  high();
  print ("     0123456789ABCDEF0123456789ABCDEF");
  for (i=0; i<=0x1FF; i++) {
    if (t==0) {
      setcolor(BLANCO);
      high();
      y++;
      locate(40,y);
      inttochar4(i+EEPROM,s);
      print(s); print (" ");
    }
    t++;
    t=t%0x20;
    low();
    if (eeprom[i]>=32 && eeprom[i]<='z') {
      sprintf (s,"%c",eeprom[i]);
      print (s);
    }  
    else {
      print (".");
    }  
  }  
  printf ("\n");
}

void ram_externa()
{
  printf ("Programa para la RAM externa\n");
}

int main(int argc, char* argv[])
{
  char *caderror;
  S19 fs19;
  int ov;
  char s[30];
  int sp;
  int tam;

  analizar_parametros(argc,argv);

  clrscr();
  presenta();
  
  if (abrir_s19(fich,&fs19, 1)==0) {
    caderror=(char *)geterrors19();
    high();
    setcolor(ROJO);
    printf (" --> ERROR: %s\n\n",caderror);
    low();
    return 0;
  }
  
  sp=situacion_progs19(fs19,&ov);
  if (sp==1) {  /* Programa para la ram interna */
    s19toramint(fs19,ramint,ramintoc);
    ram_interna();
  }
  else if (sp==2) {
    s19toeeprom(fs19,eeprom,eepromoc);
    mem_eeprom();
  }
  else {
    ram_externa();
    cerrar_s19(fs19);
    low();
    printf ("\n");
    exit(0);
  }
  
  locate(2,23); setcolor(AMARILLO); high();
  print ("Fichero:   "); setcolor (AZUL); print (fich);
  locate(2,24); setcolor(AMARILLO); high(); print ("Tamano :   ");
  setcolor(AZUL);
  tam=getnbytes19(fs19);
  sprintf(s,"%u byte(s)",tam); print(s);
  
  locate(30,23); setcolor(AMARILLO); high();
    print ("Situacion       : "); setcolor(CYAN);
  if (sp==1) print ("RAM INTERNA");
  if (sp==2) print ("EEPROM INTERNA");
  
  locate(30,24); setcolor(AMARILLO); high();
  if (sp==1) {
    print ("Ocupacion RAM   : ");
    if (ov==0) sprintf (s,"%u%%",(tam*100)/0xFF);
    else sprintf (s,"OVERFLOW");
    setcolor(CYAN);
    print (s);
  }  
  if (sp==2) {
    print ("Ocupacion EEPROM: ");
    if (ov==0) sprintf (s,"%u%%",(tam*100)/0x1FF);
    else sprintf (s,"OVERFLOW");
    setcolor(CYAN);
    print (s);
  }  
  setcolor(CYAN);
  
  low();
  printf ("\n\n");
  return 0;
}
