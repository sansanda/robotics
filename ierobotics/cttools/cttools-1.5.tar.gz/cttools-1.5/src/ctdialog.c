/**************************************************************************/
/* CTDIALOG                                                               */
/*------------------------------------------------------------------------*/
/* Dialogo con la tarjeta CT6811.                                         */
/*------------------------------------------------------------------------*/
/**************************************************************************/

/**************************************************************************/
/* Esta version mejora la forma de distinguir el tipo de micro, ahora     */
/* arranquemos en otro modo podremos saber el tipo de micro. Funciona     */
/* perfectamente con el modelo E2. Todavia no funciona con el E9          */
/* ---------------------------------------------------------------------- */
/* Enero 2000: Cambiado el ctserver de 7680 a 9600 baudios. Se ha podido  */
/* porque se utiliza la nueva libreria cts.1.4                            */
/**************************************************************************/

char *version={"1.5.0"};
char *fecha={"Julio 2004"};

#include<fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#include <cts/r6811pc.h>
#include <cts/s19.h>
#include <cts/serie.h>
#include <cts/bootstrp.h>
#include <cts/ctclient.h>
#include "termansi.h"
#include "io.h"
#include "comandos.h"
#include "dasm.h"

#define BPROT 0x1035

int comprobar_conexion();
void sacar_puerto();
void sacar_posicion_eeprom();
void presenta();

/*            ********************
  ************* TIPOS DEFINIDOS  ************
              ********************              */

enum tconex {noconex,perdida, establecida};
/* La conexion entre CTDIALOG y CTSERVER se puede encontrar en 3  */
/* estados diferentes: No conexion, conexion perdida y conexion   */
/* establecida.                                                   */


/*            ***********************
  ************* VARIABLES GLOBALES  ************
              ***********************              */

enum tconex estconex = noconex;   /* Estado de la conexion        */
				  /* Inicialmente no hay conexion */
enum tipo_micro {Ax,E2,xx};
int puerto;
int tope_max=0xB600,tope_min=0xB7FF;  /* Localizacion de la EEPROM */
enum tipo_micro micro=Ax;             /* Por defecto tenemos un A1 */
S19 fichs19;   /* Fichero s19        */
uint tamfich;  /* Tamano del fichero */
int flage;     /* Flag de EEPROM */

void textcolor(int color)
{
}
void nada()
{
}
int wherex()
{
  return 1;
}
int wherey()
{
  return 1;
}
void gotoxy()
{
}
int i=0;
int n=0;

void accion_load()
/********************************************/
/* Accion al realiar al cargar el servidor  */
/********************************************/
{
  if (n==16 || i==255) {
    n=0;
    print ("*");
  }
  i++;
  n++;
} 

/**************************************************************************
 *         SERVICIOS OFRECIDOS POR EL CTDIALOG AL USUARIO                 *
 **************************************************************************/

void volcar_memoria(uint dir,uint nbloq)
/* ************************************************************************
   * Volcar un numero determinado de bloques. Un bloque son 16 bytes.     *
   *                                                                      *
   * ENTRADAS:  dir: Direccion de la memoria a volcar                     *
   *            nbloq: Numero de bloques a volcar                         *
   *************************************************************************/
{
  char s[5];
  byte buffer[16];
  uint tamano = 16;
  int i;
  unsigned int bloque;

  dir=dir & 0xFFF0;	/* Solo se vuelcan bloques de memoria multiplos de 16 */

  printf ("\n\n");
  setcolor(VERDE); high();
  printf ("      00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F\n");

  for (bloque=0; bloque<nbloq; bloque++) {
    load_block(buffer,tamano,dir,nada);
    setcolor(AMARILLO); high();
    sprintf (s,"%4X",dir); print(s);
    low();
    print ("  ");
    for (i=0; i<=15; i++) {  /* Escribir valores en hexadecimal */
      printhex(buffer[i]&0xFF);
      print (" ");
    }
    print ("   ");
    setcolor(AZUL); high();
    for (i=0; i<=15; i++) {  /* Escribir valores en ASCII       */
      printchar(buffer[i]);
    }
    printf("\n");
    dir=dir + 16;
  }
  low();
}

/**************************************************************************
 *         IMPLEMENTACION DE LOS DIFERENTES COMANDOS                      *
 **************************************************************************/
 
void ejecuta_md(uint dir,uint nbloq)
/* ************************************************************************
   * COMANDO MD: Volcar un bloque de memoria desde el micro al pc         *
   *             Si la conexion no esta establecida no se ejecuta.        *
   *                                                                      *
   * ENTRADAS:  dir: Direccion de la memoria a volcar                     *
   *************************************************************************/
{
  uint bloque;
  char c;

  bloque=nbloq;

  if (check_conexion()) {
    for (bloque=(nbloq/20); bloque>0; bloque--) {
	volcar_memoria(dir,20);
	low();
	printf ("\nPulse una tecla. <ESC> cancelar.\n");
	c=io_getch();
	if (c==27) {
	  printf ("\nAbortado\n");
	  return;
	}
        dir=dir+20*16;
    }
    if (nbloq % 20) volcar_memoria(dir,nbloq % 20);

    low();
    if (nbloq==1) printf ("\n1 bloque volcado\n\n");
    else printf ("\n%d bloques volcados\n\n",nbloq);
  }
  else printf ("\nNo hay conexion\n\n");
}

void ejecutar_ms(byte dato,uint dir)
/* ************************************************************************
   * COMANDO MS: Almacenar un byte en una direccion de memoria del micro  *
   *             Si la conexion no esta establecida no se ejecuta.        *
   *                                                                      *
   * ENTRADAS:  dir: Direccion de la memoria a grabar                     *
   *            dato: Dato a enviar                                       *
   *************************************************************************/
{
  if (check_conexion()) {
    store(dato,dir);
    usleep(10000);
  }
  else printf ("\nNo hay conexion\n");
}

void ejecutar_mse(byte dato,uint dir)             /* ANDRES !!!!! */
/* ************************************************************************
   * COMANDO MSE: Almacenar un byte en una direccion de memoria EEPROM.   *
   *             Si la conexion no esta establecida no se ejecuta.        *
   *                                                                      *
   * ENTRADAS:  dir: Direccion de la memoria a grabar                     *
   *            dato: Dato a enviar                                       *
   *************************************************************************/
{
  if (check_conexion()) {
    if (dir>tope_max || dir<tope_min) {
      textcolor(12);
      printf ("\n");
      printf ("Direccion ");
      printdir(dir);
      printf (": Intento de acceso a memoria no EEPROM\n");
      printf ("Grabacion no completada\n");
      return;
    }
    store_block_eeprom(&dato,1,dir,nada);
    usleep(20000);
  }
  else printf ("\nNo hay conexion\n");
}

void ejecuta_go(uint dir)
/* ************************************************************************
   * COMANDO GO: Saltar a la direccion especificada.                      *
   *             La conexion con el CTSERVER se pierde                    *
   *                                                                      *
   * ENTRADAS:  dir: Direccion a donde saltar                             *
   *************************************************************************/
{
  if (check_conexion()) {
    execute(dir);
    usleep(10000);
  }
  else printf ("\nNo hay conexion\n");
}

void ejecuta_dasm(uint dir)
{
  byte buffer[80];
  int i;

  if (check_conexion()) {
    load_block(buffer,80,dir,nada);
    printf ("En ctdialog..\n");
    for (i=0; i<16; i++)
      printf ("%x ",buffer[i]);
    printf ("En dasm..\n");
    dasm(buffer,80,dir);
  }
  else printf ("\nNo hay conexion\n");
}

void ejecutar_ckc()
/* ************************************************************************
   * COMANDO CKC: Comprobar el estado de la conexi*n.                     *
   *************************************************************************/
{
  int con;

  printf ("\n");
  sacar_puerto();
  con=comprobar_conexion();
  if (con) printf ("Estado de la conexion: ESTABLECIDA");
  else printf ("Estado de la conexion: NO HAY CONEXION");
  printf ("\n\n");
}


void ejecutar_info()            /* modificado por Andres !!!!! */
/* ************************************************************************
   * COMANDO INFO: Mostrar informacion sobre el microcontrolador.         *
   *************************************************************************/
{
  byte buffer;

  presenta();
  if (!check_conexion()) {
    printf ("\nNo hay conexion\n");
    return;
  }
  load(&buffer,CONFIG);       
  low(); high();
  printf("\n");
  if ( !(buffer&01) ) {
    printf("bit 0: EEON =0 -> EEPROM desactivada.");
    printf("\n");
  }
  else {
   printf("bit 0: EEON =1 -> EEPROM activada.");
   printf("\n");
  }
  
  if ( !(buffer&02) ) {
    printf("bit 1: ROMON=0 -> ROM desactivada.");
    printf("\n");
  }
  else {
    printf("bit 1: ROMON=1 -> ROM activada.");
    printf("\n");
  }
  
  if ( !(buffer&04) ) {
    printf("bit 2: NOCOP=0 -> COP activado.");
    printf("\n");
  }
  else {
    printf("bit 2: NOCOP=1 -> COP desactivado.");
    printf("\n");
  }
  
  if ( !(buffer&0x08) ) {
    printf("bit 3: NOSEC=0 -> SECURITY activada. Modelo fabricado con la mascara\n");
    printf("                  de seguridad\n");
  }
  else {
    printf("bit 3: NOSEC=1 -> SECURITY desactivada. (Solo disponible en modelos \n");
    printf("                  fabricados con la mascara de seguridad). \n");
  }
  
  setcolor(AMARILLO); high();
  printf("\nRegistro CONFIG: %X ",buffer);
  printf("\n");

  if (micro==E2) {
    printf("El modelo de micro se corresponde con la familia Ex\n");
    buffer=buffer & 0xF0;  /* me quedo con los bits superiores */
    tope_min=(buffer+8)*256;
    tope_max=(buffer+0xF)*256+0xFF;
    store(0x00,BPROT);
  }
  else {
     printf("El modelo de micro se corresponde con la familia Ax\n");
     tope_min=0xB600; tope_max=0xB7ff;
  }
     sacar_posicion_eeprom();
     low();
     printf ("\n");
}

void ejecutar_bulk()            
/* ************************************************************************
   * COMANDO BULK: Borrar la EEPROM del microcontrolador.                 *
   *************************************************************************/
{
  if (check_conexion()) {
    store(0x06,PPROG);
    store(0x06,tope_min);
    store(0x07,PPROG);
    store(0x00,PPROG);
    usleep(100000);
  }
  else printf ("\nNo hay conexion\n");
}

void ejecutar_config(byte dato)            /* modificado por Andres !!!!! */
/* ************************************************************************
   * COMANDO CONFIG: Programar el registro CONFIG.                        *
   *************************************************************************/
{
  if (check_conexion()) {
    store(0x16,PPROG);
    store(0x16,CONFIG);
    store(0x17,PPROG);
		/* Ahora grabo el nuevo valor */
    store(0x02,PPROG);
    store(dato,CONFIG);
    store(0x03,PPROG);
    store(0x00,PPROG);
    usleep(200000);
  }
  else printf ("\nNo hay conexion\n");
}


int abrir_fich_ee(char *fich)  /* actualizacion para que sirva para el E2 */
/***************************************************/
/* Abrir el fichero para ser grabado en la EEPROM  */
/***************************************************/
{
  char *caderror;
  unsigned int i;
  unsigned int dir;
  unsigned int nreg;
  byte codigo[37];
  byte tam;
  byte crc;
  
  if (abrir_s19(fich,&fichs19,1)==0) { /* Si se ha producido un error */
    caderror=(char *)geterrors19();    /* Leer la cadena de error     */
    printf ("Error: %s\n\n",caderror);   /* Imprimir mensaje de error   */
    return 0;
  }
  
  nreg=getnregs19(fichs19);
  
  if (nreg==0) { /* fichero s19 sin registros ? */
    print("Error: El archivo no tiene informacion \n\n");
    return 0;
  }
  
  leerdir_s19(fichs19,1,&dir);
  if (dir<tope_min || dir>tope_max) { /* el programa no es para la EEPROM */
    printf("Error: El programa no se situa en los limites de la EEPROM\n\n");
    return 0;
  }
  
  for (i=2; i<=nreg; i++) {
    leerdir_s19(fichs19,i,&dir);
    leercod_s19(fichs19,i,codigo,&tam,&crc);
    if ( (dir+tam)>tope_max+1) {
      printf("El programa desborda la EEPROM interna\n\n");
      return 0;
    }
  }
    
  return 1;
}



void accion()
/*****************************************************************/
/* Accion a realizar cada vez que se graba un byte en la EEPROM  */
/*****************************************************************/
{
  char cad[6];

  sprintf(cad,"%4u",tamfich);  
  print(cad); print ("\b\b\b\b");
  tamfich--;
}

void grabar_eeprom()
/*************************************/
/*  Grabar un fichero en la eeprom   */
/*************************************/
{
  uint nreg;
  uint i;
  uint dir;
  byte tam;
  uint tam2;
  byte codigo[30];
  byte crc;
  int ok;

  low();
  high(); print ("Bytes restantes: ");
  low();
  nreg=getnregs19(fichs19);
  for (i=1; i<=nreg; i++) {
    leerdir_s19(fichs19,i,&dir);
    leercod_s19(fichs19,i,codigo,&tam,&crc);
    tam2=(uint)tam;
    ok=store_block_eeprom(codigo,tam,dir,accion);
    if (ok==0) {
      printf ("\nConexion perdida...\n\n");
      return;
    } 
  }
  setcolor(AZUL); high();  print (" OK!!!\n");
  setcolor(AMARILLO); 
  print ("Grabacion completada\n\n");
  low();
}

void ejecutar_eeprom(char *fich)
/* ************************************************************************
   * COMANDO EEPROM: Grabar un programa en la EEPROM.                     *
   *************************************************************************/
{
  char s[80];

  if (!check_conexion()) {
    printf ("\nNo hay conexion\n");
    return;
  }
  
  if (abrir_fich_ee(fich)==0) return;
  tamfich=getnbytes19(fichs19);
  low(); high();
  high(); print ("\nFichero: ");
  low(); print (fich); print("\n");
  high(); print ("Tamano : ");
  low(); sprintf(s,"%u bytes\n\n",tamfich); print(s);
  grabar_eeprom();
  cerrar_s19(fichs19);
}

void cargar_ram()
/*************************************/
/*  Grabar un fichero en la ram      */
/*************************************/
{
  uint nreg;
  uint i;
  uint dir;
  byte tam;
  uint tam2;
  byte crc;
  byte codigo[30];
  int ok;

  low();
  high(); print ("Bytes restantes: ");
  low();
  nreg=getnregs19(fichs19);
  for (i=1; i<=nreg; i++) {
    leerdir_s19(fichs19,i,&dir);
    leercod_s19(fichs19,i,codigo,&tam,&crc);
    tam2=(uint) tam;
    store_block(codigo,tam2,dir,accion);
    ok=check_conexion();
    if (ok==0) {
      printf ("\nConexion perdida...\n\n");
      return;
    }
  }
  setcolor(AZUL); high();  print (" OK!!!\n");
  setcolor(AMARILLO); 
  print ("Carga completada\n\n");
  usleep(200000);
  low();
}

void ejecutar_load(char fich[])
{
  char s[80];
  char *caderror;
  
  if (!check_conexion()) {
    printf ("\nNo hay conexion\n");
    return;
  }

  if (abrir_s19(fich,&fichs19,1)==0) { /* Si se ha producido un error */
    caderror=(char *)geterrors19();    /* Leer la cadena de error     */
    printf ("Error: %s\n\n",caderror);   /* Imprimir mensaje de error   */
    return;
  }
  high();
  print ("\nCargar programa en RAM\n");
  tamfich=getnbytes19(fichs19)&0xFF;
  low(); high();
  high(); print ("\nFichero: ");
  low(); print (fich); print("\n");
  high(); print ("Tamano : ");
  low(); sprintf(s,"%u bytes\n\n",tamfich); print(s);
  cargar_ram();
  cerrar_s19(fichs19);
}

void presenta()
{
  char s[30];

  printf ("\n\n");
  high();
  setcolor(ROJO); print ("CTDIALOG ");
  setcolor(CYAN); sprintf (s,"Version %s ",version);
  print(s);
  setcolor(VERDE);
  print ("(C) IEAROBOTICS. ");
  print (fecha);
  printf ("\n");
  setcolor(AZUL);
  print ("Teclee HELP para obtener ayuda\n\n");
  low();
}

void establecer_conexion()
/* ************************************************************************
   * Establecer la conexion con el servidor CTSERVER que debe estar eje-  *
   * cut*ndose en la entrenadora. Segun que exista o no conexion se       *
   * informa al usuario y se modifica la variable global estconex, que    *
   * indica el estado de la conexion actual.                              *
   *************************************************************************/
{
  textcolor(7);
  printf ("Estableciendo conexion con tarjeta..... ");
  usleep(300000);
  if (check_conexion()) {
    printf("conexion establecida\n");
    estconex=establecida;
  }
  else {
    printf("CONEXION NO ESTABLECIDA\n");
    estconex=noconex;
  }
}

int comprobar_conexion()
/* ************************************************************************
   * Comprobar si existe conexion. Se actualiza la variable global        *
   * estconex.                                                            *
   * Se devuelve 0 si no hay conexion. 1 si la hay.                       *
   *************************************************************************/
{
  check_conexion();
  if (estconex==establecida && !hay_conexion()) {
    estconex=perdida;
    textcolor(7);
    printf ("\nConexion perdida\n\n");
    return 0;
  }
  if (estconex!=establecida && hay_conexion()) {
    estconex=establecida;
    printf ("\nConexion reestablecida\n\n");
    return 1;
  }
  if (hay_conexion()) return 1;
  else return 0;
}

void prompt()
/* ************************************************************************
   * Imprimir el prompt actual. En caso de que la conexi*n se haya es-    *
   * tablecido, el prompt ser* >. Si la conexi*n no se ha establecido el  *
   * prompt es de la forma *>                                             *
   *************************************************************************/
{
  textcolor(7);
  if (estconex==establecida) print (">");
  else print ("*>");
}

void help()
{
  presenta();
  printf ("Parametro incorrecto. Los parametros permitidos son: \n");
  printf (" -com1   : Utilizar el COM1 (valor por defecto)\n");
  printf (" -com2   : Utilizar el COM2\n");
  printf (" -noansi : Se usa un terminal no ansi\n");
  printf (" -e      : El CTSERVER se encuentra en la EEPROM\n");
}

void analiza_parametros(int argc, char *argv[])
/* ************************************************************************
   * Analizar los parametros de la linea de argumentos. Si se encuentran  *
   * errores se aborta el programa. Se actualizan las siguientes varia-   *
   * bles:                                                                *
   *                                                                      *
   * puerto --> Numero del puerto especificado.                           *
   *************************************************************************/
{
  char c;

  flage=0;   /* Por defecto se carga el ctserver */

  if (argc>3) {
    printf ("Demasiados parametros\n");
    exit(1);
  }
  while ((c = getopt(argc, argv, "c:n:he"))!=EOF) {
    switch (c) {
      case 'c': if (strcmp("om2",optarg)==0) puerto=COM2;
                else 
                  if (strcmp("om1",optarg)==0) puerto=COM1;
                  else puerto=COM2;  /* Por defecto COM2 */
                break;
      case 'n': if (strcmp("oansi",optarg)==0) configansi(0);
                else printf ("Parametro incorrecto\n");  
                break;
      case 'e': flage=1; 
                break;          
      case 'h':
      default: help();
               exit (0);
     }
  }
}

void sacar_puerto()
/* ***********************************
   * Sacar el puerto actual en uso.  *
   ************************************/
{ 
  low();
  printf ("Puerto actual: COM%u\n",puerto+1);
}

void sacar_posicion_eeprom()     
/* ***********************************
   * Sacar la posicion de la eeprom  *
   ************************************/
{
  printf ("Posicion eeprom: %X - %X \n",tope_min,tope_max);
}


void modelo_micro()              
/* ***********************************
   * Averigua que micro tenemos      *
   ************************************/
{
  byte dato_inicial;
				  /* Vamos a observar la posicion BF64 */
  if (check_conexion()) {
    load(&dato_inicial,0xbf64); 
    switch (dato_inicial&0xFF) {
      case 0xb6: micro=Ax; break;
      case 0xf8: micro=E2; break;
      default  : micro=xx; break;
    }
  }
  else printf ("\nNo hay conexion\n");
}

int detecta_ct6811()
{
  resetct6811();
  if (wait_break(100000)==0) {
    return 0;  /* No se detecta CT6811 */
  }
  return 1;    /* CT6811 detectada  */
}



int cargar_ctserver()
/******************************************************************/
/* Cargar el CTSERVER.                                            */
/******************************************************************/
{

  /* Matriz con el CTserver. La version es para 7680 Baudios  */
  /* Este es el CTSERVER empleado en versiones anteriores del */
  /* CTDIALOG                                                 */
   
//~ byte cts7680[256]={
//~ 0x20,0x05,0x00,0x00,0x00,0x00,0x00,0xCE,0x10,0x00,0x1F,0x2E,0x40,0xFC,0xCE,
//~ 0x10,0x00,0x8D,0x66,0x97,0x06,0x81,0x44,0x27,0x13,0x81,0x43,0x27,0x54,0x81,
//~ 0x41,0x27,0x17,0x81,0x42,0x27,0x0E,0x81,0x45,0x27,0x6A,0x7E,0x00,0x0E,0x86,
//~ 0x4A,0x8D,0x50,0x7E,0x00,0x0E,0x7C,0x00,0x06,0x20,0x03,0x7F,0x00,0x06,0x8D,
//~ 0x4A,0x18,0xDF,0x02,0x8D,0x45,0x18,0xDF,0x04,0x18,0x8C,0x00,0x00,0x27,0x23,
//~ 0x18,0xDE,0x02,0x96,0x06,0x4D,0x26,0x07,0x18,0xA6,0x00,0x8D,0x28,0x20,0x05,
//~ 0x8D,0x1D,0x18,0xA7,0x00,0x18,0x08,0x18,0xDF,0x02,0x18,0xDE,0x04,0x18,0x09,
//~ 0x18,0xDF,0x04,0x20,0xD7,0x7E,0x00,0x0E,0x8D,0x14,0x18,0xDF,0x02,0x18,0x6E,
//~ 0x00,0x1F,0x2E,0x20,0xFC,0xA6,0x2F,0x39,0x1F,0x2E,0x80,0xFC,0xA7,0x2F,0x39,
//~ 0x36,0x37,0x8D,0xEE,0x16,0x8D,0xEB,0x18,0x8F,0x33,0x32,0x39,0x8D,0xF2,0x18,
//~ 0xDF,0x02,0x8D,0xED,0x18,0xDF,0x04,0x18,0x8C,0x00,0x00,0x27,0x34,0x18,0xDE,
//~ 0x02,0xC6,0x16,0xF7,0x10,0x3B,0x18,0xE7,0x00,0xC6,0x17,0xF7,0x10,0x3B,0x8D,
//~ 0x28,0xC6,0x02,0xF7,0x10,0x3B,0x8D,0xBD,0x18,0xA7,0x00,0xC6,0x03,0xF7,0x10,
//~ 0x3B,0x8D,0x17,0x8D,0xB8,0x18,0x08,0x18,0xDF,0x02,0x18,0xDE,0x04,0x18,0x09,
//~ 0x18,0xDF,0x04,0x20,0xC6,0x7F,0x10,0x3B,0x7E,0x00,0x0E,0x18,0x3C,0x18,0xCE,
//~ 0x0D,0x10,0x18,0x09,0x18,0x8C,0x00,0x00,0x26,0xF8,0x18,0x38,0x39,0x00,0x00,
//~ 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
//~ 0x00,};

  /* Matriz con el CTserver. Version para 9600 Baudios */

byte cts9600[256]={
0x20,0x05,0x00,0x00,0x00,0x00,0x00,0xCE,0x10,0x00,0x1F,0x2E,0x40,0xFC,0x86,
0x30,0xA7,0x2B,0xCE,0x10,0x00,0x8D,0x66,0x97,0x06,0x81,0x44,0x27,0x13,0x81,
0x43,0x27,0x54,0x81,0x41,0x27,0x17,0x81,0x42,0x27,0x0E,0x81,0x45,0x27,0x6A,
0x7E,0x00,0x12,0x86,0x4A,0x8D,0x50,0x7E,0x00,0x12,0x7C,0x00,0x06,0x20,0x03,
0x7F,0x00,0x06,0x8D,0x4A,0x18,0xDF,0x02,0x8D,0x45,0x18,0xDF,0x04,0x18,0x8C,
0x00,0x00,0x27,0x23,0x18,0xDE,0x02,0x96,0x06,0x4D,0x26,0x07,0x18,0xA6,0x00,
0x8D,0x28,0x20,0x05,0x8D,0x1D,0x18,0xA7,0x00,0x18,0x08,0x18,0xDF,0x02,0x18,
0xDE,0x04,0x18,0x09,0x18,0xDF,0x04,0x20,0xD7,0x7E,0x00,0x12,0x8D,0x14,0x18,
0xDF,0x02,0x18,0x6E,0x00,0x1F,0x2E,0x20,0xFC,0xA6,0x2F,0x39,0x1F,0x2E,0x80,
0xFC,0xA7,0x2F,0x39,0x36,0x37,0x8D,0xEE,0x16,0x8D,0xEB,0x18,0x8F,0x33,0x32,
0x39,0x8D,0xF2,0x18,0xDF,0x02,0x8D,0xED,0x18,0xDF,0x04,0x18,0x8C,0x00,0x00,
0x27,0x34,0x18,0xDE,0x02,0xC6,0x16,0xF7,0x10,0x3B,0x18,0xE7,0x00,0xC6,0x17,
0xF7,0x10,0x3B,0x8D,0x28,0xC6,0x02,0xF7,0x10,0x3B,0x8D,0xBD,0x18,0xA7,0x00,
0xC6,0x03,0xF7,0x10,0x3B,0x8D,0x17,0x8D,0xB8,0x18,0x08,0x18,0xDF,0x02,0x18,
0xDE,0x04,0x18,0x09,0x18,0xDF,0x04,0x20,0xC6,0x7F,0x10,0x3B,0x7E,0x00,0x12,
0x18,0x3C,0x18,0xCE,0x0D,0x10,0x18,0x09,0x18,0x8C,0x00,0x00,0x26,0xF8,0x18,
0x38,0x39,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,};


  print ("\nCargando CTSERVER:\n\n");
  set_break_timeout(500000);
  printf("0%%     50%%   100%%\n");
  print ("................\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
  
  if (cargar_ramint(cts9600,accion_load)==0) {
    printf ("\nError: %s\n",getloaderror());
    return 0;
  };
  printf ("\nOK!\n");
  return 1;
}

/*            ***********************
  ************* Programa PRINCIPAL  ************
              ***********************             */

int main(argc,argv)
int argc;
char *argv[];
{

  puerto =COM2;    
  analiza_parametros(argc,argv); 
  if (abrir_puerto_serie(puerto)==0) {
    printf ("Error al abrir puerto serie: %s\n\n",getserial_error());
    exit(1);
  }  
  abrir_consola();
  if (flage) {
    baudios(9600); 
    resetct6811();  /* En los modelos E2 al hacer reset salta a la EEPROM */
    usleep(100000);
    enviar_break(); /* En los A1 hay que enviar un break  */
  }  
  else {                   
    baudios(7680);
    if (detecta_ct6811()) cargar_ctserver();
    baudios(9600);
  }  
  usleep(200000);
  vaciar_buffer_tx();
  vaciar_buffer_rx();
  sacar_puerto();
  establecer_conexion();
  modelo_micro();
  ejecutar_info();
  printf ("\n");
  
  do {
    vaciar_buffer_rx();
    comprobar_conexion();
    prompt();
  } while(procesar_comando());
  low();
  printf("\n");
  cerrar_puerto_serie();
  cerrar_consola();
  return 0;
}
