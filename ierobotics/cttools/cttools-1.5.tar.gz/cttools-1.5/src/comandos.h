/**************************************************************************/
/**************************************************************************/

#include <cts/ctclient.h>

void printhex(byte num);
void printchar(unsigned short int num);
void printdir(uint dir);
int procesar_comando();
