/***************************************************************************/
/*  CT294.                                                                 */
/*-------------------------------------------------------------------------*/
/***************************************************************************/

/*
****************************************************************************
*                                                                          *
*       INFORMACION SOBRE LA TARJETA CT293+                                *
*                                                                          *
*   La  tarjeta permite realizar las siguientes funciones:                 *
*                                                                          * 
*        - mover dos motores de continua o uno paso_paso (PUERTO A)        *
*        - leer el estado de cuatro sensores de infrarrojos (PUERTO A)     *
*        - leer ocho entradas digitales o analogicas . (Puerto E)          *
*                                                                          *
*   Tambien tiene otras funciones que amplian la versatibilidad de la      *
*  misma.                                                                  *
*         - Alimentacion externa o interna.                                *
*         - Desconexion de los infrarrojos no utilizados.                  *
*         - Conexion con clemas                                            *
*                                                                          *
*                                                                          *
*                                                                          *
*   La CT293+ se ha desarrollado para unirse a la CT6811, aunque se puede  *
*  conectar a cualquier sistema digital. Este programa supone que esta     *
*  conectada a la CT293+. Cargaremos en el servidor CTSERVER y a traves de *
*  el actuaremos sobre la CT293+.                                          *
*                                                                          *
*   La actuacion con dicho servidor se realiza por medio de la libreria    *
*  CTS que ofrece servicios de alto nivel para la programacion.            * 
*                                                                          *
*                                                                          *
*   Por ultimo destacamos que este programa mantiene la compatibilidad con *
* la tarjeta CT293 ( antecesora de la que ahora nos trata ).               *
*                                                                          *
****************************************************************************
*/

/* Esta versi�n funciona en SUSE ,corrige el bug que apareci� en ventanas */
/* Esta versi�n corrige el problema de micro E2 con el PA3                */

#include <stdlib.h>
#include <unistd.h>
#include <curses.h>
#include <string.h>
#include <cts/serie.h>
#include <cts/ctclient.h>
#include <cts/r6811pc.h>
#include <cts/bootstrp.h>
#include "io.h"


/*
********************************************************************
* Variables del sistema y estructura de datos                      *
********************************************************************
*/

#define PA 1
#define PE 0

#define B1 ACS_BOARD 
#define B2 ACS_CKBOARD 
#define B3 ACS_BLOCK  

#define LT ACS_LTEE 
#define RT ACS_RTEE
#define TT ACS_TTEE  
#define BT ACS_BTEE 

const char version[]={"1.5.0"};
const char fecha[]={"Julio 2004"};
 
byte puertoE,puertoA;
int  bit_activo_A=0, bit_activo_E=0 ;
int  puerto;
byte conversores[8];

WINDOW *ventana[50];


/*
*********************************************************************
*     SUBRUTINAS DE CONTROL DEL PROGRAMA                            *
*********************************************************************
*/

void accion_rxcar()
{
}

void accion_break()
{
}

void nada()
{
}

void dprint(char *cad)
/******************************************************/
/* Imprimir una cadena directamente en la pantalla    */
/******************************************************/
{
  int i=0;
  
  while (cad[i]!=0){
    write(1,&cad[i],1);
    i++;
  }
}

void clrscr()
/************************/
/*  Borrar la pantalla  */
/************************/
{
    dprint ("[2J");     /* Borrar la pantalla                        */
    dprint ("[1;1H");   /* Situar cursor en esquina superior derecha */
  
}


/*
 ***************************************************************************                                                                      �
 *   SUBRUTINAS DE PRESENTACION DEL PROGRAMA                               *
 ***************************************************************************
*/

void inicia()

{
 if(!(initscr())){
  fprintf(stderr,"Error en la inicializacion.\n\n");
  exit(1);
 }
 start_color();
 noecho();
 raw();
 
 init_pair(1,COLOR_YELLOW,COLOR_BLACK);
 init_pair(2,COLOR_WHITE,COLOR_BLACK);
 init_pair(3,COLOR_GREEN,COLOR_BLACK);
 init_pair(4,COLOR_RED,COLOR_BLACK); 
 init_pair(5,COLOR_CYAN,COLOR_BLACK);
 init_pair(6,COLOR_YELLOW,COLOR_BLUE);
 init_pair(7,COLOR_GREEN,COLOR_BLUE);
 init_pair(8,COLOR_RED,COLOR_BLUE); 
 init_pair(9,COLOR_WHITE,COLOR_BLUE);
 init_pair(10,COLOR_BLUE,COLOR_BLUE);
 
}


void actualiza(WINDOW *win)
{
 wnoutrefresh(win);
 doupdate(); 
}


void ventanas(int x,int y,int alt,int anch,int pair,int tipo)
/*
*******************************
* Dibujar una ventana simple  *
*******************************
*/
{
	static int numero=0;

	numero++;
	ventana[numero]=newwin(alt,anch,y-1,x-1);
	if (has_colors()){
	  wattrset(ventana[numero],COLOR_PAIR(pair)|tipo);
	}
	else{ 
	  wattrset(ventana[numero],A_BOLD);  
	} 
	box(ventana[numero],0,0);
	wrefresh(ventana[numero]);
        actualiza(ventana[numero]);
}


void menu(int puerto)
/*
****************************************************************************
*   Dibuja el marco de trabajo.                                            *
****************************************************************************
*/
{
  int i;

  clrscr();
  inicia();                       

        // creamos esta ventana al principio. Es la ventana global.

	ventana[40]=newwin(25,80,0,0);
	if (has_colors()){
	  wattrset(ventana[40],COLOR_PAIR(5)|A_BOLD);
	}
	else{ 
	  wattrset(ventana[40],A_BOLD);  
	} 
	wrefresh(ventana[40]);
        actualiza(ventana[40]);


  if (has_colors()){
    wattrset(ventana[40],COLOR_PAIR(6) | A_BOLD);
    mvwprintw(ventana[40],0,0," CT293+ TEST   ");
    wattrset(ventana[40],COLOR_PAIR(8) | A_BOLD);  
    mvwprintw(ventana[40],0,15,"Version %s",version);
    wattrset(ventana[40],COLOR_PAIR(7) | A_BOLD);
    mvwprintw(ventana[40],0,28," IEAROBOTICS, %s",fecha);
    wattrset(ventana[40],COLOR_PAIR(9) | A_BOLD);
    mvwprintw(ventana[40],0,60,"        COM%i       ", puerto+1);
  }
  else{ 
    wattrset(ventana[40],A_REVERSE);  
    mvwprintw(ventana[40],0,0," CT293+ TEST   Version %s     IEAROBOTICS, %s ",version,fecha);  
    mvwprintw(ventana[40],0,59,"         COM%i      ", puerto+1); 
    
  } 

  ventanas(1,3,6,52,5,A_BOLD);
  ventanas(1,11,6,52,5,A_BOLD);
  ventanas(15,19,3,66,5,A_BOLD);   
  ventanas(1,19,3,9,5,A_BOLD);
  ventanas(9,19,3,7,5,A_BOLD);
  ventanas(54,3,6,7,5,A_BOLD);
  ventanas(54,11,6,7,5,A_BOLD);
  ventanas(54,8,3,7,5,A_BOLD);
  ventanas(54,16,3,7,5,A_BOLD);
  ventanas(62,4,4,19,5,A_BOLD);
  ventanas(62,7,4,19,5,A_BOLD);
  ventanas(62,13,3,19,5,A_BOLD);
  ventanas(62,15,3,19,5,A_BOLD); 

  wattrset(ventana[40],COLOR_PAIR(5)|A_BOLD);  
  mvwprintw(ventana[40],24,0,"  CANAL 0   CANAL 1   CANAL 2   CANAL 3");
  mvwprintw(ventana[40],24,41," CANAL 4   CANAL 5   CANAL 6   CANAL 7");   
  for (i=0; i<=7; i++) {
    ventanas(1+i*10,22,3,10,5,A_BOLD);
  }

  wattrset(ventana[40],COLOR_PAIR(5) | A_BOLD);  
  mvwprintw(ventana[40],2,63,"ESTADO MOTORES");
  mvwprintw(ventana[40],11,63,"ESTADO CONEXION");

  wattrset(ventana[13],COLOR_PAIR(1) | A_BOLD);  
  wmove(ventana[13],1,1); whline(ventana[13],0,16);
  wattrset(ventana[12],COLOR_PAIR(1) | A_BOLD);  
  mvwprintw(ventana[12],1,7,"Activa");                 

  for (i=0 ; i<=7 ; i++) {
	ventanas(3+i*5,12,3,5,1,A_BOLD);
	wattrset(ventana[40],COLOR_PAIR(1)|A_BOLD);         
	mvwprintw(ventana[40],14,3+i*5,"PE%i",7-i);
        if ( (i<=4) && (i>=1) ){
	  ventanas(3+i*5,4,3,5,2,A_BOLD);
          wattrset(ventana[40],COLOR_PAIR(2)|A_BOLD);        
          mvwprintw(ventana[40],6,3+i*5,"PA%i",7-i);	
	}
	else {  
	  ventanas(3+i*5,4,3,5,1,A_BOLD);
          wattrset(ventana[40],COLOR_PAIR(1)|A_BOLD);        
          mvwprintw(ventana[40],6,3+i*5,"PA%i",7-i);	          
	}

  }
  
  wattrset(ventana[11],COLOR_PAIR(5)|A_BOLD);
  wattrset(ventana[13],COLOR_PAIR(5)|A_BOLD);

  wmove(ventana[8],0,0);  whline(ventana[8],LT,1); 
  wmove(ventana[8],0,6);  whline(ventana[8],RT,1);
  wmove(ventana[13],0,0); whline(ventana[13],LT,1); 
  wmove(ventana[13],0,18);whline(ventana[13],RT,1);
  wmove(ventana[9],0,0);  whline(ventana[9],LT,1); 
  wmove(ventana[9],0,6);  whline(ventana[9],RT,1);
  wmove(ventana[11],0,0); whline(ventana[11],LT,1); 
  wmove(ventana[11],0,18);whline(ventana[11],RT,1);
  wmove(ventana[5],0,0);  whline(ventana[5],TT,1); 
  wmove(ventana[5],2,0);  whline(ventana[5],BT,1);
  wmove(ventana[3],0,0);  whline(ventana[3],TT,1); 
  wmove(ventana[3],2,0);  whline(ventana[3],BT,1);



  wattrset(ventana[40],COLOR_PAIR(2) | A_BOLD);  
  mvwprintw(ventana[40],8,3,"Avanzar        Derecha          Activar bits");
  mvwprintw(ventana[40],9,3,"Retroceder     Izquierda        Parar");
  mvwprintw(ventana[40],16,8,"Seleccionar canal analagico");
  mvwprintw(ventana[40],17,8,"Seleccionar puerto");
  
  
  
  wattrset(ventana[10],COLOR_PAIR(2)|A_BOLD);
  mvwprintw(ventana[10],1,2,"Motor 1");
  mvwprintw(ventana[10],2,12,"<-  I"); 
  wattrset(ventana[10],COLOR_PAIR(2));
  wmove(ventana[10],2,2); 
  whline(ventana[10],B2,7);
  whline(ventana[10],B1-(B1-B2)*(!has_colors()),5);

  wattrset(ventana[11],COLOR_PAIR(2)|A_BOLD);
  mvwprintw(ventana[11],1,2,"Motor 2");
  mvwprintw(ventana[11],2,12,"->  D");
  wattrset(ventana[11],COLOR_PAIR(2));
  wmove(ventana[11],2,2); 
  whline(ventana[11],B2,7);
  whline(ventana[11],B1-(B1-B2)*(!has_colors()),5);

  wattrset(ventana[40],COLOR_PAIR(4) | A_BOLD);
  mvwprintw(ventana[40],8,1,"Q"); mvwprintw(ventana[40],8,16,"P");
  mvwprintw(ventana[40],9,1,"A"); mvwprintw(ventana[40],9,16,"O");
  mvwprintw(ventana[40],8,1,"Q");
  mvwprintw(ventana[40],8,30,"1..8");
  mvwprintw(ventana[40],9,30,"SPC");
  mvwprintw(ventana[40],16,1,"1..8");
  mvwprintw(ventana[40],17,1,"C");
  
  wattrset(ventana[1],COLOR_PAIR(4) | A_BOLD);
  mvwprintw(ventana[1],2,43,"Puerto A");
  wattrset(ventana[2],COLOR_PAIR(2) | A_BOLD);    
  mvwprintw(ventana[2],2,43,"Puerto E");
  wrefresh(ventana[2]);
}


void refresca_puertoA()
{
  int i;

  load(&puertoA,PORTA);  // leemos el PUERTA
  for(i=0; i<=7; i++) {
	attrset(COLOR_PAIR(1)|A_BOLD);
        if ( (i>=3) && (i<=6) ) attrset(COLOR_PAIR(2)|A_BOLD);
	mvwprintw(ventana[37-i*2],1,2,"%i",(puertoA>>i)&0x01);   
  }
  
  wattrset(ventana[1],COLOR_PAIR(2)|A_BOLD);
  mvwprintw(ventana[1],3,44,"0x%X ",puertoA&0xFF);
}


void refresca_puertoE()
{
  int i;

  load(&puertoE,PORTE);  // leemos el PUERTO A
  attrset(COLOR_PAIR(1)|A_BOLD);
  for(i=0; i<=7; i++) {
	mvwprintw(ventana[36-i*2],1,2,"%i", (puertoE>>i)&0x01);
  }
  
  wattrset(ventana[2],COLOR_PAIR(2)|A_BOLD); 
  mvwprintw(ventana[2],3,44,"0x%X ",puertoE&0xFF);
}



void dib_motor()
{
  if ( (puertoA&0x08)==0x08 ) {
	 wattrset(ventana[10],COLOR_PAIR(2)|A_BOLD);
         wmove(ventana[10],2,2);
         whline(ventana[10],B2,7);
         whline(ventana[10],B1-(B1-B2)*(!has_colors()),5);
  }
  else {
	 wattrset(ventana[10],COLOR_PAIR(2));
         wmove(ventana[10],2,2);
	 whline(ventana[10],B2,7);
	 whline(ventana[10],B1-(B1-B2)*(!has_colors()),5);
  }

  if ( (puertoA&0x10)==0x10 ) {
	 wattrset(ventana[11],COLOR_PAIR(2)|A_BOLD);
	 wmove(ventana[11],2,2); 
	 whline(ventana[11],B2,7);
         whline(ventana[11],B1-(B1-B2)*(!has_colors()),5);
  }
  else {
	 wattrset(ventana[11],COLOR_PAIR(2));
	 wmove(ventana[11],2,2); 
	 whline(ventana[11],B2,7);
         whline(ventana[11],B1-(B1-B2)*(!has_colors()),5);
  }
  if ( (puertoA&0x20)==0x20 ) {
	 wattrset(ventana[10],COLOR_PAIR(2)|A_BOLD);
	 mvwprintw(ventana[10],2,12,"->  D");
  }
  else {
	 wattrset(ventana[10],COLOR_PAIR(2)|A_BOLD);
	 mvwprintw(ventana[10],2,12,"<-  I");
  }

  if ( (puertoA&0x40)==0x40 ) {
	 wattrset(ventana[11],COLOR_PAIR(2)|A_BOLD);
	 mvwprintw(ventana[11],2,12,"<-  I");
  }
  else {
	 wattrset(ventana[11],COLOR_PAIR(2)|A_BOLD);
	 mvwprintw(ventana[11],2,12,"->  D");
  }
}


void dib_bit(int bit,int tipo)
/*
****************************************************************************
* Dibuja el bit seleccionado en grande                                     *
*   bit -> numero del bit que queremos.                                    *
*   tipo-> se refiere si el bit es del puerto A (tipo=1) o del E (tipo=0). *
****************************************************************************
*/
{
  int valor;
  if (tipo==1) {
	valor=(puertoA>>bit)&0x01;
  }
  else {
	valor=(puertoE>>bit)&0x01;
  }
  wattrset(ventana[7-tipo],COLOR_PAIR(2)|A_BOLD);
  wattrset(ventana[9-tipo],COLOR_PAIR(2)|A_BOLD);
  if (valor) {
        mvwprintw(ventana[7-tipo],1,3, "* ");
	mvwprintw(ventana[7-tipo],2,2,"** ");
	mvwprintw(ventana[7-tipo],3,2," * ");
	mvwprintw(ventana[7-tipo],4,2,"***");
	mvwprintw(ventana[9-tipo],1,2,"P%c%i",'E'-tipo*('E'-'A'),bit);
  }
  else {
	mvwprintw(ventana[7-tipo],1,3, "*");
	mvwprintw(ventana[7-tipo],2,2,"* *");
	mvwprintw(ventana[7-tipo],3,2,"* *");
	mvwprintw(ventana[7-tipo],4,2," * ");
	mvwprintw(ventana[9-tipo],1,2,"P%c%i",'E'-tipo*('E'-'A'),bit);
  }
}


void dib_ana_uno(int bit)
/*
********************************************************************
* Dibuja el canal analogico seleccionado en grande   		   *
*   bit -> numero del canal que queremos.                          *
********************************************************************
*/
{
	int j,tope;

	wattrset(ventana[4],COLOR_PAIR(2)|A_BOLD);
	mvwprintw(ventana[4],1,1,"Canal %i",bit);
	wattrset(ventana[5],COLOR_PAIR(2)|A_BOLD);	
	mvwprintw(ventana[5],1,1,"0x%X ",conversores[bit]&0xff);
	tope=((conversores[bit]&0xff)>>2);
	wattrset(ventana[3],COLOR_PAIR(4)|A_BOLD);
	for (j=1; j<=64-tope; j++) {
	 mvwprintw(ventana[3],1,65-j," ");
	}
	for (j=0; j<=tope; j++) {
          wmove(ventana[3],1,1+j);
          wdelch(ventana[3]);
	  if (j<=15) {
	    wattrset(ventana[3],COLOR_PAIR(4));
	    if (!has_colors()) wattrset(ventana[3],A_NORMAL);
	    winsch(ventana[3],B2);
	  }
	  if ((j>=16) && (j<=31) ) {
	    wattrset(ventana[3],COLOR_PAIR(4)|A_BOLD);
	    if (!has_colors()) wattrset(ventana[3],A_NORMAL);
	    winsch(ventana[3],B1-(B1-B2)*(!has_colors()));
	  }  
	  if ((j>=32) && (j<=47) ) {
	    wattrset(ventana[3],COLOR_PAIR(4)|A_BOLD);
	    if (!has_colors()) wattrset(ventana[3],A_NORMAL);
	    winsch(ventana[3],B2);
	  }
	  if ( j>=48 ) {
	    wattrset(ventana[3],COLOR_PAIR(4)|A_BOLD);
	    if (!has_colors()) wattrset(ventana[3],A_NORMAL);	    
	    winsch(ventana[3],B3-(B3-B2)*(!has_colors()));
	  }
	}
}


void dib_ana_todos()
/*
*************************************************************************
* Dibuja los canales analogicos en pequeno                              *
* despues de leer un grupo activa la siguiente la conversion del grupo  *
* siguiente.                                                            *
*************************************************************************
*/
{
  byte temp,error=1;
  int  tope,i,j,fin=0;

  do {
   error=load(&temp,ADCTL);
   if ( (temp&0x80)==0x80) {
	 error=load_block(conversores,4,ADR1,nada);
	 store(0x14,ADCTL);
	 fin=1;
   }
  } while ( (!fin)&(error) );

  for (i=0 ; i<=3 ; i++ ) {
     tope=((conversores[i]&0xff)>>5);
     for (j=0; j<=7-tope; j++) {
	mvwprintw(ventana[14+i],1,8-j," ");
     }
     for (j=0; j<=tope; j++) {
        wmove(ventana[14+i],1,1+j);
        wdelch(ventana[14+i]);
	if (j<=3) {
	    wattrset(ventana[14+i],COLOR_PAIR(3));
	    if (!has_colors()) wattrset(ventana[14+i],A_NORMAL);
	    winsch(ventana[14+i],B2);
        }
	if ((j>=4) && (j<=5) ) {
	    wattrset(ventana[14+i],COLOR_PAIR(3)|A_BOLD);
	    if (!has_colors()) wattrset(ventana[14+i],A_NORMAL);
	    winsch(ventana[14+i],B1-(B1-B2)*(!has_colors()));
        }
	if ( j>=6 ) {
	    wattrset(ventana[14+i],COLOR_PAIR(3)|A_BOLD);
	    if (!has_colors()) wattrset(ventana[14+i],A_NORMAL);
	    winsch(ventana[14+i],B2);
        }
     }
  }

  do {
   error=load(&temp,ADCTL);
   if ( (temp&0x80)==0x80) {
	 error=load_block(&conversores[4],4,ADR1,nada);
	 store(0x10,ADCTL);
	 fin=0;
   }
  } while ( fin&error);


  for (i=4 ; i<=7 ; i++ ) {
     tope=((conversores[i]&0xff)>>5);
     for (j=0; j<=7-tope; j++) {
 	mvwprintw(ventana[14+i],1,8-j," ");
     }
     for (j=0; j<=tope; j++) {
        wmove(ventana[14+i],1,1+j);
        wdelch(ventana[14+i]);
	if (j<=3) {
	    wattrset(ventana[14+i],COLOR_PAIR(3));
	    if (!has_colors()) wattrset(ventana[14+i],A_NORMAL);
	    winsch(ventana[14+i],B2);
        }
	if ((j>=4) && (j<=5) ) {
	    wattrset(ventana[14+i],COLOR_PAIR(3)|A_BOLD);
	    if (!has_colors()) wattrset(ventana[14+i],A_NORMAL);
	    winsch(ventana[14+i],B1-(B1-B2)*(!has_colors()));
        }
	if ( j>=6 ) {
	    wattrset(ventana[14+i],COLOR_PAIR(3)|A_BOLD);
	    if (!has_colors()) wattrset(ventana[14+i],A_NORMAL);
	    winsch(ventana[14+i],B2);
        }
     }
  }
}


/*
 ****************************************************************************
 *   SUBRUTINAS DE DIALOGO CON EL SERVIDOR                                  *
 ****************************************************************************
*/

void activar_conversores()
{
     store(0x80,OPTION);  // Activamos conversor
     store(0x10,ADCTL);   // Conversion multiple 4 primeros canales sin SCAN
}

void activar_puertoA()
{
     store(0x08,PACTL);  // Activamos PA3 como salida
}


void comprueba_conexion()
{
  static int x=0;

  if ( !hay_conexion()) {
	 wattrset(ventana[12],COLOR_PAIR(4)|A_BOLD);
	 mvwprintw(ventana[12],1,7,"Perdida"); 
  }
  else {
	 wattrset(ventana[12],COLOR_PAIR(1)|A_BOLD);	 
	 mvwprintw(ventana[12],1,7,"Activa ");
	 wattrset(ventana[13],COLOR_PAIR(1)|A_BOLD);
         wmove(ventana[13],1,9-x); whline(ventana[13],0,1);
         wmove(ventana[13],1,9+x++); whline(ventana[13],0,1);         
         if (x>=9) x=0;
	 wattrset(ventana[13],COLOR_PAIR(3)|A_BOLD);
	 mvwprintw(ventana[13],1,9+x,">");
	 mvwprintw(ventana[13],1,9-x,"<");
  }
}


/*
 ***************************************************************************
 *   SUBRUTINA DE PROCESAMIENTO DE COMANDOS                                *
 ***************************************************************************
*/

int procesar_comando()
{
  char c;
  static int turno=0; // 0-> puerto A ,, 1 -> puerto_E

  if ( kbhit() ) {
   c=getchar(); 
     switch(c) {
     case '0': if (turno) bit_activo_E=0;
               else bit_activo_A=0;
               break;
     case '1': if (turno) bit_activo_E=1;
               else bit_activo_A=1;
               break;
     case '2': if (turno) bit_activo_E=2;
               else bit_activo_A=2;
               break;
     case '3': if (turno) bit_activo_E=3;
               else {
                  puertoA=puertoA^0x08; dib_motor();store(puertoA,PORTA); 
               }  break;
     case '4': if (turno) bit_activo_E=4;
               else {
                  puertoA=puertoA^0x10; dib_motor();store(puertoA,PORTA);
               }  break;
     case '5': if (turno) bit_activo_E=5;
               else {
                  puertoA=puertoA^0x20; dib_motor();store(puertoA,PORTA); 
               }  break;
     case '6': if (turno) bit_activo_E=6;
               else {
                  puertoA=puertoA^0x40; dib_motor();store(puertoA,PORTA); 
               }  break;
     case '7': if (turno) bit_activo_E=7;
               else bit_activo_A=7;
               break;
     case ' ': puertoA=0x00; dib_motor();store(puertoA,PORTA); break;
     case 'q': puertoA=0x18; dib_motor();store(puertoA,PORTA); break;
     case 'a': puertoA=0x78; dib_motor();store(puertoA,PORTA); break;
     case 'p': puertoA=0x58; dib_motor();store(puertoA,PORTA); break;
     case 'o': puertoA=0x38; dib_motor();store(puertoA,PORTA); break;
     case 'w': store(0xf0,PORTB);  break;
     case 's': store(0x20,PORTB);  break;
     case 'x': store(0x00,PORTB);  break;
     case 'c': if (turno) {   // cambiar a puerto_A
                  wattrset(ventana[1],COLOR_PAIR(4) | A_BOLD);
                  mvwprintw(ventana[1],2,43,"Puerto A");
                  wattrset(ventana[2],COLOR_PAIR(2) | A_BOLD);    
                  mvwprintw(ventana[2],2,43,"Puerto E");
                  wrefresh(ventana[2]);
                  turno=0;
               }
               else {       // cambiar a puerto_E
                  wattrset(ventana[1],COLOR_PAIR(2) | A_BOLD);
                  mvwprintw(ventana[1],2,43,"Puerto A");
                  wattrset(ventana[2],COLOR_PAIR(4) | A_BOLD);    
                  mvwprintw(ventana[2],2,43,"Puerto E");
                  wrefresh(ventana[2]);
                  turno=1;
               }          
               break;
     case 27 : return 0;    
   } 
  }
  return 1;
}



void analiza_parametros(int argc, char *argv[])
/* ************************************************************************
   * Analizar los parametros de la linea de argumentos. Si se encuentran  *
   * errores se aborta el programa. Se actualizan las siguientes varia-   *
   * bles:                                                                *
   *                                                                      *
   * puerto --> Numero del puerto especificado.                           *
   *************************************************************************/
{
  char c;

  if (argc>2) {
    printf ("Demasiados parametros\n");
    exit(1);
  }
  while ((c = getopt(argc, argv, "c:h"))!=EOF) {
    switch (c) {
      case 'c': if (strcmp("om2",optarg)==0) puerto=COM2;
                else 
                  if (strcmp("om1",optarg)==0) puerto=COM1;
                  else puerto=COM2;  /* Por defecto COM2 */
                break;
      case 'h':
      default: 
               printf("\nParametros permtidos:\n\n");
               printf("-com1 : Establece puerto de comunicaciones COM1\n");
               printf("-com2 : Establece puerto de comunicaciones COM2\n");
               printf("-h    : Saca este menu\n");
               exit (0);
     }
  }
}

int detecta_ct6811()
{
  resetct6811();
  if (wait_break(100000)==0) {
    return 0;  /* No se detecta CT6811 */
  }
  return 1;    /* CT6811 detectada  */
}



void establecer_conexion()
/* ************************************************************************
   * Establecer la conexion con el servidor CTSERVER que debe estar eje-  *
   * cutandose en la entrenadora.                                         *
   *************************************************************************/
 {
    printf ("Estableciendo conexion con tarjeta..... ");
    usleep(300000);
    if (check_conexion()) {
      printf("conexion establecida\n");
    }
    else {
      printf("CONEXION NO ESTABLECIDA\n");
    }
 }

void accion_load()
/********************************************/
/* Accion al realiar al cargar el servidor  */
/********************************************/
{
  static int i=0;
  static int n=0;
  
  if (n==16 || i==255) {
    n=0;
    print ("*");
  }
  i++;
  n++;
}

int cargar_ctserver()
/******************************************************************/
/* Cargar el CTSERVER. El CTSERVER que se carga esta configurado  */
/* para la velocidad de 7680 baudios.                             */
/******************************************************************/
{
  /* Matriz con el CTserver. La version es para 7680 Baudios */
//~ byte programint[256]={
//~ 0x20,0x05,0x00,0x00,0x00,0x00,0x00,0xCE,0x10,0x00,0x1F,0x2E,0x40,0xFC,0xCE,
//~ 0x10,0x00,0x8D,0x66,0x97,0x06,0x81,0x44,0x27,0x13,0x81,0x43,0x27,0x54,0x81,
//~ 0x41,0x27,0x17,0x81,0x42,0x27,0x0E,0x81,0x45,0x27,0x6A,0x7E,0x00,0x0E,0x86,
//~ 0x4A,0x8D,0x50,0x7E,0x00,0x0E,0x7C,0x00,0x06,0x20,0x03,0x7F,0x00,0x06,0x8D,
//~ 0x4A,0x18,0xDF,0x02,0x8D,0x45,0x18,0xDF,0x04,0x18,0x8C,0x00,0x00,0x27,0x23,
//~ 0x18,0xDE,0x02,0x96,0x06,0x4D,0x26,0x07,0x18,0xA6,0x00,0x8D,0x28,0x20,0x05,
//~ 0x8D,0x1D,0x18,0xA7,0x00,0x18,0x08,0x18,0xDF,0x02,0x18,0xDE,0x04,0x18,0x09,
//~ 0x18,0xDF,0x04,0x20,0xD7,0x7E,0x00,0x0E,0x8D,0x14,0x18,0xDF,0x02,0x18,0x6E,
//~ 0x00,0x1F,0x2E,0x20,0xFC,0xA6,0x2F,0x39,0x1F,0x2E,0x80,0xFC,0xA7,0x2F,0x39,
//~ 0x36,0x37,0x8D,0xEE,0x16,0x8D,0xEB,0x18,0x8F,0x33,0x32,0x39,0x8D,0xF2,0x18,
//~ 0xDF,0x02,0x8D,0xED,0x18,0xDF,0x04,0x18,0x8C,0x00,0x00,0x27,0x34,0x18,0xDE,
//~ 0x02,0xC6,0x16,0xF7,0x10,0x3B,0x18,0xE7,0x00,0xC6,0x17,0xF7,0x10,0x3B,0x8D,
//~ 0x28,0xC6,0x02,0xF7,0x10,0x3B,0x8D,0xBD,0x8D,0xC2,0x18,0xA7,0x00,0xC6,0x03,
//~ 0xF7,0x10,0x3B,0x8D,0x15,0x18,0x08,0x18,0xDF,0x02,0x18,0xDE,0x04,0x18,0x09,
//~ 0x18,0xDF,0x04,0x20,0xC6,0x7F,0x10,0x3B,0x7E,0x00,0x0E,0x18,0x3C,0x18,0xCE,
//~ 0x0D,0x10,0x18,0x09,0x18,0x8C,0x00,0x00,0x26,0xF8,0x18,0x38,0x39,0x00,0x00,
//~ 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
//~ 0x00,};


  /* Matriz con el CTserver. Version para 9600 baudios */
byte cts9600[256]={
0x20,0x05,0x00,0x00,0x00,0x00,0x00,0xCE,0x10,0x00,0x1F,0x2E,0x40,0xFC,0x86,
0x30,0xA7,0x2B,0xCE,0x10,0x00,0x8D,0x66,0x97,0x06,0x81,0x44,0x27,0x13,0x81,
0x43,0x27,0x54,0x81,0x41,0x27,0x17,0x81,0x42,0x27,0x0E,0x81,0x45,0x27,0x6A,
0x7E,0x00,0x12,0x86,0x4A,0x8D,0x50,0x7E,0x00,0x12,0x7C,0x00,0x06,0x20,0x03,
0x7F,0x00,0x06,0x8D,0x4A,0x18,0xDF,0x02,0x8D,0x45,0x18,0xDF,0x04,0x18,0x8C,
0x00,0x00,0x27,0x23,0x18,0xDE,0x02,0x96,0x06,0x4D,0x26,0x07,0x18,0xA6,0x00,
0x8D,0x28,0x20,0x05,0x8D,0x1D,0x18,0xA7,0x00,0x18,0x08,0x18,0xDF,0x02,0x18,
0xDE,0x04,0x18,0x09,0x18,0xDF,0x04,0x20,0xD7,0x7E,0x00,0x12,0x8D,0x14,0x18,
0xDF,0x02,0x18,0x6E,0x00,0x1F,0x2E,0x20,0xFC,0xA6,0x2F,0x39,0x1F,0x2E,0x80,
0xFC,0xA7,0x2F,0x39,0x36,0x37,0x8D,0xEE,0x16,0x8D,0xEB,0x18,0x8F,0x33,0x32,
0x39,0x8D,0xF2,0x18,0xDF,0x02,0x8D,0xED,0x18,0xDF,0x04,0x18,0x8C,0x00,0x00,
0x27,0x34,0x18,0xDE,0x02,0xC6,0x16,0xF7,0x10,0x3B,0x18,0xE7,0x00,0xC6,0x17,
0xF7,0x10,0x3B,0x8D,0x28,0xC6,0x02,0xF7,0x10,0x3B,0x8D,0xBD,0x18,0xA7,0x00,
0xC6,0x03,0xF7,0x10,0x3B,0x8D,0x17,0x8D,0xB8,0x18,0x08,0x18,0xDF,0x02,0x18,
0xDE,0x04,0x18,0x09,0x18,0xDF,0x04,0x20,0xC6,0x7F,0x10,0x3B,0x7E,0x00,0x12,
0x18,0x3C,0x18,0xCE,0x0D,0x10,0x18,0x09,0x18,0x8C,0x00,0x00,0x26,0xF8,0x18,
0x38,0x39,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,};


  print ("\nCargando CTSERVER:\n\n");
  set_break_timeout(500000);
  printf("0%%     50%%   100%%\n");
  print ("................\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
  
  if (cargar_ramint(cts9600,accion_load)==0) {
    printf ("\nError: %s\n",getloaderror());
    return 0;
  };
  printf ("\nOK!\n");
  return 1;
}
                                             
/*
 ****************************************************************************
 *                                                                          *    
 *      PROCEDIMIENTO PRINCIPAL. PRINCIPIO DEL PROGRAMA.                    *     
 *                                                                          *
 ****************************************************************************
*/

int main(int argc,char *argv[])
/*
*************************************************************
*  Procedimiento principal.                                 *
*************************************************************
*/
{
   static int turno=0;
   int j;

   puerto=COM2;
   analiza_parametros(argc,argv);
   if (abrir_puerto_serie(puerto)==0) {
    printf ("Error al abrir puerto serie: %s\n",getserial_error());
    exit(1);
   }  
   baudios(7680);
  

   if (cargar_ctserver()==0) {
     exit(1);
   }
   baudios(9600);
   usleep(200000);
   
   clrscr();
   print (" CT294 ");
   print (" Version "); 
   printf ("%s",version);
   printf ("IEAROBOTICS. %s\n",fecha);

	
   establecer_conexion();
   
   activar_conversores();
   activar_puertoA();     
   menu(puerto);

   
   do {   
     if (turno==0) {
	refresca_puertoA(); 
	dib_bit(bit_activo_A,PA);
	refresca_puertoE(); 
	dib_bit(bit_activo_E,PE);
	turno=1;
      }
      else {
	dib_ana_todos(); 
	dib_ana_uno(bit_activo_E);
	comprueba_conexion();
	turno=0;
      } 

      for (j=1; j<=38; j++) {
        wrefresh(ventana[j]);
      }
      wrefresh(ventana[40]);      

   } while ( procesar_comando() );

   noraw();
   echo();
   endwin();
   store(0x0,PORTA); 
   clrscr();

   cerrar_puerto_serie();
   return 0;
}
