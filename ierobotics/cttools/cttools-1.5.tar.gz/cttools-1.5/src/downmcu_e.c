/****************************************************************************/
/* Downmcu.c                                                                */
/****************************************************************************/
/*  Carga de programas en la RAM interna del 68HC11. El programa esta       */
/*  especificamente disenado para trabajar con la tarjeta CT6811.           */
/*--------------------------------------------------------------------------*/
/****************************************************************************/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>   
#include <unistd.h>  

#include <cts/serie.h>
#include <cts/s19.h>
#include <cts/bootstrp.h>
#include <cts/ctclient.h>
#include "termansi.h"
#include "io.h"

#define TIEMPO 500000

char version[]={"1.5.0"};
char fecha[]={"Julio 2004"};

int puerto;
char fich[80];

int i=0;
int n=0;

void carga()
{
  if (n==32 || i==511) {
    n=0;
    print ("*");
  }
  i++;
  n++;
}

void presenta()
{
  printf ("\n");
  setcolor(ROJO);
  high();
  print ("DOWNMCU_E ");
  setcolor(AMARILLO);
  print (version);
  setcolor(VERDE);
  print (" para LINUX. ");
  setcolor(CYAN);
  print ("(C) IEAROBOTICS ");
  print (fecha);
  printf ("\n");
  setcolor(BLANCO);
  print ("Carga de programas en la CT6811\n\n");
  low();
}

void help()
{
  presenta();
  low();
  high();
  print ("Forma de uso: ");
  low();
  print ("downmcu_e fichero.s19 [opciones]\n\n");
  high(); print ("   -com1   ");
  low();  print ("Utilizar el COM1\n");
  high(); print ("   -com2   ");
  low();  print ("Utilizar el COM2\n");
  high(); print ("   -noansi ");
  low();  print ("No utilizar terminal ansi\n");
  high(); print ("   -h      ");
  low();  print ("Esta ayuda\n\n");
  high(); print ("Ejemplo:  ");
  low();  print ("downmcu_e ledp.s19 -com2\n\n");
}

void analizar_parametros(int argc, char* argv[])
{
    int c;

    puerto=COM2;  /* Por defecto COM2 */

    if (argc<2) {
      printf ("\nERROR: No se ha especificado nombre de fichero .s19\n");
      printf ("Utilice downmcu -h para obtener ayuda\n\n");
      exit(1);
    }  
      
    strcpy(fich,argv[1]);
    while ((c = getopt(argc, argv, ":c:n:h"))!=EOF) {
 	switch (c) {
  	  case 'c':
            if (strcmp("om2",optarg)==0) puerto=COM2;
            else 
              if (strcmp("om1",optarg)==0) puerto=COM1;
              else puerto=COM2;  /* Por defecto COM2 */
	    break;
          case 'n':
            if (strcmp("oansi",optarg)==0) configansi(0);
            else printf ("Parametro incorrecto\n");  
            break;
	  case 'h':
	default: help();
	         exit (0);
	}
    }
}




int check_raminta(S19 fs19, int *ov)
{
  int i;
  unsigned int dir;
  unsigned int nreg;
  byte codigo[35];
  byte tam;
  byte crc;

  nreg=getnregs19(fs19);

  if (nreg==0) {   /* *Fichero S19 sin registros? */
      setcolor(ROJO);
      high();
      print ("\n\n  ---> ERROR: Error en el fichero\n\n");
      low();
      exit(1);
  }
  leerdir_s19(fs19,1,&dir);
  if (dir>0x1FF) {
    *ov=0;
    return 0;      /* programa no es para la RAM interna */
  }
   
  for (i=2; i<=nreg; i++) {
    leerdir_s19(fs19,i,&dir);
    leercod_s19(fs19,i,codigo,&tam,&crc);
    if ( (dir+tam)>0x1FF) {
      *ov=1;                /* Programa desborda la ram interna */
      return 1;
    }
  }
  *ov=0;
  return 1;                 /* Programa es para la RAM interna */
}



int situacion_progs19a(S19 fs19, int *ov)
{
  if (check_raminta(fs19,ov)==1) return 1;  /* Programa para RAM interna */
  return 3;   /* Programa para RAM externa */
}



void s19toraminta(S19 f,byte *ramint, byte *ramintoc)
{
  unsigned int i,n;
  unsigned int dir;
  unsigned int nreg;
  byte codigo[37];
  byte tam;
  byte crc;

  nreg=getnregs19(f);

  for (i=0; i<=511; i++) {
    ramint[i]=0;
    ramintoc[i]=0;	      /* Inicialmente todas las posiciones vacias */
  }

  for (i=1; i<=nreg; i++) {
    leerdir_s19(f,i,&dir);
    leercod_s19(f,i,codigo,&tam,&crc);
    for (n=0; n<tam; n++) {
      if ((dir+n)<=0x1FF) {
	ramint[dir+n]=codigo[n];    /* Guardar valor          */
	ramintoc[dir+n]=1;          /* Indicar posici*n llena */
      }
    }
  }
}




int cargar_raminta(byte *ramint, void (*car)())
{
  int i;
  byte c;
  int timeout;


  baudios(7680);
  vaciar_buffer_rx();
  resetct6811();
  if (okreset()==0) {
    setcolor(ROJO);
    high();
    print ("\n\n  ---> ERROR: No se recibe BREAK\n\n");
    low();
    return 0;
  }
  enviar_car(0xFF);          /* Especificar 7680 baudios */
  enviar_bloque(ramint,512);

  for (i=0; i<=511; i++) {
    c=leer_car_plazo(TIEMPO,&timeout);

    if (timeout) {
      setcolor(ROJO);
      high();
      print ("\n\n  ---> ERROR: Timeout\n\n");
      low();
      return 0;
    }
    
    if (c!=ramint[i]) { 
      setcolor(ROJO);
      high();
      print ("\n\n  ---> ERROR: Fallo en la transmision\n\n");
      low();
      return 0;      /* El ultimo eco no se cuenta...   */
    }  
    (*car)();          
  }
  return 1;
}

int cargars19_raminta(S19 fs19, void (*car)())
{
  byte ramint[512];
  byte ramintoc[512];

  s19toraminta(fs19,ramint,ramintoc);
  return cargar_raminta(ramint,car);
}


int main(int argc, char* argv[])
{
  char *caderror;
  S19 fs19;
  int ov;
  char s[30];

  analizar_parametros(argc,argv);

  printf ("\n");
  presenta();

  if (abrir_s19(fich,&fs19, 1)==0) {
    caderror=(char *)geterrors19();
    high();
    setcolor(ROJO);
    printf (" --> ERROR: %s\n\n",caderror);
    low();
    return 0;
  }
  
  if (situacion_progs19a(fs19,&ov)!=1) {
    setcolor(ROJO);
    high();
    print ("  ---> ERROR: El programa NO es para la RAM interna\n\n");
    low();
    cerrar_s19(fs19);
    exit(1);
  }
  if (ov==1) {
    setcolor(ROJO);
    high();
    print ("  ---> ERROR: El programa desborda la RAM interna\n\n");
    low();
    cerrar_s19(fs19);
    exit(2);
  }
  
  if (abrir_puerto_serie(puerto)==0) {
    printf ("Error al abrir puerto serie: %s\n\n",getserial_error());
    exit(1);
  }  
  set_break_timeout(100000);
  setcolor(CYAN);
  printf("0%%     50%%   100%%\n");
  high();
  setcolor(AZUL);
  print ("................\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
  if (cargars19_raminta(fs19,carga)==0) {
    low();
  }
  else {
    printf (" OK!!\n\n");
    low(); high();
    print ("Tamano del programa: ");
    setcolor(VERDE);
    sprintf (s,"%u bytes\n",getnbytes19(fs19));
    print(s);
    low(); high();
    printf ("Envio correcto\n\n");
    low();
  }

  cerrar_s19(fs19);
  cerrar_puerto_serie();

  return 0;
}
