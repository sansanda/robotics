/**************************************************************************/
/*  IO.C                                                                  */
/* ---------------------------------------------------------------------- */
/*  Rutinas de E/S para la pantalla y el teclado. Las funciones de        */
/*  interfaz son:                                                         */
/*                                                                        */
/*    * abrir_consola()                                                   */
/*    * cerrar_consola()                                                  */
/*    * print()                                                           */
/*    * printcar()                                                        */
/*    * getch()                                                           */
/*    * kbhit()                                                           */
/*                                                                        */
/**************************************************************************/

void abrir_consola();
void cerrar_consola();
int kbhit();
char io_getch();
void printcar(char c);
void print(char *cad);
