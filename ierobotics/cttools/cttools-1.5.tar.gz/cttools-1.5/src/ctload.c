/****************************************************************************/
/* CTLOAD.c                                                                 */
/****************************************************************************/
/*  Cargar programa en la RAM externa del 68HC11.                           */
/*--------------------------------------------------------------------------*/
/****************************************************************************/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>   
#include <unistd.h>
#include<fcntl.h>

#include <cts/serie.h>
#include <cts/bootstrp.h>
#include <cts/r6811pc.h>
#include <cts/ctclient.h>
#include "termansi.h"
#include "io.h"



#define ESC 27

char version[]={"1.5.0"};
char fecha[]={"Julio 2004"};

/***********************/
/* Variables globales  */
/***********************/
int puerto;              /* Puerto serie.              */
int flag_terminal=0;     /* Ejecutar el terminal si/no */
unsigned int dir_ini=0;  /* Direccion de arranque      */
char fich[80];


int i=0;
int n=0;

void accion_load()
{
  if (n==16 || i==255) {
    n=0;
    print ("*");
  }
  i++;
  n++;
}

void presenta()
/******************************************/
/* Encabezado de presentacion del CTLOAD  */
/******************************************/
{
  printf ("\n");
  setcolor(ROJO);
  high();
  print ("CTLOAD ");
  setcolor(AMARILLO);
  print (version);
  setcolor(VERDE);
  print (" para LINUX. ");
  setcolor(CYAN);
  print ("IEAROBOTICS, ");
  print (fecha);
  printf ("\n");
  setcolor(BLANCO);
  print ("Carga de programas en RAM externa\n\n");
  low();
}

void help()
/*********************/
/* Mostrar la ayuda  */
/*********************/
{
  presenta();
  low();
  high();
  print ("Forma de uso: ");
  low();
  print ("ctload fichero.s19 [opciones]\n\n");
  high(); print ("   -com1   ");
  low();  print ("Utilizar el COM1\n");
  high(); print ("   -com2   ");
  low();  print ("Utilizar el COM2\n");
  high(); print ("   -h      ");
  low();  print ("Esta ayuda\n");
  high(); print ("   -t      ");
  low();  print ("Arrancar un terminal\n\n");
  high(); print ("Ejemplo:  ");
  low();  print ("ctload ledp.s19 -com2\n\n");
}

void analizar_parametros(int argc, char* argv[])
/*****************************************************************/
/* Analizar los parametros pasados desde la linea de comandos    */
/* Se actualizan las variables globales:                         */
/*       - puerto: Con el puerto serie especificado              */
/*       - flag_terminal: Si hay que ejecutar el terminal        */
/*****************************************************************/
{
    int c;

    puerto=COM2;  /* Por defecto COM2 */

    if (argc<2) {
      printf ("\nERROR: No se ha especificado nombre de fichero .s19\n");
      printf ("Utilice ctload -h para obtener ayuda\n\n");
      exit(1);
    }  
      
    strcpy(fich,argv[1]);
    while ((c = getopt(argc, argv, ":c:ht"))!=EOF) {
 	switch (c) {
  	  case 'c':
            if (strcmp("om2",optarg)==0) puerto=COM2;
            else 
              if (strcmp("om1",optarg)==0) puerto=COM1;
              else puerto=COM2;  /* Por defecto COM2 */
	    break;
          case 't':
            flag_terminal=1;
            break;  
	  case 'h':
	default: help();
	         exit (0);
	}
    }
}

void print_info(S19 fs19)
/********************************************************/
/* Imprimir informacion sobre los parametros actuales   */
/********************************************************/
{
  leerdir_s19(fs19,1,&dir_ini);

  printf ("Puerto actual        : COM%u\n",puerto+1);
  printf ("Fichero              : %s\n",fich);
  printf ("Tama�o               : %d bytes\n",getnbytes19(fs19));
  printf ("Direccion de comienzo: %X\n",dir_ini);
}

void print_error(char *cad)
/*******************************/
/* Imprimir cadena de error    */
/*******************************/
{
  setcolor(AMARILLO);
  high();
  print ("\n  ---> ERROR: ");
  low();
  printf (cad);
  printf ("\n\n");
}
 

int ram_interna(S19 fs19)
/*****************************************/
/* Cargar un programa en la RAM interna  */
/*****************************************/
{
  char cad[80];
  
  setcolor(CYAN);
  printf("0%%     50%%   100%%\n");
  high();
  setcolor(AZUL);
  print ("................\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
  if (cargars19_ramint(fs19,accion_load)==0) {
    sprintf (cad,"Error: %s",getloaderror());
    print_error(cad);
    return 0;
  }
  else {
    printf (" OK!!\n\n");
    return 1;
  }
}

void accion()
{
}

int cargar_ram_ext(S19 fs19)
/***********************************************************/
/* Cargar un programa en la ram externa. Se supone que el  */
/* CTSERVER ya se encuentra cargado y la conexion          */
/* establecida                                             */
/***********************************************************/
{
  uint nreg;
  uint i;
  uint dir;
  byte tam;
  uint tam2;
  byte crc;
  byte codigo[30];
  uint total;
  uint cargados=0;

  nreg=getnregs19(fs19);   /* Numero de registros */
  total=getnbytes19(fs19); /* Bytes totales       */
  low();
  high(); print ("Bytes restantes: ");
  low();
  printf ("%5d",total); fflush(stdout);
  
  for (i=1; i<=nreg; i++) {
    leerdir_s19(fs19,i,&dir);
    leercod_s19(fs19,i,codigo,&tam,&crc);
    tam2=(uint) tam;
    store_block(codigo,tam2,dir,accion);
    cargados+=tam2;
    printf ("\b\b\b\b\b%5d",total-cargados);
    fflush(stdout);
    if (!check_conexion()) {
      print_error("CTSERVER: Conexion perdida...");
      return 0;
    }
  }
  setcolor(AZUL); high();  print (" OK!!!\n");
  setcolor(AMARILLO); 
  print ("Carga completada\n\n");
  usleep(200000);
  low();
  return 1;
}

void terminal()
/********************************/
/* Terminal de comunicaciones   */
/********************************/
{
  char c,d;
  
  low();
  printf ("TERMINAL ACTIVADO. ESC PARA TERMINAR\n\n");
  abrir_consola();
  do {
    if (kbhit()) {
      c=io_getch();
      enviar_car(c);
    }
    if (car_waiting()) {
      d=leer_car();
      if (d!=0) printcar(d);
      else printcar('*');
    }
  } while (c!=ESC);
  
  printf ("\n\n");
  cerrar_consola();
}

int detecta_ct6811()
/**************************************************/
/* Detectar la tarjeta ct6811 en modo bootstrap   */
/**************************************************/
{
  resetct6811();
  if (wait_break(100000)==0) {
    return 0;  /* No se detecta CT6811 */
  }
  return 1;    /* CT6811 detectada  */
}


int cargar_ctserver()
/******************************************************************/
/* Cargar el CTSERVER.                                            */
/******************************************************************/
{
  char cad[80];

/*********************************************************************/
/* Matriz en C que contiene el servidor ctsloader. Es totalmente     */
/* compatible con el ctserver. Funciona a 9600 baudios y al arrancar */
/* pasa a expanded.                                                  */
/*********************************************************************/

byte ctsloader[256]={
0x20,0x05,0x00,0x00,0x00,0x00,0x00,0xCE,0x10,0x00,0x1F,0x2E,0x40,0xFC,0x86,
0x30,0xA7,0x2B,0x1D,0x3C,0x80,0x1C,0x3C,0x20,0x1D,0x3C,0x40,0xCE,0x10,0x00,
0x8D,0x66,0x97,0x06,0x81,0x44,0x27,0x13,0x81,0x43,0x27,0x54,0x81,0x41,0x27,
0x17,0x81,0x42,0x27,0x0E,0x81,0x45,0x27,0x6A,0x7E,0x00,0x1B,0x86,0x4A,0x8D,
0x50,0x7E,0x00,0x1B,0x7C,0x00,0x06,0x20,0x03,0x7F,0x00,0x06,0x8D,0x4A,0x18,
0xDF,0x02,0x8D,0x45,0x18,0xDF,0x04,0x18,0x8C,0x00,0x00,0x27,0x23,0x18,0xDE,
0x02,0x96,0x06,0x4D,0x26,0x07,0x18,0xA6,0x00,0x8D,0x28,0x20,0x05,0x8D,0x1D,
0x18,0xA7,0x00,0x18,0x08,0x18,0xDF,0x02,0x18,0xDE,0x04,0x18,0x09,0x18,0xDF,
0x04,0x20,0xD7,0x7E,0x00,0x1B,0x8D,0x14,0x18,0xDF,0x02,0x18,0x6E,0x00,0x1F,
0x2E,0x20,0xFC,0xA6,0x2F,0x39,0x1F,0x2E,0x80,0xFC,0xA7,0x2F,0x39,0x36,0x37,
0x8D,0xEE,0x16,0x8D,0xEB,0x18,0x8F,0x33,0x32,0x39,0x8D,0xF2,0x18,0xDF,0x02,
0x8D,0xED,0x18,0xDF,0x04,0x18,0x8C,0x00,0x00,0x27,0x34,0x18,0xDE,0x02,0xC6,
0x16,0xF7,0x10,0x3B,0x18,0xE7,0x00,0xC6,0x17,0xF7,0x10,0x3B,0x8D,0x28,0xC6,
0x02,0xF7,0x10,0x3B,0x8D,0xBD,0x18,0xA7,0x00,0xC6,0x03,0xF7,0x10,0x3B,0x8D,
0x17,0x8D,0xB8,0x18,0x08,0x18,0xDF,0x02,0x18,0xDE,0x04,0x18,0x09,0x18,0xDF,
0x04,0x20,0xC6,0x7F,0x10,0x3B,0x7E,0x00,0x1B,0x18,0x3C,0x18,0xCE,0x0D,0x10,
0x18,0x09,0x18,0x8C,0x00,0x00,0x26,0xF8,0x18,0x38,0x39,0x00,0x00,0x00,0x00,
0x00,};

  print ("\nCargando CTSERVER:\n\n");
  set_break_timeout(500000);

  setcolor(CYAN);
  printf("0%%     50%%   100%%\n");
  high();
  setcolor(AZUL);
  print ("................\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
  if (cargar_ramint(ctsloader,accion_load)==0) {
    sprintf (cad,"Error: %s\n\n",getloaderror());
    print_error(cad);
    return 0;
  }
  else {
    printf (" OK!!\n\n");
    return 1;
  }
}

int cargar_ctserver_s19()
/************************************************************************/
/* Cargar el ctsloader de un fichero S19. Esta funcion se utiliza para   */
/* realizar pruebas rapidas con un ctserver modificado. Una vez que     */
/* tiene el ctserver definitivo se pasa a C y se incluye en la funcion  */
/* cargar_ctserver().                                                   */
/************************************************************************/
{
  char *caderror;
  S19 fs19;

  if (abrir_s19("ctsloader.s19",&fs19,1)==0) {
    caderror=(char *)geterrors19();
    printf ("Error: %s\n",caderror);
    return 0;
  }
  
  print ("\nCargando CTSERVER:\n\n");
  set_break_timeout(500000);
  printf("0%%     50%%   100%%\n");
  print ("................\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
  
  if (cargars19_ramint(fs19,accion_load)==0) {
    printf ("\nError: %s\n",getloaderror());
    return 0;
  }
  
  printf ("\nOK!\n");
  return 1;
  
  cerrar_s19(fs19);
}

int modo_expanded(S19 fs19)
/******************************************************************/
/* Cargar un programa en la RAM externa:                          */
/*                                                                */
/*  - Se carga el CTSERVER                                        */
/*  - Se pasa a expanded                                          */
/*  - Se carga el programa                                        */
/*  - Se salta a la direccion de inicio                           */
/*                                                                */
/*  Se devuelve 1 si no ha habido problemas. 0 en caso de error   */
/******************************************************************/
{
  baudios(7680);
  
  /* DETECTAR LA CT6811 */
  if (!detecta_ct6811()) {
    print_error("No se recibe se�al de BREAK");
    return 0;
  }
  
  /* CARGAR EL CTSERVER */
  if (!cargar_ctserver()) return 0;
  
  baudios(9600);
  usleep(200000);
  vaciar_buffer_tx();
  vaciar_buffer_rx();
  
  /* ESTABLECER CONEXION CON CTSERVER */
  if (!check_conexion()) {
    print_error("CTSERVER, conexion no establecida");
    return 0;
  }
  
  if (cargar_ram_ext(fs19)) {
    execute(dir_ini);
    return 1;
  }
  else return 0;
}

/*****************************************************/
/*     P R O G R A M A     P R I N C I P A L         */
/*****************************************************/

int main(int argc, char* argv[])
{
  char *caderror;
  char cad[80];
  S19 fs19;
  int ov;
  int ok=0;

  analizar_parametros(argc,argv);

  printf ("\n");
  presenta();

  /* ABRIR EL FICHERO  S19 */
  if (abrir_s19(fich,&fs19, 1)==0) {
    caderror=(char *)geterrors19();
    print_error(caderror);
    exit(1);
  }

  /* IMPRIMIR INFORMACION */
  print_info(fs19);
  
  /* ABRIR EL PUERTO SERIE */
  if (abrir_puerto_serie(puerto)==0) {
    sprintf (cad,"Puerto serie, %s",getserial_error());
    print_error(cad);
    cerrar_s19(fs19);
    exit(1);
  }
  set_break_timeout(500000);

  /* SI ES UN PROGRAMA PARA LA RAM INTERNA */
  if (situacion_progs19(fs19,&ov)==1) {
    printf ("PROGRAMA PARA LA RAM INTERNA\n\n");
    if (ov==1) {
      print_error("El programa desborda la RAM interna");
      cerrar_s19(fs19);
      cerrar_puerto_serie();
      exit(2);
    }
    
    /* Cargar el programa en la RAM interna */
    ok=ram_interna(fs19);
  }
  else {
    printf ("PROGRAMA PARA RAM EXTERNA\n\n");
    ok=modo_expanded(fs19);
  }  
  
  if (ok)
    if (flag_terminal) terminal();

  low();
  printf ("\n");  
  cerrar_s19(fs19);
  cerrar_puerto_serie();
  return 0;
}
